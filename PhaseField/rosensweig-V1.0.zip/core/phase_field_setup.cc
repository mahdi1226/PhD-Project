// ============================================================================
// core/phase_field_setup.cc - Setup Methods for Phase Field Problem
//
// Setup for CH + Poisson + Magnetization (DG) + NS systems.
//
// Reference: Nochetto, Salgado & Tomas, CMAME 309 (2016) 497-531
// ============================================================================

#include "core/phase_field.h"
#include "diagnostics/ch_mms.h"
#include "setup/ch_setup.h"
#include "setup/poisson_setup.h"
#include "setup/ns_setup.h"

#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/grid_tools.h>
#include <deal.II/dofs/dof_tools.h>
#include <deal.II/lac/dynamic_sparsity_pattern.h>
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/base/quadrature_lib.h>

#include <cmath>
#include <iostream>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// ============================================================================
// Constructor
// ============================================================================
template <int dim>
PhaseFieldProblem<dim>::PhaseFieldProblem(const Parameters& params)
    : params_(params)
    , fe_Q2_(params.fe.degree_velocity)   // Q2 for velocity, phase fields
    , fe_Q1_(params.fe.degree_pressure)   // Q1 for pressure
    , fe_DG_(0)                           // DG0 for magnetization
    , theta_dof_handler_(triangulation_)
    , psi_dof_handler_(triangulation_)
    , phi_dof_handler_(triangulation_)
    , mx_dof_handler_(triangulation_)
    , my_dof_handler_(triangulation_)
    , ux_dof_handler_(triangulation_)
    , uy_dof_handler_(triangulation_)
    , p_dof_handler_(triangulation_)
    , time_(0.0)
    , timestep_number_(0)
{
}

// ============================================================================
// setup_mesh()
//
// Creates rectangular domain with specified number of initial cells,
// then applies global refinement.
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::setup_mesh()
{
    using namespace dealii;

    // Create rectangular domain with subdivisions
    Point<dim> p1(params_.domain.x_min, params_.domain.y_min);
    Point<dim> p2(params_.domain.x_max, params_.domain.y_max);

    std::vector<unsigned int> subdivisions(dim);
    subdivisions[0] = params_.domain.initial_cells_x;
    subdivisions[1] = params_.domain.initial_cells_y;

    GridGenerator::subdivided_hyper_rectangle(triangulation_, subdivisions, p1, p2);

    // Assign boundary IDs:
    //   0 = bottom (y = y_min)
    //   1 = right  (x = x_max)
    //   2 = top    (y = y_max)
    //   3 = left   (x = x_min)
    for (auto& face : triangulation_.active_face_iterators())
    {
        if (!face->at_boundary())
            continue;

        const auto center = face->center();
        const double tol = 1e-10;

        if (std::abs(center[1] - params_.domain.y_min) < tol)
            face->set_boundary_id(0);  // bottom
        else if (std::abs(center[0] - params_.domain.x_max) < tol)
            face->set_boundary_id(1);  // right
        else if (std::abs(center[1] - params_.domain.y_max) < tol)
            face->set_boundary_id(2);  // top
        else if (std::abs(center[0] - params_.domain.x_min) < tol)
            face->set_boundary_id(3);  // left
    }

    // Global refinement
    triangulation_.refine_global(params_.domain.initial_refinement);

    if (params_.output.verbose)
    {
        std::cout << "[Setup] Base mesh: " << params_.domain.initial_cells_x
                  << " × " << params_.domain.initial_cells_y << " cells\n";
        std::cout << "[Setup] After " << params_.domain.initial_refinement
                  << " refinements: " << triangulation_.n_active_cells() << " cells\n";
    }
}

// ============================================================================
// setup_dof_handlers()
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::setup_dof_handlers()
{
    using namespace dealii;

    // ========================================================================
    // CH fields (θ, ψ) - Q2 elements
    // ========================================================================
    theta_dof_handler_.distribute_dofs(fe_Q2_);
    psi_dof_handler_.distribute_dofs(fe_Q2_);

    const unsigned int n_theta = theta_dof_handler_.n_dofs();
    const unsigned int n_psi = psi_dof_handler_.n_dofs();

    theta_solution_.reinit(n_theta);
    theta_old_solution_.reinit(n_theta);
    psi_solution_.reinit(n_psi);

    // ========================================================================
    // Poisson (φ) - Q2 elements
    // ========================================================================
    if (params_.magnetic.enabled)
    {
        phi_dof_handler_.distribute_dofs(fe_Q2_);
        phi_solution_.reinit(phi_dof_handler_.n_dofs());
    }

    // ========================================================================
    // Magnetization (Mx, My) - DG elements (NEW!)
    //
    // CRITICAL: M must be DG for the energy identity B_h^m(H,H,M) = 0.
    // Do NOT use CG or projected fields!
    // ========================================================================
    if (params_.magnetic.enabled)
    {
        mx_dof_handler_.distribute_dofs(fe_DG_);
        my_dof_handler_.distribute_dofs(fe_DG_);

        const unsigned int n_M = mx_dof_handler_.n_dofs();

        mx_solution_.reinit(n_M);
        my_solution_.reinit(n_M);
        mx_old_solution_.reinit(n_M);
        my_old_solution_.reinit(n_M);

        // Initialize to zero (will be set properly in initialize_solutions)
        mx_solution_ = 0;
        my_solution_ = 0;
        mx_old_solution_ = 0;
        my_old_solution_ = 0;

        if (params_.output.verbose)
        {
            std::cout << "[Setup] Magnetization DoFs: " << n_M << " (DG"
                      << fe_DG_.degree << ")\n";
        }
    }

    // ========================================================================
    // NS fields (ux, uy, p) - Q2 velocity, Q1 pressure (Taylor-Hood)
    // ========================================================================
    if (params_.ns.enabled)
    {
        ux_dof_handler_.distribute_dofs(fe_Q2_);
        uy_dof_handler_.distribute_dofs(fe_Q2_);
        p_dof_handler_.distribute_dofs(fe_Q1_);

        const unsigned int n_ux = ux_dof_handler_.n_dofs();
        const unsigned int n_uy = uy_dof_handler_.n_dofs();
        const unsigned int n_p = p_dof_handler_.n_dofs();

        ux_solution_.reinit(n_ux);
        ux_old_solution_.reinit(n_ux);
        uy_solution_.reinit(n_uy);
        uy_old_solution_.reinit(n_uy);
        p_solution_.reinit(n_p);

        // Initialize velocity to zero
        ux_solution_ = 0;
        ux_old_solution_ = 0;
        uy_solution_ = 0;
        uy_old_solution_ = 0;
        p_solution_ = 0;

        if (params_.output.verbose)
        {
            std::cout << "[Setup] DoFs: θ = " << n_theta
                      << ", ψ = " << n_psi;
            if (params_.magnetic.enabled)
                std::cout << ", φ = " << phi_dof_handler_.n_dofs()
                          << ", M = " << mx_dof_handler_.n_dofs();
            std::cout << ", ux = " << n_ux
                      << ", uy = " << n_uy
                      << ", p = " << n_p << "\n";
        }
    }
    else
    {
        // Create dummy velocity vectors for CH assembly (zero velocity)
        ux_old_solution_.reinit(n_theta);
        uy_old_solution_.reinit(n_theta);
        ux_old_solution_ = 0;
        uy_old_solution_ = 0;

        if (params_.output.verbose)
        {
            std::cout << "[Setup] DoFs: θ = " << n_theta
                      << ", ψ = " << n_psi;
            if (params_.magnetic.enabled)
                std::cout << ", φ = " << phi_dof_handler_.n_dofs()
                          << ", M = " << mx_dof_handler_.n_dofs();
            std::cout << "\n";
        }
    }
}

// ============================================================================
// setup_constraints()
//
// For physical runs: Neumann BCs (natural, no explicit constraints)
// For MMS verification: Dirichlet BCs (θ = θ_exact, ψ = ψ_exact on ∂Ω)
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::setup_constraints()
{
    using namespace dealii;

    // θ constraints
    theta_constraints_.clear();
    DoFTools::make_hanging_node_constraints(theta_dof_handler_, theta_constraints_);

    // ψ constraints
    psi_constraints_.clear();
    DoFTools::make_hanging_node_constraints(psi_dof_handler_, psi_constraints_);

    // For MMS: add Dirichlet BCs at initial time
    if (params_.mms.enabled)
    {
        apply_ch_mms_boundary_constraints<dim>(
            theta_dof_handler_,
            psi_dof_handler_,
            theta_constraints_,
            psi_constraints_,
            params_.mms.t_init);

        // Set initial time
        const_cast<double&>(time_) = params_.mms.t_init;
    }

    theta_constraints_.close();
    psi_constraints_.close();
}

// ============================================================================
// setup_ch_system()
//
// Creates coupled θ-ψ system using the setup free function.
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::setup_ch_system()
{
    setup_ch_coupled_system<dim>(
        theta_dof_handler_,
        psi_dof_handler_,
        theta_constraints_,
        psi_constraints_,
        theta_to_ch_map_,
        psi_to_ch_map_,
        ch_combined_constraints_,
        ch_sparsity_,
        params_.output.verbose);

    // Initialize matrix and vectors
    const unsigned int n_ch = theta_dof_handler_.n_dofs() +
                               psi_dof_handler_.n_dofs();
    ch_matrix_.reinit(ch_sparsity_);
    ch_rhs_.reinit(n_ch);
    ch_solution_.reinit(n_ch);
}

// ============================================================================
// setup_poisson_system()
//
// Poisson for magnetostatic potential: (∇φ, ∇χ) = (h_a - M, ∇χ)
// Pure Neumann → pin DoF 0 to fix constant.
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::setup_poisson_system()
{
    using namespace dealii;

    // Constraints: hanging nodes + pin DoF 0
    phi_constraints_.clear();
    DoFTools::make_hanging_node_constraints(phi_dof_handler_, phi_constraints_);

    // Pin DoF 0 to zero (fixes the constant for pure Neumann)
    if (phi_dof_handler_.n_dofs() > 0 && !phi_constraints_.is_constrained(0))
    {
        phi_constraints_.add_line(0);
        phi_constraints_.set_inhomogeneity(0, 0.0);
    }
    phi_constraints_.close();

    // Sparsity pattern WITH constraints
    DynamicSparsityPattern dsp(phi_dof_handler_.n_dofs());
    DoFTools::make_sparsity_pattern(phi_dof_handler_, dsp,
                                     phi_constraints_,
                                     /*keep_constrained_dofs=*/false);
    phi_sparsity_.copy_from(dsp);

    // Initialize matrix and vectors
    phi_matrix_.reinit(phi_sparsity_);
    phi_rhs_.reinit(phi_dof_handler_.n_dofs());

    if (params_.output.verbose)
    {
        std::cout << "[Setup] Poisson sparsity: "
                  << phi_sparsity_.n_nonzero_elements() << " nonzeros\n";
    }
}

// ============================================================================
// setup_magnetization_system() - NEW!
//
// DG transport for magnetization M = (Mx, My).
// Paper Eq. 42d: ∂M/∂t + (u·∇)M = (1/τ_M)(χ(θ)H - M)
//
// CRITICAL: Must use DG elements and flux sparsity pattern!
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::setup_magnetization_system()
{
    using namespace dealii;

    const unsigned int n_M = mx_dof_handler_.n_dofs();

    // DG sparsity: includes face coupling (for upwind flux)
    DynamicSparsityPattern dsp_M(n_M, n_M);
    DoFTools::make_flux_sparsity_pattern(mx_dof_handler_, dsp_M);
    mx_sparsity_.copy_from(dsp_M);
    my_sparsity_.copy_from(dsp_M);  // Same pattern for My

    // Initialize matrices and vectors
    mx_matrix_.reinit(mx_sparsity_);
    my_matrix_.reinit(my_sparsity_);
    mx_rhs_.reinit(n_M);
    my_rhs_.reinit(n_M);

    if (params_.output.verbose)
    {
        std::cout << "[Setup] Magnetization sparsity: "
                  << mx_sparsity_.n_nonzero_elements() << " nonzeros (DG flux)\n";
    }
}

// ============================================================================
// setup_ns_system()
//
// Taylor-Hood Q2-Q1 for velocity-pressure.
// No-slip BCs on all boundaries.
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::setup_ns_system()
{
    using namespace dealii;

    // ========================================================================
    // Individual field constraints
    // ========================================================================
    ux_constraints_.clear();
    uy_constraints_.clear();
    p_constraints_.clear();

    DoFTools::make_hanging_node_constraints(ux_dof_handler_, ux_constraints_);
    DoFTools::make_hanging_node_constraints(uy_dof_handler_, uy_constraints_);
    DoFTools::make_hanging_node_constraints(p_dof_handler_, p_constraints_);

    // No-slip BCs: u = 0 on all boundaries
    for (unsigned int boundary_id = 0; boundary_id < 4; ++boundary_id)
    {
        VectorTools::interpolate_boundary_values(
            ux_dof_handler_,
            boundary_id,
            Functions::ZeroFunction<dim>(),
            ux_constraints_);
        VectorTools::interpolate_boundary_values(
            uy_dof_handler_,
            boundary_id,
            Functions::ZeroFunction<dim>(),
            uy_constraints_);
    }

    // ========================================================================
    // CRITICAL: Pin one pressure DoF to fix the constant!
    // ========================================================================
    if (p_dof_handler_.n_dofs() > 0 && !p_constraints_.is_constrained(0))
    {
        p_constraints_.add_line(0);
        p_constraints_.set_inhomogeneity(0, 0.0);
    }

    ux_constraints_.close();
    uy_constraints_.close();
    p_constraints_.close();

    // ========================================================================
    // Build coupled NS system
    // ========================================================================
    setup_ns_coupled_system<dim>(
        ux_dof_handler_,
        uy_dof_handler_,
        p_dof_handler_,
        ux_constraints_,
        uy_constraints_,
        p_constraints_,
        ux_to_ns_map_,
        uy_to_ns_map_,
        p_to_ns_map_,
        ns_combined_constraints_,
        ns_sparsity_,
        params_.output.verbose);

    // Initialize matrix and vectors
    const unsigned int n_ns = ux_dof_handler_.n_dofs() +
                               uy_dof_handler_.n_dofs() +
                               p_dof_handler_.n_dofs();
    ns_matrix_.reinit(ns_sparsity_);
    ns_rhs_.reinit(n_ns);
    ns_solution_.reinit(n_ns);
}

// ============================================================================
// initialize_solutions()
//
// IC types for physical runs:
//   0 = Flat ferrofluid layer (DEFAULT)
//   1 = Perturbed layer
//   2 = Circular droplet (testing)
//
// For MMS: use exact solutions at t_init
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::initialize_solutions()
{
    using namespace dealii;

    // MMS mode: use exact solutions at t_init
    if (params_.mms.enabled)
    {
        apply_ch_mms_initial_conditions<dim>(
            theta_dof_handler_,
            psi_dof_handler_,
            theta_solution_,
            psi_solution_,
            params_.mms.t_init);

        theta_old_solution_ = theta_solution_;

        if (params_.output.verbose)
        {
            std::cout << "[Setup] MMS IC at t = " << params_.mms.t_init << "\n";
            std::cout << "[Setup] Initial mass = " << compute_mass() << "\n";
        }
        return;
    }

    // Physical IC modes
    const double epsilon = params_.ch.epsilon;
    const int ic_type = params_.ic.type;
    const double interface_y = params_.ic.pool_depth;

    if (ic_type == 0)
    {
        // ================================================================
        // Flat ferrofluid layer
        // θ = +1 below interface (ferrofluid)
        // θ = -1 above interface (non-magnetic)
        // ================================================================
        class FlatLayerIC : public Function<dim>
        {
        public:
            double interface_y_, eps_;
            FlatLayerIC(double y, double e)
                : Function<dim>(1), interface_y_(y), eps_(e) {}

            double value(const Point<dim>& p, unsigned int = 0) const override
            {
                return -std::tanh((p[1] - interface_y_) / (std::sqrt(2.0) * eps_));
            }
        };

        FlatLayerIC ic_func(interface_y, epsilon);
        VectorTools::interpolate(theta_dof_handler_, ic_func, theta_solution_);

        if (params_.output.verbose)
            std::cout << "[Setup] Flat layer IC: interface at y = " << interface_y << "\n";
    }
    else if (ic_type == 1)
    {
        // ================================================================
        // Perturbed layer
        // ================================================================
        const double perturbation = params_.ic.perturbation;
        const int n_modes = params_.ic.perturbation_modes;
        const double Lx = params_.domain.x_max - params_.domain.x_min;

        class PerturbedLayerIC : public Function<dim>
        {
        public:
            double interface_y_, eps_, amp_, Lx_, x_min_;
            int n_modes_;

            PerturbedLayerIC(double y, double e, double a, double L, double xm, int n)
                : Function<dim>(1)
                , interface_y_(y), eps_(e), amp_(a), Lx_(L), x_min_(xm), n_modes_(n) {}

            double value(const Point<dim>& p, unsigned int = 0) const override
            {
                double pert = 0.0;
                for (int k = 1; k <= n_modes_; ++k)
                    pert += amp_ * std::cos(2.0 * M_PI * k * (p[0] - x_min_) / Lx_);
                const double y_interface = interface_y_ + pert;
                return -std::tanh((p[1] - y_interface) / (std::sqrt(2.0) * eps_));
            }
        };

        PerturbedLayerIC ic_func(interface_y, epsilon, perturbation, Lx,
                                  params_.domain.x_min, n_modes);
        VectorTools::interpolate(theta_dof_handler_, ic_func, theta_solution_);

        if (params_.output.verbose)
            std::cout << "[Setup] Perturbed layer IC: interface at y = " << interface_y << "\n";
    }
    else if (ic_type == 2)
    {
        // ================================================================
        // Circular droplet (testing only)
        // ================================================================
        const double cx = 0.5 * (params_.domain.x_min + params_.domain.x_max);
        const double cy = 0.5 * (params_.domain.y_min + params_.domain.y_max);
        const double radius = 0.2;

        class DropletIC : public Function<dim>
        {
        public:
            double cx_, cy_, radius_, eps_;
            DropletIC(double cx, double cy, double r, double e)
                : Function<dim>(1), cx_(cx), cy_(cy), radius_(r), eps_(e) {}

            double value(const Point<dim>& p, unsigned int = 0) const override
            {
                const double dist = std::sqrt((p[0]-cx_)*(p[0]-cx_) + (p[1]-cy_)*(p[1]-cy_));
                return -std::tanh((dist - radius_) / (std::sqrt(2.0) * eps_));
            }
        };

        DropletIC ic_func(cx, cy, radius, epsilon);
        VectorTools::interpolate(theta_dof_handler_, ic_func, theta_solution_);

        if (params_.output.verbose)
            std::cout << "[Setup] Circular droplet IC\n";
    }
    else
    {
        std::cerr << "[Setup] Unknown IC type: " << ic_type << "\n";
        std::exit(1);
    }

    // Copy to old solution
    theta_old_solution_ = theta_solution_;

    // Initialize ψ = 0 (will be computed in first solve)
    psi_solution_ = 0;

    // ========================================================================
    // Initialize magnetization M = χ(θ) H
    //
    // At t=0, we don't have H yet, so either:
    //   (a) Set M = 0 and let it evolve
    //   (b) Solve Poisson once to get H, then set M = χ(θ) H
    //
    // Option (b) is more physical but requires Poisson to be set up first.
    // For simplicity, we use (a) here; M will quickly relax to equilibrium.
    // ========================================================================
    if (params_.magnetic.enabled)
    {
        mx_solution_ = 0;
        my_solution_ = 0;
        mx_old_solution_ = 0;
        my_old_solution_ = 0;

        if (params_.output.verbose)
            std::cout << "[Setup] Magnetization initialized to zero (will relax)\n";
    }

    if (params_.output.verbose)
        std::cout << "[Setup] Initial mass = " << compute_mass() << "\n";
}

// ============================================================================
// get_min_h() - Minimum cell diameter
// ============================================================================
template <int dim>
double PhaseFieldProblem<dim>::get_min_h() const
{
    return dealii::GridTools::minimal_cell_diameter(triangulation_);
}

// ============================================================================
// Explicit instantiation
// ============================================================================
template class PhaseFieldProblem<2>;