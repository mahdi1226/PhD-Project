// ============================================================================
// mms/mms_core/mms_verification.cc - MMS Verification Implementation (PARALLEL VERSION)
//
// PARALLEL STATUS:
//   - CH_STANDALONE: CONVERTED ✓
//   - POISSON_STANDALONE: CONVERTED ✓
//   - NS_STANDALONE: CONVERTED ✓
//   - MAGNETIZATION_STANDALONE: CONVERTED ✓
//   - POISSON_MAGNETIZATION: CONVERTED ✓
//   - CH_NS_CAPILLARY: CONVERTED ✓
//   - NS_MAGNETIZATION: CONVERTED ✓ (tests Kelvin force coupling)
//   - NS_VARIABLE_NU: NOT YET
//
// Uses MMSContext for setup, which calls PRODUCTION code:
// - CH: ch_setup.h + ch_assembler.h + ch_solver.h
// - NS: ns_setup.h + ns_assembler.h + ns_solver.h + ns_block_preconditioner.h
// ============================================================================

#include "mms_verification.h"
#include "mms_context.h"

// MMS exact solutions and error computation
#include "mms/ch/ch_mms.h"
#include "mms/poisson/poisson_mms.h"

// Coupled MMS tests
#include "mms/coupled/coupled_mms_test.h"

// Production assembly
#include "assembly/ch_assembler.h"

// Production solvers
#include "solvers/ch_solver.h"

// MMS test modules (converted to parallel)
#include "mms/ch/ch_mms_test.h"
#include "mms/poisson/poisson_mms_test.h"
#include "mms/ns/ns_mms_test.h"
#include "mms/magnetization/magnetization_mms_test.h"

#include <deal.II/base/utilities.h>

#include <iostream>
#include <iomanip>
#include <fstream>
#include <chrono>
#include <cmath>
#include <stdexcept>

// ============================================================================
// Helper: compute convergence rate
// ============================================================================

static double compute_single_rate(double e_fine, double e_coarse,
                                  double h_fine, double h_coarse)
{
    if (e_coarse < 1e-15 || e_fine < 1e-15) return 0.0;
    return std::log(e_coarse / e_fine) / std::log(h_coarse / h_fine);
}

static void fill_rates(const std::vector<double>& errors,
                       const std::vector<double>& h_values,
                       std::vector<double>& rates)
{
    rates.clear();
    for (size_t i = 1; i < errors.size(); ++i)
        rates.push_back(compute_single_rate(errors[i], errors[i - 1],
                                            h_values[i], h_values[i - 1]));
}

// ============================================================================
// MMSConvergenceResult Implementation
// ============================================================================

void MMSConvergenceResult::compute_rates()
{
    fill_rates(theta_L2, h_values, theta_L2_rate);
    fill_rates(theta_H1, h_values, theta_H1_rate);
    fill_rates(psi_L2, h_values, psi_L2_rate);
    fill_rates(phi_L2, h_values, phi_L2_rate);
    fill_rates(phi_H1, h_values, phi_H1_rate);
    fill_rates(ux_L2, h_values, ux_L2_rate);
    fill_rates(ux_H1, h_values, ux_H1_rate);
    fill_rates(uy_L2, h_values, uy_L2_rate);
    fill_rates(uy_H1, h_values, uy_H1_rate);
    fill_rates(p_L2, h_values, p_L2_rate);
    fill_rates(M_L2, h_values, M_L2_rate);
    fill_rates(div_u_L2, h_values, div_u_L2_rate);
}

void MMSConvergenceResult::print() const
{
    std::cout << "\n========================================\n";
    std::cout << "MMS Convergence Results: " << to_string(level) << "\n";
    std::cout << "MPI ranks: " << n_mpi_ranks << "\n";
    std::cout << "Total wall time: " << std::fixed << std::setprecision(1)
              << total_wall_time << " s\n";
    std::cout << "========================================\n";

    // Print appropriate table based on level
    switch (level)
    {
    case MMSLevel::CH_STANDALONE:
        print_ch_table();
        break;
    case MMSLevel::POISSON_STANDALONE:
        print_poisson_table();
        break;
    case MMSLevel::NS_STANDALONE:
        print_ns_table();
        break;
    case MMSLevel::MAGNETIZATION_STANDALONE:
        print_magnetization_table();
        break;
    case MMSLevel::POISSON_MAGNETIZATION:
        print_poisson_table();
        print_magnetization_table();
        break;
    case MMSLevel::CH_NS_CAPILLARY:
        print_ch_table();
        print_ns_table();
        break;
    case MMSLevel::NS_MAGNETIZATION:
        print_ns_table();
        print_magnetization_table();
        break;
    case MMSLevel::NS_VARIABLE_NU:
        print_ns_table();
        break;
    default:
        std::cout << "Unknown test level\n";
    }

    std::cout << "========================================\n";
    if (passes())
        std::cout << "[PASS] Convergence rates within tolerance!\n";
    else
        std::cout << "[FAIL] Some rates below expected!\n";
}

void MMSConvergenceResult::print_ch_table() const
{
    std::cout << "\n--- CH Errors ---\n";
    if (theta_L2.empty()) {
        std::cout << "[WARNING] No CH data to display\n";
        return;
    }
    std::cout << std::left
        << std::setw(5) << "Ref"
        << std::setw(10) << "h"
        << std::setw(9) << "wall(s)"
        << std::setw(10) << "θ_L2"
        << std::setw(6) << "rate"
        << std::setw(10) << "θ_H1"
        << std::setw(6) << "rate"
        << std::setw(10) << "ψ_L2"
        << std::setw(6) << "rate"
        << "\n";
    std::cout << std::string(72, '-') << "\n";

    for (size_t i = 0; i < refinements.size(); ++i)
    {
        std::cout << std::left << std::setw(5) << refinements[i]
            << std::scientific << std::setprecision(2)
            << std::setw(10) << h_values[i]
            << std::fixed << std::setprecision(1)
            << std::setw(9) << wall_times[i]
            << std::scientific << std::setprecision(2)
            << std::setw(10) << theta_L2[i]
            << std::fixed << std::setprecision(2)
            << std::setw(6) << (i > 0 ? theta_L2_rate[i - 1] : 0.0)
            << std::scientific << std::setprecision(2)
            << std::setw(10) << theta_H1[i]
            << std::fixed << std::setprecision(2)
            << std::setw(6) << (i > 0 ? theta_H1_rate[i - 1] : 0.0)
            << std::scientific << std::setprecision(2)
            << std::setw(10) << (i < psi_L2.size() ? psi_L2[i] : 0.0)
            << std::fixed << std::setprecision(2)
            << std::setw(6) << (i > 0 && !psi_L2_rate.empty() ? psi_L2_rate[i - 1] : 0.0)
            << "\n";
    }
}

void MMSConvergenceResult::print_poisson_table() const
{
    std::cout << "\n--- Poisson Errors ---\n";
    if (phi_L2.empty()) {
        std::cout << "[WARNING] No Poisson data to display\n";
        return;
    }
    std::cout << std::left
        << std::setw(6) << "Ref"
        << std::setw(10) << "h"
        << std::setw(10) << "wall(s)"
        << std::setw(10) << "φ_L2"
        << std::setw(7) << "rate"
        << std::setw(10) << "φ_H1"
        << std::setw(7) << "rate"
        << "\n";
    std::cout << std::string(60, '-') << "\n";

    for (size_t i = 0; i < refinements.size(); ++i)
    {
        std::cout << std::left << std::setw(6) << refinements[i]
            << std::scientific << std::setprecision(2)
            << std::setw(10) << h_values[i]
            << std::fixed << std::setprecision(1)
            << std::setw(10) << wall_times[i]
            << std::scientific << std::setprecision(2)
            << std::setw(10) << phi_L2[i]
            << std::fixed << std::setprecision(2)
            << std::setw(7) << (i > 0 ? phi_L2_rate[i - 1] : 0.0)
            << std::scientific << std::setprecision(2)
            << std::setw(10) << phi_H1[i]
            << std::fixed << std::setprecision(2)
            << std::setw(7) << (i > 0 ? phi_H1_rate[i - 1] : 0.0)
            << "\n";
    }
}

void MMSConvergenceResult::print_ns_table() const
{
    std::cout << "\n--- NS Errors ---\n";
    if (ux_L2.empty()) {
        std::cout << "[WARNING] No NS data to display\n";
        return;
    }
    std::cout << std::left
        << std::setw(6) << "Ref"
        << std::setw(10) << "h"
        << std::setw(10) << "wall(s)"
        << std::setw(10) << "ux_L2"
        << std::setw(7) << "rate"
        << std::setw(10) << "ux_H1"
        << std::setw(7) << "rate"
        << std::setw(10) << "p_L2"
        << std::setw(7) << "rate"
        << "\n";
    std::cout << std::string(80, '-') << "\n";

    for (size_t i = 0; i < refinements.size(); ++i)
    {
        std::cout << std::left << std::setw(6) << refinements[i]
            << std::scientific << std::setprecision(2)
            << std::setw(10) << (i < h_values.size() ? h_values[i] : 0.0)
            << std::fixed << std::setprecision(1)
            << std::setw(10) << (i < wall_times.size() ? wall_times[i] : 0.0)
            << std::scientific << std::setprecision(2)
            << std::setw(10) << (i < ux_L2.size() ? ux_L2[i] : 0.0)
            << std::fixed << std::setprecision(2)
            << std::setw(7) << (i > 0 && i - 1 < ux_L2_rate.size() ? ux_L2_rate[i - 1] : 0.0)
            << std::scientific << std::setprecision(2)
            << std::setw(10) << (i < ux_H1.size() ? ux_H1[i] : 0.0)
            << std::fixed << std::setprecision(2)
            << std::setw(7) << (i > 0 && i - 1 < ux_H1_rate.size() ? ux_H1_rate[i - 1] : 0.0)
            << std::scientific << std::setprecision(2)
            << std::setw(10) << (i < p_L2.size() ? p_L2[i] : 0.0)
            << std::fixed << std::setprecision(2)
            << std::setw(7) << (i > 0 && i - 1 < p_L2_rate.size() ? p_L2_rate[i - 1] : 0.0)
            << "\n";
    }
}

void MMSConvergenceResult::print_magnetization_table() const
{
    std::cout << "\n--- Magnetization Errors ---\n";
    if (M_L2.empty()) {
        std::cout << "[WARNING] No Magnetization data to display\n";
        return;
    }
    std::cout << std::left
        << std::setw(6) << "Ref"
        << std::setw(10) << "h"
        << std::setw(10) << "wall(s)"
        << std::setw(10) << "M_L2"
        << std::setw(7) << "rate"
        << "\n";
    std::cout << std::string(43, '-') << "\n";

    for (size_t i = 0; i < refinements.size(); ++i)
    {
        std::cout << std::left << std::setw(6) << refinements[i]
            << std::scientific << std::setprecision(2)
            << std::setw(10) << h_values[i]
            << std::fixed << std::setprecision(1)
            << std::setw(10) << wall_times[i]
            << std::scientific << std::setprecision(2)
            << std::setw(10) << M_L2[i]
            << std::fixed << std::setprecision(2)
            << std::setw(7) << (i > 0 ? M_L2_rate[i - 1] : 0.0)
            << "\n";
    }
}

bool MMSConvergenceResult::passes(double tolerance) const
{
    // Check based on level
    switch (level)
    {
    case MMSLevel::CH_STANDALONE:
        if (theta_L2_rate.empty()) return false;
        return (theta_L2_rate.back() >= expected_L2_rate - tolerance) &&
               (theta_H1_rate.back() >= expected_H1_rate - tolerance);

    case MMSLevel::POISSON_STANDALONE:
        if (phi_L2_rate.empty()) return false;
        return (phi_L2_rate.back() >= expected_L2_rate - tolerance) &&
               (phi_H1_rate.back() >= expected_H1_rate - tolerance);

    case MMSLevel::POISSON_MAGNETIZATION:
        if (phi_L2_rate.empty() || M_L2_rate.empty()) return false;
        return (phi_L2_rate.back() >= expected_L2_rate - tolerance) &&
               (M_L2_rate.back() >= 2 - tolerance);

    case MMSLevel::CH_NS_CAPILLARY:
        if (theta_L2_rate.empty() || ux_L2_rate.empty()) return false;
        return (theta_L2_rate.back() >= expected_L2_rate - tolerance) &&
               (ux_L2_rate.back() >= expected_L2_rate - tolerance);

    case MMSLevel::NS_STANDALONE:
    case MMSLevel::NS_MAGNETIZATION:
    case MMSLevel::NS_VARIABLE_NU:
        if (ux_L2_rate.empty()) return false;
        return (ux_L2_rate.back() >= expected_L2_rate - tolerance);

    case MMSLevel::MAGNETIZATION_STANDALONE:
        if (M_L2_rate.empty()) return false;
        return (M_L2_rate.back() >= 2 - tolerance);

    default:
        return false;
    }
}

// ============================================================================
// CH_STANDALONE - Wrapper that calls ch_mms_test module (PARALLEL)
// ============================================================================

static MMSConvergenceResult run_ch_standalone(
    const std::vector<unsigned int>& refinements,
    Parameters params,
    unsigned int n_time_steps,
    MPI_Comm mpi_communicator)
{
    CHMMSConvergenceResult ch_result = run_ch_mms_standalone(
        refinements, params, CHSolverType::GMRES_AMG, n_time_steps, mpi_communicator);

    MMSConvergenceResult result;
    result.level = MMSLevel::CH_STANDALONE;
    result.fe_degree = ch_result.fe_degree;
    result.n_time_steps = ch_result.n_time_steps;
    result.dt = ch_result.dt;
    result.expected_L2_rate = ch_result.expected_L2_rate;
    result.expected_H1_rate = ch_result.expected_H1_rate;

    for (const auto& r : ch_result.results)
    {
        result.refinements.push_back(r.refinement);
        result.h_values.push_back(r.h);
        result.theta_L2.push_back(r.theta_L2);
        result.theta_H1.push_back(r.theta_H1);
        result.psi_L2.push_back(r.psi_L2);
        result.n_dofs.push_back(r.n_dofs);
        result.wall_times.push_back(r.total_time);
    }

    result.n_mpi_ranks = dealii::Utilities::MPI::n_mpi_processes(mpi_communicator);
    result.total_wall_time = 0.0;
    for (const auto& t : result.wall_times)
        result.total_wall_time += t;

    result.compute_rates();
    return result;
}

// ============================================================================
// POISSON_STANDALONE
// ============================================================================

static MMSConvergenceResult run_poisson_standalone(
    const std::vector<unsigned int>& refinements,
    Parameters params,
    MPI_Comm mpi_communicator)
{
    PoissonMMSConvergenceResult poisson_result = run_poisson_mms_standalone(
        refinements, params, PoissonSolverType::AMG, mpi_communicator);

    MMSConvergenceResult result;
    result.level = MMSLevel::POISSON_STANDALONE;
    result.fe_degree = poisson_result.fe_degree;
    result.expected_L2_rate = poisson_result.expected_L2_rate;
    result.expected_H1_rate = poisson_result.expected_H1_rate;

    for (const auto& r : poisson_result.results)
    {
        result.refinements.push_back(r.refinement);
        result.h_values.push_back(r.h);
        result.phi_L2.push_back(r.L2_error);
        result.phi_H1.push_back(r.H1_error);
        result.n_dofs.push_back(r.n_dofs);
        result.wall_times.push_back(r.total_time);
    }

    result.n_mpi_ranks = dealii::Utilities::MPI::n_mpi_processes(mpi_communicator);
    result.total_wall_time = 0.0;
    for (const auto& t : result.wall_times)
        result.total_wall_time += t;

    result.compute_rates();
    return result;
}

// ============================================================================
// MAGNETIZATION_STANDALONE
// ============================================================================

static MMSConvergenceResult run_magnetization_standalone(
    const std::vector<unsigned int>& refinements,
    Parameters params,
    MPI_Comm mpi_communicator)
{
    MagMMSConvergenceResult mag_result = run_magnetization_mms_standalone(
        refinements, params, MagSolverType::GMRES, mpi_communicator);

    MMSConvergenceResult result;
    result.level = MMSLevel::MAGNETIZATION_STANDALONE;
    result.fe_degree = mag_result.fe_degree;
    result.expected_L2_rate = mag_result.expected_L2_rate;

    for (const auto& r : mag_result.results)
    {
        result.refinements.push_back(r.refinement);
        result.h_values.push_back(r.h);
        result.M_L2.push_back(r.M_L2);
        result.n_dofs.push_back(r.n_dofs);
        result.wall_times.push_back(r.total_time);
    }

    result.n_mpi_ranks = dealii::Utilities::MPI::n_mpi_processes(mpi_communicator);
    result.total_wall_time = 0.0;
    for (const auto& t : result.wall_times)
        result.total_wall_time += t;

    result.compute_rates();
    return result;
}

// ============================================================================
// NS_STANDALONE - Now passes n_time_steps!
// ============================================================================

static MMSConvergenceResult run_ns_standalone(
    const std::vector<unsigned int>& refinements,
    Parameters params,
    unsigned int n_time_steps,
    MPI_Comm mpi_communicator)
{
    NSMMSConvergenceResult ns_result = run_ns_mms_standalone(
        refinements, params, n_time_steps, mpi_communicator);

    MMSConvergenceResult result;
    result.level = MMSLevel::NS_STANDALONE;
    result.fe_degree = ns_result.fe_degree_velocity;
    result.n_time_steps = ns_result.n_time_steps;
    result.dt = ns_result.dt;
    result.expected_L2_rate = ns_result.expected_vel_L2_rate;
    result.expected_H1_rate = ns_result.expected_vel_H1_rate;

    for (const auto& r : ns_result.results)
    {
        result.refinements.push_back(r.refinement);
        result.h_values.push_back(r.h);
        result.n_dofs.push_back(r.n_dofs);
        result.wall_times.push_back(r.total_time);
        result.ux_L2.push_back(r.ux_L2);
        result.ux_H1.push_back(r.ux_H1);
        result.uy_L2.push_back(r.uy_L2);
        result.uy_H1.push_back(r.uy_H1);
        result.p_L2.push_back(r.p_L2);
        result.div_u_L2.push_back(r.div_U_L2);
    }

    result.n_mpi_ranks = dealii::Utilities::MPI::n_mpi_processes(mpi_communicator);
    result.total_wall_time = 0.0;
    for (const auto& t : result.wall_times)
        result.total_wall_time += t;

    result.compute_rates();
    return result;
}

// ============================================================================
// POISSON_MAGNETIZATION - Coupled test
// ============================================================================

static MMSConvergenceResult run_poisson_magnetization_coupled(
    const std::vector<unsigned int>& refinements,
    Parameters params,
    unsigned int n_time_steps,
    MPI_Comm mpi_communicator)
{
    CoupledMMSConvergenceResult coupled_result = run_poisson_magnetization_mms(
        refinements, params, n_time_steps, mpi_communicator);

    MMSConvergenceResult result;
    result.level = MMSLevel::POISSON_MAGNETIZATION;
    result.fe_degree = params.fe.degree_potential;
    result.n_time_steps = n_time_steps;
    result.expected_L2_rate = params.fe.degree_potential + 1;
    result.expected_H1_rate = params.fe.degree_potential;

    for (const auto& r : coupled_result.results)
    {
        result.refinements.push_back(r.refinement);
        result.h_values.push_back(r.h);
        result.n_dofs.push_back(r.n_dofs);
        result.wall_times.push_back(r.total_time);
        result.phi_L2.push_back(r.phi_L2);
        result.phi_H1.push_back(r.phi_H1);
        result.M_L2.push_back(r.M_L2);
    }

    result.n_mpi_ranks = dealii::Utilities::MPI::n_mpi_processes(mpi_communicator);
    result.total_wall_time = 0.0;
    for (const auto& t : result.wall_times)
        result.total_wall_time += t;

    result.compute_rates();
    return result;
}

// ============================================================================
// CH_NS_CAPILLARY - Coupled test
// ============================================================================

static MMSConvergenceResult run_ch_ns_coupled(
    const std::vector<unsigned int>& refinements,
    Parameters params,
    unsigned int n_time_steps,
    MPI_Comm mpi_communicator)
{
    CoupledMMSConvergenceResult coupled_result = run_ch_ns_mms(
        refinements, params, n_time_steps, mpi_communicator);

    MMSConvergenceResult result;
    result.level = MMSLevel::CH_NS_CAPILLARY;
    result.fe_degree = params.fe.degree_phase;
    result.n_time_steps = n_time_steps;
    result.expected_L2_rate = params.fe.degree_phase + 1;
    result.expected_H1_rate = params.fe.degree_phase;

    for (const auto& r : coupled_result.results)
    {
        result.refinements.push_back(r.refinement);
        result.h_values.push_back(r.h);
        result.n_dofs.push_back(r.n_dofs);
        result.wall_times.push_back(r.total_time);
        result.theta_L2.push_back(r.theta_L2);
        result.theta_H1.push_back(r.theta_H1);
        result.ux_L2.push_back(r.ux_L2);
        result.ux_H1.push_back(r.ux_H1);
        result.p_L2.push_back(r.p_L2);
    }

    result.n_mpi_ranks = dealii::Utilities::MPI::n_mpi_processes(mpi_communicator);
    result.total_wall_time = 0.0;
    for (const auto& t : result.wall_times)
        result.total_wall_time += t;

    result.compute_rates();
    return result;
}

// ============================================================================
// NS_POISSON_MAG - Coupled test (Kelvin force)
// ============================================================================

static MMSConvergenceResult run_ns_poisson_mag_coupled(
    const std::vector<unsigned int>& refinements,
    Parameters params,
    unsigned int n_time_steps,
    MPI_Comm mpi_communicator)
{
    CoupledMMSConvergenceResult coupled_result = run_ns_poisson_mag_mms(
        refinements, params, n_time_steps, mpi_communicator);

    MMSConvergenceResult result;
    result.level = MMSLevel::NS_MAGNETIZATION;
    result.fe_degree = params.fe.degree_velocity;
    result.n_time_steps = n_time_steps;
    result.expected_L2_rate = params.fe.degree_velocity + 1;
    result.expected_H1_rate = params.fe.degree_velocity;

    for (const auto& r : coupled_result.results)
    {
        result.refinements.push_back(r.refinement);
        result.h_values.push_back(r.h);
        result.n_dofs.push_back(r.n_dofs);
        result.wall_times.push_back(r.total_time);
        result.ux_L2.push_back(r.ux_L2);
        result.ux_H1.push_back(r.ux_H1);
        result.phi_L2.push_back(r.phi_L2);
        result.phi_H1.push_back(r.phi_H1);
        result.M_L2.push_back(r.M_L2);
    }

    result.n_mpi_ranks = dealii::Utilities::MPI::n_mpi_processes(mpi_communicator);
    result.total_wall_time = 0.0;
    for (const auto& t : result.wall_times)
        result.total_wall_time += t;

    result.compute_rates();
    return result;
}

// ============================================================================
// Main dispatcher (PARALLEL)
// ============================================================================

MMSConvergenceResult run_mms_test(
    MMSLevel level,
    const std::vector<unsigned int>& refinements,
    const Parameters& params,
    unsigned int n_time_steps,
    MPI_Comm mpi_communicator)
{
    Parameters mutable_params = params;

    switch (level)
    {
    case MMSLevel::CH_STANDALONE:
        return run_ch_standalone(refinements, mutable_params, n_time_steps, mpi_communicator);

    case MMSLevel::POISSON_STANDALONE:
        return run_poisson_standalone(refinements, mutable_params, mpi_communicator);

    case MMSLevel::NS_STANDALONE:
        return run_ns_standalone(refinements, mutable_params, n_time_steps, mpi_communicator);

    case MMSLevel::MAGNETIZATION_STANDALONE:
        return run_magnetization_standalone(refinements, mutable_params, mpi_communicator);

    case MMSLevel::POISSON_MAGNETIZATION:
        return run_poisson_magnetization_coupled(refinements, mutable_params, n_time_steps, mpi_communicator);

    case MMSLevel::CH_NS_CAPILLARY:
        return run_ch_ns_coupled(refinements, mutable_params, n_time_steps, mpi_communicator);

    case MMSLevel::NS_MAGNETIZATION:
        return run_ns_poisson_mag_coupled(refinements, mutable_params, n_time_steps, mpi_communicator);

    case MMSLevel::NS_VARIABLE_NU:
        throw std::runtime_error(
            "NS_VARIABLE_NU not yet implemented.\n"
            "Available: CH_STANDALONE, POISSON_STANDALONE, NS_STANDALONE,\n"
            "           MAGNETIZATION_STANDALONE, POISSON_MAGNETIZATION, CH_NS_CAPILLARY");

    default:
        std::cerr << "[ERROR] Unknown MMS level: " << static_cast<int>(level) << "\n";
        return MMSConvergenceResult{};
    }
}

// ============================================================================
// Write results to CSV
// ============================================================================

void MMSConvergenceResult::write_csv(const std::string& filename) const
{
    std::ofstream file(filename);
    if (!file.is_open())
    {
        std::cerr << "[MMS] Failed to open " << filename << " for writing\n";
        return;
    }

    // Header
    file << "refinement,h,n_dofs,wall_time";

    // Add columns based on test level
    switch (level)
    {
    case MMSLevel::CH_STANDALONE:
        file << ",theta_L2,theta_L2_rate,theta_H1,theta_H1_rate,psi_L2,psi_L2_rate";
        break;
    case MMSLevel::POISSON_STANDALONE:
        file << ",phi_L2,phi_L2_rate,phi_H1,phi_H1_rate";
        break;
    case MMSLevel::POISSON_MAGNETIZATION:
        file << ",phi_L2,phi_L2_rate,phi_H1,phi_H1_rate,M_L2,M_L2_rate";
        break;
    case MMSLevel::CH_NS_CAPILLARY:
        file << ",theta_L2,theta_L2_rate,theta_H1,theta_H1_rate,ux_L2,ux_L2_rate,p_L2,p_L2_rate";
        break;
    case MMSLevel::NS_STANDALONE:
    case MMSLevel::NS_MAGNETIZATION:
    case MMSLevel::NS_VARIABLE_NU:
        file << ",ux_L2,ux_L2_rate,ux_H1,ux_H1_rate,p_L2,p_L2_rate,div_u_L2";
        break;
    case MMSLevel::MAGNETIZATION_STANDALONE:
        file << ",M_L2,M_L2_rate";
        break;
    default:
        break;
    }
    file << "\n";

    // Data rows
    for (size_t i = 0; i < refinements.size(); ++i)
    {
        file << refinements[i] << ","
            << std::scientific << std::setprecision(6) << h_values[i] << ","
            << n_dofs[i] << ","
            << std::fixed << std::setprecision(4) << wall_times[i];

        switch (level)
        {
        case MMSLevel::CH_STANDALONE:
            file << "," << std::scientific << theta_L2[i]
                << "," << std::fixed << std::setprecision(2) << (i > 0 ? theta_L2_rate[i - 1] : 0.0)
                << "," << std::scientific << theta_H1[i]
                << "," << std::fixed << (i > 0 ? theta_H1_rate[i - 1] : 0.0)
                << "," << std::scientific << psi_L2[i]
                << "," << std::fixed << (i > 0 ? psi_L2_rate[i - 1] : 0.0);
            break;
        case MMSLevel::POISSON_STANDALONE:
            file << "," << std::scientific << phi_L2[i]
                << "," << std::fixed << (i > 0 ? phi_L2_rate[i - 1] : 0.0)
                << "," << std::scientific << phi_H1[i]
                << "," << std::fixed << (i > 0 ? phi_H1_rate[i - 1] : 0.0);
            break;
        case MMSLevel::POISSON_MAGNETIZATION:
            file << "," << std::scientific << phi_L2[i]
                << "," << std::fixed << (i > 0 ? phi_L2_rate[i - 1] : 0.0)
                << "," << std::scientific << phi_H1[i]
                << "," << std::fixed << (i > 0 ? phi_H1_rate[i - 1] : 0.0)
                << "," << std::scientific << M_L2[i]
                << "," << std::fixed << (i > 0 ? M_L2_rate[i - 1] : 0.0);
            break;
        case MMSLevel::CH_NS_CAPILLARY:
            file << "," << std::scientific << theta_L2[i]
                << "," << std::fixed << (i > 0 ? theta_L2_rate[i - 1] : 0.0)
                << "," << std::scientific << theta_H1[i]
                << "," << std::fixed << (i > 0 ? theta_H1_rate[i - 1] : 0.0)
                << "," << std::scientific << ux_L2[i]
                << "," << std::fixed << (i > 0 ? ux_L2_rate[i - 1] : 0.0)
                << "," << std::scientific << p_L2[i]
                << "," << std::fixed << (i > 0 ? p_L2_rate[i - 1] : 0.0);
            break;
        case MMSLevel::NS_STANDALONE:
        case MMSLevel::NS_MAGNETIZATION:
        case MMSLevel::NS_VARIABLE_NU:
            file << "," << std::scientific << ux_L2[i]
                << "," << std::fixed << (i > 0 ? ux_L2_rate[i - 1] : 0.0)
                << "," << std::scientific << ux_H1[i]
                << "," << std::fixed << (i > 0 ? ux_H1_rate[i - 1] : 0.0)
                << "," << std::scientific << p_L2[i]
                << "," << std::fixed << (i > 0 ? p_L2_rate[i - 1] : 0.0)
                << "," << std::scientific << div_u_L2[i];
            break;
        case MMSLevel::MAGNETIZATION_STANDALONE:
            file << "," << std::scientific << M_L2[i]
                << "," << std::fixed << (i > 0 ? M_L2_rate[i - 1] : 0.0);
            break;
        default:
            break;
        }
        file << "\n";
    }

    file.close();
    std::cout << "[MMS] Results written to " << filename << "\n";
}

// ============================================================================
// to_string helper
// ============================================================================

std::string to_string(MMSLevel level)
{
    switch (level)
    {
    case MMSLevel::CH_STANDALONE:          return "CH_STANDALONE";
    case MMSLevel::POISSON_STANDALONE:     return "POISSON_STANDALONE";
    case MMSLevel::NS_STANDALONE:          return "NS_STANDALONE";
    case MMSLevel::MAGNETIZATION_STANDALONE: return "MAGNETIZATION_STANDALONE";
    case MMSLevel::POISSON_MAGNETIZATION:  return "POISSON_MAGNETIZATION";
    case MMSLevel::CH_NS_CAPILLARY:        return "CH_NS_CAPILLARY";
    case MMSLevel::NS_MAGNETIZATION:       return "NS_MAGNETIZATION";
    case MMSLevel::NS_VARIABLE_NU:         return "NS_VARIABLE_NU";
    default:                               return "UNKNOWN";
    }
}