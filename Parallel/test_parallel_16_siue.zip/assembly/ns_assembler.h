// ============================================================================
// assembly/ns_assembler.h - Parallel Navier-Stokes Assembler (Production)
//
// Reference: Nochetto, Salgado & Tomas, CMAME 309 (2016) 497-531
// Equation 42e-42f (discrete scheme)
//
// PRODUCTION assembler with:
//   - Skew-symmetric convection via skew_forms.h (Eq. 37)
//   - Kelvin force μ₀(M·∇)H via kelvin_force.h (Eq. 38)
//   - Capillary force (λ/ε)θ∇ψ (Eq. 14e)
//   - Gravity force r·H(θ/ε)·g (Eq. 19)
//   - Variable viscosity ν(θ) (Eq. 17)
//   - Optional MMS support via enable_mms flag
//
// Terms assembled:
//   - Mass: (U^n/τ, V) [if include_time_derivative]
//   - Viscous: ν(θ)(T(U), T(V)) where T(U) = ∇U + (∇U)^T
//   - Convection: B_h(U_old, U, V) [if include_convection]
//   - Pressure: -(p, ∇·V) + (∇·U, q)
//   - Kelvin force: μ₀ B_h^m(V, H, M) [if M and φ provided]
//   - Capillary force: (λ/ε)θ∇ψ [if θ and ψ provided]
//   - Gravity: r·H(θ/ε)·g [if enable_gravity]
//   - Body force: (f_body, V) [if provided]
//   - MMS source: (f_mms, V) [if enable_mms]
//   - RHS: (U^{n-1}/τ, V) [if include_time_derivative]
//
// ============================================================================
#ifndef NS_ASSEMBLER_H
#define NS_ASSEMBLER_H

#include <deal.II/base/tensor.h>
#include <deal.II/dofs/dof_handler.h>
#include <deal.II/lac/affine_constraints.h>
#include <deal.II/lac/trilinos_sparse_matrix.h>
#include <deal.II/lac/trilinos_vector.h>

#include <vector>
#include <functional>

/**
 * @brief Assemble the Navier-Stokes system (parallel, production)
 *
 * Basic version without Kelvin force - for standalone NS or when M=0.
 */
template <int dim>
void assemble_ns_system_parallel(
    const dealii::DoFHandler<dim>& ux_dof_handler,
    const dealii::DoFHandler<dim>& uy_dof_handler,
    const dealii::DoFHandler<dim>& p_dof_handler,
    const dealii::TrilinosWrappers::MPI::Vector& ux_old,
    const dealii::TrilinosWrappers::MPI::Vector& uy_old,
    double nu,
    double dt,
    bool include_time_derivative,
    bool include_convection,
    const std::vector<dealii::types::global_dof_index>& ux_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& uy_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& p_to_ns_map,
    const dealii::IndexSet& ns_owned,
    const dealii::AffineConstraints<double>& ns_constraints,
    dealii::TrilinosWrappers::SparseMatrix& ns_matrix,
    dealii::TrilinosWrappers::MPI::Vector& ns_rhs,
    MPI_Comm mpi_comm,
    bool enable_mms = false,
    double mms_time = 0.0,
    double mms_time_old = 0.0,
    double mms_L_y = 1.0);

/**
 * @brief Assemble NS system with body force callback
 *
 * Extended version that accepts a body force function for external forces
 * (gravity, etc.) - does NOT include Kelvin force.
 */
template <int dim>
void assemble_ns_system_with_body_force_parallel(
    const dealii::DoFHandler<dim>& ux_dof_handler,
    const dealii::DoFHandler<dim>& uy_dof_handler,
    const dealii::DoFHandler<dim>& p_dof_handler,
    const dealii::TrilinosWrappers::MPI::Vector& ux_old,
    const dealii::TrilinosWrappers::MPI::Vector& uy_old,
    double nu,
    double dt,
    bool include_time_derivative,
    bool include_convection,
    const std::vector<dealii::types::global_dof_index>& ux_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& uy_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& p_to_ns_map,
    const dealii::IndexSet& ns_owned,
    const dealii::AffineConstraints<double>& ns_constraints,
    dealii::TrilinosWrappers::SparseMatrix& ns_matrix,
    dealii::TrilinosWrappers::MPI::Vector& ns_rhs,
    MPI_Comm mpi_comm,
    const std::function<dealii::Tensor<1, dim>(const dealii::Point<dim>&, double)>& body_force,
    double current_time,
    bool enable_mms = false,
    double mms_time = 0.0,
    double mms_time_old = 0.0,
    double mms_L_y = 1.0);

/**
 * @brief Assemble NS system with Kelvin force only (for MMS testing)
 *
 * Kelvin force μ₀(M·∇)H from magnetization and magnetic potential fields.
 * Uses constant viscosity (no variable ν(θ)).
 *
 * This version is suitable for MMS testing of Kelvin force coupling.
 * For production ferrofluid, use assemble_ns_system_ferrofluid_parallel.
 *
 * Kelvin force (Eq. 38): B_h^m(V, H, M) with H = ∇φ
 *   = Σ_T ∫_T [(M·∇)H·V + ½(∇·M)(H·V)] dx - Σ_F ∫_F (V·n)[[H]]·{M} ds
 */
template <int dim>
void assemble_ns_system_with_kelvin_force_parallel(
    const dealii::DoFHandler<dim>& ux_dof_handler,
    const dealii::DoFHandler<dim>& uy_dof_handler,
    const dealii::DoFHandler<dim>& p_dof_handler,
    const dealii::TrilinosWrappers::MPI::Vector& ux_old,
    const dealii::TrilinosWrappers::MPI::Vector& uy_old,
    double nu,
    double dt,
    bool include_time_derivative,
    bool include_convection,
    const std::vector<dealii::types::global_dof_index>& ux_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& uy_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& p_to_ns_map,
    const dealii::IndexSet& ns_owned,
    const dealii::AffineConstraints<double>& ns_constraints,
    dealii::TrilinosWrappers::SparseMatrix& ns_matrix,
    dealii::TrilinosWrappers::MPI::Vector& ns_rhs,
    MPI_Comm mpi_comm,
    // Kelvin force inputs
    const dealii::DoFHandler<dim>& phi_dof_handler,
    const dealii::DoFHandler<dim>& M_dof_handler,
    const dealii::TrilinosWrappers::MPI::Vector& phi_solution,
    const dealii::TrilinosWrappers::MPI::Vector& Mx_solution,
    const dealii::TrilinosWrappers::MPI::Vector& My_solution,
    double mu_0,
    // MMS options
    bool enable_mms = false,
    double mms_time = 0.0,
    double mms_time_old = 0.0,
    double mms_L_y = 1.0);

/**
 * @brief Assemble full ferrofluid NS system (PRODUCTION)
 *
 * Complete ferrofluid momentum assembler (Paper Eq. 14e, 17, 19):
 *   - Variable viscosity: ν(θ) = ν_water + (ν_ferro - ν_water)·H(θ/ε)
 *   - Kelvin force: μ₀(M·∇)H (magnetic body force)
 *   - Capillary force: (λ/ε)θ∇ψ (surface tension)
 *   - Gravity force: r·H(θ/ε)·g (Boussinesq buoyancy)
 *
 * This is the PRODUCTION assembler for ferrofluid simulations.
 * Call from phase_field.cc with params_ values.
 */
template <int dim>
void assemble_ns_system_ferrofluid_parallel(
    const dealii::DoFHandler<dim>& ux_dof_handler,
    const dealii::DoFHandler<dim>& uy_dof_handler,
    const dealii::DoFHandler<dim>& p_dof_handler,
    const dealii::TrilinosWrappers::MPI::Vector& ux_old,
    const dealii::TrilinosWrappers::MPI::Vector& uy_old,
    double nu,  // Reference viscosity (for MMS source and Schur preconditioner)
    double dt,
    bool include_time_derivative,
    bool include_convection,
    const std::vector<dealii::types::global_dof_index>& ux_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& uy_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& p_to_ns_map,
    const dealii::IndexSet& ns_owned,
    const dealii::AffineConstraints<double>& ns_constraints,
    dealii::TrilinosWrappers::SparseMatrix& ns_matrix,
    dealii::TrilinosWrappers::MPI::Vector& ns_rhs,
    MPI_Comm mpi_comm,
    // Kelvin force inputs (magnetic)
    const dealii::DoFHandler<dim>& phi_dof_handler,
    const dealii::DoFHandler<dim>& M_dof_handler,
    const dealii::TrilinosWrappers::MPI::Vector& phi_solution,
    const dealii::TrilinosWrappers::MPI::Vector& Mx_solution,
    const dealii::TrilinosWrappers::MPI::Vector& My_solution,
    double mu_0,
    // Capillary force inputs (phase field)
    const dealii::DoFHandler<dim>& theta_dof_handler,
    const dealii::DoFHandler<dim>& psi_dof_handler,
    const dealii::TrilinosWrappers::MPI::Vector& theta_solution,
    const dealii::TrilinosWrappers::MPI::Vector& psi_solution,
    double lambda,   // params.physics.lambda
    double epsilon,  // params.physics.epsilon
    // Variable viscosity (Paper Eq. 17)
    double nu_water, // params.physics.nu_water
    double nu_ferro, // params.physics.nu_ferro
    // Gravity force inputs (Paper Eq. 19)
    bool enable_gravity,                       // params.enable_gravity
    double r,                                  // params.physics.r
    double gravity_mag,                        // params.physics.gravity
    const dealii::Tensor<1, dim>& gravity_dir, // params.gravity_direction
    // MMS options
    bool enable_mms = false,
    double mms_time = 0.0,
    double mms_time_old = 0.0,
    double mms_L_y = 1.0);

#endif // NS_ASSEMBLER_H