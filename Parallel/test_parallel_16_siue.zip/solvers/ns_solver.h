// ============================================================================
// solvers/ns_solver.h - Parallel Navier-Stokes Solver Interface
//
// Provides FGMRES + Block Schur preconditioner for saddle-point systems.
// This is the mathematically correct approach for Stokes/NS.
//
// UPDATE (2026-01-11): solve_ns_system_direct_parallel now uses true direct
// solver (Trilinos Amesos/UMFPACK), not GMRES+AMG.
//
// UPDATE (2026-01-12): Added overload with pressure pinning to remove null space.
// ============================================================================
#ifndef NS_SOLVER_H
#define NS_SOLVER_H

#include "solvers/solver_info.h"  // SolverInfo struct

#include <deal.II/lac/trilinos_sparse_matrix.h>
#include <deal.II/lac/trilinos_vector.h>
#include <deal.II/lac/trilinos_sparsity_pattern.h>
#include <deal.II/lac/affine_constraints.h>
#include <deal.II/dofs/dof_handler.h>

#include <vector>
#include <mpi.h>

/**
 * @brief Solve NS system with Block Schur preconditioner (ITERATIVE)
 *
 * Uses FGMRES with block Schur preconditioner:
 *   - AMG for velocity block
 *   - Pressure mass matrix for Schur approximation
 *
 * This is the correct approach for saddle-point systems.
 * Recommended for refinement >= 5 where direct solver is too slow.
 */
SolverInfo solve_ns_system_schur_parallel(
    const dealii::TrilinosWrappers::SparseMatrix& matrix,
    const dealii::TrilinosWrappers::MPI::Vector& rhs,
    dealii::TrilinosWrappers::MPI::Vector& solution,
    const dealii::AffineConstraints<double>& constraints,
    const dealii::TrilinosWrappers::SparseMatrix& pressure_mass,
    const std::vector<dealii::types::global_dof_index>& ux_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& uy_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& p_to_ns_map,
    const dealii::IndexSet& ns_owned,
    const dealii::IndexSet& vel_owned,
    const dealii::IndexSet& p_owned,
    MPI_Comm mpi_comm,
    double viscosity = 1.0,
    bool verbose = false);

/**
 * @brief Solve NS system with direct solver + pressure pinning (RECOMMENDED)
 *
 * Uses Trilinos Amesos direct solver with pressure pinning to remove null space.
 * This version pins the first pressure DoF to zero, making the matrix non-singular.
 *
 * Recommended for refinement levels <= 4 (< 500k DoFs)
 */
SolverInfo solve_ns_system_direct_parallel(
    const dealii::TrilinosWrappers::SparseMatrix& matrix,
    const dealii::TrilinosWrappers::MPI::Vector& rhs,
    dealii::TrilinosWrappers::MPI::Vector& solution,
    const dealii::AffineConstraints<double>& constraints,
    const std::vector<dealii::types::global_dof_index>& p_to_ns_map,
    const dealii::IndexSet& ns_owned,
    MPI_Comm mpi_comm,
    bool verbose = false);

/**
 * @brief Solve NS system with direct solver (LEGACY - NO PRESSURE PINNING)
 *
 * WARNING: This version does NOT pin pressure and will likely fail with
 * "singular matrix" errors (MUMPS INFOG(1)=-10, UMFPACK error -22).
 *
 * Use the overload with p_to_ns_map instead!
 */
SolverInfo solve_ns_system_direct_parallel(
    const dealii::TrilinosWrappers::SparseMatrix& matrix,
    const dealii::TrilinosWrappers::MPI::Vector& rhs,
    dealii::TrilinosWrappers::MPI::Vector& solution,
    const dealii::AffineConstraints<double>& constraints,
    MPI_Comm mpi_comm,
    bool verbose = false);

/**
 * @brief Extract individual field solutions from coupled NS solution
 */
void extract_ns_solutions_parallel(
    const dealii::TrilinosWrappers::MPI::Vector& ns_solution,
    const std::vector<dealii::types::global_dof_index>& ux_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& uy_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& p_to_ns_map,
    const dealii::IndexSet& ux_owned,
    const dealii::IndexSet& uy_owned,
    const dealii::IndexSet& p_owned,
    const dealii::IndexSet& ns_owned,
    const dealii::IndexSet& ns_relevant,
    dealii::TrilinosWrappers::MPI::Vector& ux_solution,
    dealii::TrilinosWrappers::MPI::Vector& uy_solution,
    dealii::TrilinosWrappers::MPI::Vector& p_solution,
    MPI_Comm mpi_comm);

/**
 * @brief Assemble pressure mass matrix for Schur preconditioner
 */
template <int dim>
void assemble_pressure_mass_matrix_parallel(
    const dealii::DoFHandler<dim>& p_dof_handler,
    const dealii::AffineConstraints<double>& p_constraints,
    const dealii::IndexSet& p_owned,
    const dealii::IndexSet& p_relevant,
    dealii::TrilinosWrappers::SparseMatrix& pressure_mass,
    MPI_Comm mpi_comm);

#endif // NS_SOLVER_H