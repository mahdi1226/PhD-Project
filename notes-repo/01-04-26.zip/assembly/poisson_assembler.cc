// ============================================================================
// assembly/poisson_assembler.cc - Magnetostatic Poisson Assembly (FIXED)
//
// PAPER EQUATION 42d:
//   (∇φ, ∇χ) = (h_a - M^k, ∇χ)  ∀χ ∈ X_h
//
// WEAK FORM DERIVATION:
//   Strong form: -Δφ = div(m - h_a) in Ω, ∂φ/∂n = (h_a - m)·n on Γ
//   After integration by parts (boundary terms cancel), we get:
//   (∇φ, ∇χ) = (h_a - m, ∇χ)
//
// NOTE: The applied field h_a MUST be included in the RHS!
//
// MMS MODE:
//   When params.enable_mms=true, uses exact manufactured solutions instead.
//
// Reference: Nochetto, Salgado & Tomas, CMAME 309 (2016) 497-531
// ============================================================================

#include "assembly/poisson_assembler.h"
#include "mms/poisson/poisson_mms.h"
#include "physics/applied_field.h"


#include <deal.II/base/quadrature_lib.h>
#include <deal.II/base/exceptions.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/lac/full_matrix.h>

#include <iostream>
#include <memory>

// ============================================================================
// Assemble the magnetostatic Poisson system (Paper Eq. 42d)
//
//   (∇φ, ∇χ) = (h_a - M^k, ∇χ)  ∀χ ∈ X_h
//
// h_a is the applied magnetic field from dipoles/external sources.
// M is computed by solve_magnetization() before this is called.
//
// In MMS mode, the applied field is replaced by MMS source terms.
// ============================================================================
template <int dim>
void assemble_poisson_system(
    const dealii::DoFHandler<dim>& phi_dof_handler,
    const dealii::DoFHandler<dim>& M_dof_handler,
    const dealii::Vector<double>& mx_solution,
    const dealii::Vector<double>& my_solution,
    const Parameters& params,
    double current_time,
    dealii::SparseMatrix<double>& phi_matrix,
    dealii::Vector<double>& phi_rhs,
    const dealii::AffineConstraints<double>& phi_constraints)
{
    const bool mms_mode = params.enable_mms;
    const double L_y = params.domain.y_max - params.domain.y_min;

    // Check if M is provided (non-empty vectors)
    const bool has_M = (mx_solution.size() > 0);

    // Check if applied field is active (has dipoles or external field)
    const bool has_applied_field = (!mms_mode && params.enable_magnetic &&
                                    !params.dipoles.positions.empty());

    phi_matrix = 0;
    phi_rhs = 0;

    const auto& phi_fe = phi_dof_handler.get_fe();
    const unsigned int dofs_per_cell = phi_fe.n_dofs_per_cell();

    const unsigned int quad_degree = phi_fe.degree + 2;
    dealii::QGauss<dim> quadrature(quad_degree);
    const unsigned int n_q_points = quadrature.size();

    // FEValues for φ
    dealii::FEValues<dim> phi_fe_values(phi_fe, quadrature,
        dealii::update_values |
        dealii::update_gradients |
        dealii::update_quadrature_points |
        dealii::update_JxW_values);

    // FEValues for M (only if M is provided)
    std::unique_ptr<dealii::FEValues<dim>> M_fe_values_ptr;
    if (has_M)
    {
        M_fe_values_ptr = std::make_unique<dealii::FEValues<dim>>(
            M_dof_handler.get_fe(), quadrature, dealii::update_values);
    }

    dealii::FullMatrix<double> local_matrix(dofs_per_cell, dofs_per_cell);
    dealii::Vector<double> local_rhs(dofs_per_cell);
    std::vector<dealii::types::global_dof_index> local_dof_indices(dofs_per_cell);

    std::vector<double> mx_values(n_q_points);
    std::vector<double> my_values(n_q_points);

    auto phi_cell = phi_dof_handler.begin_active();
    auto M_cell = has_M ? M_dof_handler.begin_active() : decltype(M_dof_handler.begin_active())();

    // Debug: track max applied field magnitude
    static bool printed_debug = false;
    double max_h_a_norm = 0.0;

    for (; phi_cell != phi_dof_handler.end(); ++phi_cell)
    {
        phi_fe_values.reinit(phi_cell);

        local_matrix = 0;
        local_rhs = 0;

        // Get M values if provided
        if (has_M)
        {
            M_fe_values_ptr->reinit(M_cell);
            M_fe_values_ptr->get_function_values(mx_solution, mx_values);
            M_fe_values_ptr->get_function_values(my_solution, my_values);
        }

        for (unsigned int q = 0; q < n_q_points; ++q)
        {
            const double JxW = phi_fe_values.JxW(q);
            const dealii::Point<dim>& x_q = phi_fe_values.quadrature_point(q);

            // ================================================================
            // Magnetization M (zero if not provided)
            // ================================================================
            dealii::Tensor<1, dim> M;
            if (has_M)
            {
                M[0] = mx_values[q];
                M[1] = my_values[q];
            }
            else
            {
                M[0] = 0.0;
                M[1] = 0.0;
            }

            // ================================================================
            // Applied field h_a from dipoles (CRITICAL FIX!)
            // ================================================================
            dealii::Tensor<1, dim> h_a;
            h_a[0] = 0.0;
            h_a[1] = 0.0;

            if (has_applied_field)
            {
                h_a = compute_applied_field<dim>(x_q, params, current_time);
                max_h_a_norm = std::max(max_h_a_norm, h_a.norm());
            }

            // ================================================================
            // RHS source: (h_a - M, ∇χ)  [Paper Eq. 42d]
            // ================================================================
            dealii::Tensor<1, dim> source;

            if (mms_mode)
            {
                // MMS mode: source = -M (h_a is replaced by MMS source term)
                source = -M;
            }
            else
            {
                // PRODUCTION mode: source = h_a - M (CORRECT per Nochetto)
                source[0] = h_a[0] - M[0];
                source[1] = h_a[1] - M[1];
            }

            // ================================================================
            // MMS source term: add (f_MMS, χ) to RHS
            // ================================================================
            double f_mms = 0.0;
            if (mms_mode)
            {
                if (has_M)
                {
                    // Coupled: f_MMS = -Δφ_exact - ∇·M_exact
                    f_mms = compute_poisson_mms_source_coupled<dim>(x_q, current_time, L_y);
                }
                else
                {
                    // Standalone: f_MMS = -Δφ_exact
                    f_mms = compute_poisson_mms_source_standalone<dim>(x_q, current_time, L_y);
                }
            }

            // ================================================================
            // Assemble local contributions
            // ================================================================
            for (unsigned int i = 0; i < dofs_per_cell; ++i)
            {
                const double chi_i = phi_fe_values.shape_value(i, q);
                const auto& grad_chi_i = phi_fe_values.shape_grad(i, q);

                // RHS: (h_a - M, ∇χ)
                local_rhs(i) += (source * grad_chi_i) * JxW;

                // MMS: add (f_MMS, χ) term
                if (mms_mode)
                {
                    local_rhs(i) += f_mms * chi_i * JxW;
                }

                for (unsigned int j = 0; j < dofs_per_cell; ++j)
                {
                    const auto& grad_chi_j = phi_fe_values.shape_grad(j, q);
                    // LHS: (∇φ, ∇χ)
                    local_matrix(i, j) += (grad_chi_i * grad_chi_j) * JxW;
                }
            }
        }

        phi_cell->get_dof_indices(local_dof_indices);
        phi_constraints.distribute_local_to_global(
            local_matrix, local_rhs, local_dof_indices,
            phi_matrix, phi_rhs);

        // Advance M cell iterator if M is provided
        if (has_M)
            ++M_cell;
    }

    // Debug output
    if (!printed_debug && has_applied_field && params.output.verbose)
    {
        std::cout << "[Poisson] Applied field h_a included in RHS, max|h_a| = "
                  << max_h_a_norm << "\n";
        printed_debug = true;
    }
}

// ============================================================================
// Explicit instantiation
// ============================================================================
template void assemble_poisson_system<2>(
    const dealii::DoFHandler<2>&,
    const dealii::DoFHandler<2>&,
    const dealii::Vector<double>&,
    const dealii::Vector<double>&,
    const Parameters&,
    double,
    dealii::SparseMatrix<double>&,
    dealii::Vector<double>&,
    const dealii::AffineConstraints<double>&);