// ============================================================================
// solvers/ch_solver.cc - Cahn-Hilliard System Solver Implementation
//
// UPDATED: Added ILU strengthening to prevent NaN from zero pivots
// DEBUG: Added iteration tracking debug output
// ============================================================================

#include "solvers/ch_solver.h"
#include "utilities/parameters.h"

#include <deal.II/lac/solver_gmres.h>
#include <deal.II/lac/solver_control.h>
#include <deal.II/lac/sparse_ilu.h>
#include <deal.II/lac/sparse_direct.h>

#include <iostream>
#include <chrono>
#include <cmath>

// ============================================================================
// Main solver with explicit parameters - RETURNS SolverInfo
// ============================================================================
SolverInfo solve_ch_system(
    const dealii::SparseMatrix<double>& matrix,
    const dealii::Vector<double>& rhs,
    const dealii::AffineConstraints<double>& constraints,
    const std::vector<dealii::types::global_dof_index>& theta_to_ch_map,
    const std::vector<dealii::types::global_dof_index>& psi_to_ch_map,
    dealii::Vector<double>& theta_solution,
    dealii::Vector<double>& psi_solution,
    const LinearSolverParams& params,
    bool log_output)
{
    SolverInfo info;
    info.solver_name = "CH";
    info.matrix_size = matrix.m();
    info.nnz = matrix.n_nonzero_elements();
    info.iterations = 0;      // Explicitly initialize
    info.residual = 0.0;
    info.converged = false;
    info.used_direct = false;

    dealii::Vector<double> coupled_solution(rhs.size());

    const double rhs_norm = rhs.l2_norm();
    if (rhs_norm < 1e-14)
    {
        coupled_solution = 0;
        constraints.distribute(coupled_solution);

        for (unsigned int i = 0; i < theta_solution.size(); ++i)
            theta_solution[i] = coupled_solution[theta_to_ch_map[i]];
        for (unsigned int i = 0; i < psi_solution.size(); ++i)
            psi_solution[i] = coupled_solution[psi_to_ch_map[i]];

        if (log_output)
            std::cout << "[CH Solver] Zero RHS, solution set to zero\n";

        info.converged = true;
        info.iterations = 0;  // No iterations needed for zero RHS
        return info;
    }

    auto start = std::chrono::high_resolution_clock::now();

    if (params.use_iterative)
    {
        const double tol = std::max(params.abs_tolerance,
                                    params.rel_tolerance * rhs_norm);

        dealii::SolverControl solver_control(params.max_iterations, tol);

        typename dealii::SolverGMRES<dealii::Vector<double>>::AdditionalData gmres_data;
        gmres_data.max_n_tmp_vectors = params.gmres_restart + 2;
        dealii::SolverGMRES<dealii::Vector<double>> solver(solver_control, gmres_data);

        // ====================================================================
        // ILU with strengthening to prevent zero pivot failures
        // ====================================================================
        dealii::SparseILU<double> preconditioner;
        typename dealii::SparseILU<double>::AdditionalData ilu_data;
        ilu_data.strengthen_diagonal = (params.ilu_strengthen > 0.0)
                                        ? params.ilu_strengthen : 1.2;
        ilu_data.extra_off_diagonals = 0;

        bool ilu_failed = false;
        try
        {
            preconditioner.initialize(matrix, ilu_data);
        }
        catch (const std::exception& e)
        {
            std::cerr << "[CH Solver] ILU initialization failed: " << e.what() << "\n";
            ilu_failed = true;
        }

        if (ilu_failed)
        {
            // ILU failed, fall back to direct immediately
            std::cerr << "[CH Solver] Falling back to direct solver (ILU failed).\n";

            dealii::SparseDirectUMFPACK direct_solver;
            direct_solver.initialize(matrix);
            direct_solver.vmult(coupled_solution, rhs);

            info.converged = true;
            info.iterations = 1;  // Direct solver = 1 "iteration"
            info.residual = 0.0;
            info.used_direct = true;

            // DEBUG: Verify iteration count
            std::cout << "[CH DEBUG] ILU fallback: info.iterations = " << info.iterations << "\n";
        }
        else
        {
            // ILU succeeded, try GMRES
            try
            {
                solver.solve(matrix, coupled_solution, rhs, preconditioner);
                info.converged = true;
                info.iterations = solver_control.last_step();
                info.residual = solver_control.last_value();

                // Check for NaN in solution
                if (!std::isfinite(info.residual) || !std::isfinite(coupled_solution.l2_norm()))
                {
                    std::cerr << "[CH Solver] WARNING: NaN detected in solution, falling back to direct\n";
                    info.converged = false;
                }
                else
                {
                    // DEBUG: Verify iteration count
                    std::cout << "[CH DEBUG] GMRES converged: info.iterations = " << info.iterations << "\n";
                }
            }
            catch (dealii::SolverControl::NoConvergence& e)
            {
                std::cerr << "[CH Solver] WARNING: GMRES did not converge after "
                          << e.last_step << " iterations. "
                          << "Residual = " << e.last_residual << "\n";

                info.iterations = e.last_step;  // Store GMRES iterations even though it failed
                info.residual = e.last_residual;
                info.converged = false;

                if (params.fallback_to_direct)
                    std::cerr << "[CH Solver] Falling back to direct solver.\n";
            }
        }
    }

    // Fallback to direct solver if iterative didn't converge (or wasn't used)
    if (!info.converged && params.fallback_to_direct)
    {
        dealii::SparseDirectUMFPACK direct_solver;
        direct_solver.initialize(matrix);
        direct_solver.vmult(coupled_solution, rhs);

        info.converged = true;
        info.iterations = 1;  // Direct solver = 1 "iteration"
        info.residual = 0.0;
        info.used_direct = true;

        // DEBUG: Verify iteration count
        std::cout << "[CH DEBUG] GMRES fallback to direct: info.iterations = " << info.iterations << "\n";
    }

    auto end = std::chrono::high_resolution_clock::now();
    info.solve_time = std::chrono::duration<double>(end - start).count();

    constraints.distribute(coupled_solution);

    // Extract individual solutions
    for (unsigned int i = 0; i < theta_solution.size(); ++i)
        theta_solution[i] = coupled_solution[theta_to_ch_map[i]];

    for (unsigned int i = 0; i < psi_solution.size(); ++i)
        psi_solution[i] = coupled_solution[psi_to_ch_map[i]];

    // DEBUG: Final verification before return
    std::cout << "[CH DEBUG] Final info.iterations = " << info.iterations
              << ", info.converged = " << info.converged
              << ", info.used_direct = " << info.used_direct << "\n";

    if (log_output || params.verbose)
    {
        std::cout << "[CH Solver] Size: " << matrix.m()
                  << ", nnz: " << matrix.n_nonzero_elements()
                  << ", iterations: " << info.iterations
                  << ", residual: " << std::scientific << std::setprecision(4) << info.residual
                  << ", time: " << std::fixed << std::setprecision(4) << info.solve_time << "s";
        if (info.used_direct)
            std::cout << " (DIRECT)";
        std::cout << "\n";
    }

    return info;
}

// ============================================================================
// Legacy interface with default parameters
// ============================================================================
SolverInfo solve_ch_system(
    const dealii::SparseMatrix<double>& matrix,
    const dealii::Vector<double>& rhs,
    const dealii::AffineConstraints<double>& constraints,
    const std::vector<dealii::types::global_dof_index>& theta_to_ch_map,
    const std::vector<dealii::types::global_dof_index>& psi_to_ch_map,
    dealii::Vector<double>& theta_solution,
    dealii::Vector<double>& psi_solution)
{
    // Default CH parameters (nonsymmetric: GMRES + ILU)
    LinearSolverParams default_params;
    default_params.type = LinearSolverParams::Type::GMRES;
    default_params.preconditioner = LinearSolverParams::Preconditioner::ILU;
    default_params.rel_tolerance = 1e-8;
    default_params.abs_tolerance = 1e-12;
    default_params.max_iterations = 2000;
    default_params.gmres_restart = 50;
    default_params.ilu_strengthen = 1.2;
    default_params.use_iterative = true;
    default_params.fallback_to_direct = true;
    default_params.verbose = false;

    return solve_ch_system(matrix, rhs, constraints,
                           theta_to_ch_map, psi_to_ch_map,
                           theta_solution, psi_solution,
                           default_params, /*log_output=*/true);
}