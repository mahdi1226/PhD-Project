// ============================================================================
// solvers/poisson_solver.h - Magnetostatic Poisson Solver
//
// Solver hierarchy (automatic selection):
//   1. CG + AMG (Trilinos ML) - if DEAL_II_WITH_TRILINOS, scalable O(n)
//   2. CG + SSOR - fallback, O(n²) for ill-conditioned
//   3. Direct (UMFPACK) - fallback if iterative fails
//
// AMG provides mesh-independent convergence: ~20-50 iterations regardless
// of problem size. SSOR degrades as O(h⁻²) requiring 1000+ iterations.
//
// Reference: Nochetto, Salgado & Tomas, CMAME 309 (2016) 497-531
// ============================================================================
#ifndef POISSON_SOLVER_H
#define POISSON_SOLVER_H

#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/vector.h>
#include <deal.II/lac/affine_constraints.h>

#include "solvers/solver_info.h"

// Forward declaration
struct LinearSolverParams;

/**
 * @brief Solve Poisson system with AMG preconditioning
 *
 * Automatically uses Trilinos ML AMG if available, otherwise SSOR.
 * Falls back to direct solver (UMFPACK) if iterative fails.
 *
 * Expected performance with AMG:
 *   - Iterations: 20-50 (independent of mesh size)
 *   - Setup time: ~1-2s (one-time)
 *   - Solve time: ~0.1-1s per solve
 *
 * @param matrix       System matrix (SPD Laplacian)
 * @param rhs          Right-hand side vector
 * @param solution     [IN/OUT] Solution vector (initial guess on input)
 * @param constraints  Affine constraints (hanging nodes, BCs)
 * @param params       Solver parameters
 * @param log_output   Print solver statistics
 * @return SolverInfo with iterations, residual, timing
 */
SolverInfo solve_poisson_system(
    const dealii::SparseMatrix<double>& matrix,
    const dealii::Vector<double>& rhs,
    dealii::Vector<double>& solution,
    const dealii::AffineConstraints<double>& constraints,
    const LinearSolverParams& params,
    bool log_output = true);

/**
 * @brief Legacy interface with default parameters
 *
 * Uses CG + AMG (if available) with:
 *   - rel_tolerance: 1e-8
 *   - max_iterations: 500
 *   - fallback_to_direct: true
 */
SolverInfo solve_poisson_system(
    const dealii::SparseMatrix<double>& matrix,
    const dealii::Vector<double>& rhs,
    dealii::Vector<double>& solution,
    const dealii::AffineConstraints<double>& constraints,
    bool verbose = true);

#endif // POISSON_SOLVER_H