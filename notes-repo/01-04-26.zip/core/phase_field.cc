// ============================================================================
// core/phase_field.cc - Phase Field Problem Main Implementation
//
// Contains run(), do_time_step(), and all solve methods.
//
// Time stepping follows Paper Algorithm 1:
//   1. Solve CH → θ^k, ψ^k
//   2. Solve Poisson → φ^k (H^k = ∇φ^k)
//   3. Solve Magnetization → M^k (DG transport) [if enabled]
//   4. Solve NS → u^k, p^k (uses θ^{k-1}, ψ^k, H^k, M^k)
//
// CRITICAL: θ is LAGGED in NS (θ^{k-1}) for energy stability!
//
// Reference: Nochetto, Salgado & Tomas, CMAME 309 (2016) 497-531
// ============================================================================

#include "core/phase_field.h"
#include "assembly/ch_assembler.h"
#include "assembly/poisson_assembler.h"
#include "assembly/ns_assembler.h"
#include "assembly/magnetization_assembler.h"
#include "solvers/ch_solver.h"
#include "solvers/poisson_solver.h"
#include "solvers/ns_solver.h"
#include "solvers/magnetization_solver.h"
#include "solvers/solver_info.h"
#include "utilities/tools.h"
#include "utilities/parameters.h"
#include "diagnostics/ch_diagnostics.h"
#include "diagnostics/poisson_diagnostics.h"
#include "diagnostics/ns_diagnostics.h"
#include "diagnostics/interface_tracking.h"
#include "diagnostics/force_diagnostics.h"
#include "diagnostics/field_diagnostics.h"
#include "physics/material_properties.h"
#include "physics/applied_field.h"
#include "setup/magnetization_setup.h"


#include <deal.II/numerics/data_out.h>
#include <deal.II/base/quadrature_lib.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/dofs/dof_tools.h>

#include <iostream>
#include <iomanip>
#include <fstream>
#include <filesystem>
#include <cmath>
#include <limits>
#include <algorithm>
#include <chrono>

// ============================================================================
// run() - Main entry point
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::run()
{
    std::cout << "============================================================\n";
    if (params_.enable_ns)
        std::cout << "  Ferrofluid Solver (CH + Poisson + NS)\n";
    else
        std::cout << "  Cahn-Hilliard Solver (Standalone Test)\n";
    std::cout << "  Reference: Nochetto et al. CMAME 309 (2016)\n";
    std::cout << "============================================================\n\n";

    // Create output directory with timestamp
    std::string output_dir = timestamped_folder(params_.output.folder, params_.output.run_name);
    std::filesystem::create_directories(output_dir);
    std::cout << "[Info] Output directory: " << output_dir << "\n\n";

    // Log run configuration for reproducibility
    write_run_info(output_dir, params_);
    std::cout << "[Config] " << get_flag_summary(params_) << "\n";

    // Store output directory for later use
    const_cast<Parameters&>(params_).output.folder = output_dir;
    // Store magnetic fields distribution
    field_logger_.open(output_dir + "/field_distribution.csv");
    if (params_.output.verbose)
        diagnose_applied_field();

    // Initialize metrics logger
    metrics_logger_ = std::make_unique<MetricsLogger>(output_dir, params_);
    metrics_logger_->write_header_stamp(params_);


    // ========================================================================
    // Setup
    // ========================================================================
    std::cout << "--- Setup Phase ---\n";
    setup_mesh();
    setup_dof_handlers();
    setup_constraints();
    setup_ch_system();
    if (params_.enable_magnetic)
    {
        setup_poisson_system();
        if (params_.use_dg_transport)
            setup_magnetization_system();
    }
    if (params_.enable_ns)
        setup_ns_system();
    initialize_solutions();

    // To check magnetic field distribution and configuration
    if (params_.output.verbose)
    {
        diagnose_applied_field(0.0);                        // At t=0
        diagnose_applied_field(params_.dipoles.ramp_time);  // At full ramp
    }

    const double h_min = get_min_h();
    std::cout << "[Info] Mesh h_min = " << h_min << "\n";

    // Print parameters
    std::cout << "\n--- Parameters ---\n";
    std::cout << "  epsilon = " << params_.physics.epsilon << "\n";
    std::cout << "  gamma   = " << params_.physics.mobility << "\n";
    std::cout << "  lambda  = " << params_.physics.lambda << "\n";
    std::cout << "  dt      = " << params_.time.dt << "\n";
    std::cout << "  t_final = " << params_.time.t_final << "\n";
    if (params_.enable_magnetic)
    {
        std::cout << "  Magnetic: ENABLED\n";
        std::cout << "  chi_0 (susceptibility) = " << params_.physics.chi_0 << "\n";
        if (params_.use_dg_transport)
            std::cout << "  DG transport: ENABLED (tau_M = " << params_.physics.tau_M << ")\n";
        else
            std::cout << "  DG transport: disabled (quasi-equilibrium M = chi*H)\n";
    }
    if (params_.enable_ns)
    {
        std::cout << "  Navier-Stokes: ENABLED\n";
        std::cout << "  nu_water = " << params_.physics.nu_water << "\n";
        std::cout << "  nu_ferro = " << params_.physics.nu_ferro << "\n";
        if (params_.enable_gravity)
            std::cout << "  Gravity: ENABLED (g = " << params_.physics.gravity << ")\n";
    }

    // ========================================================================
    // Initial field solve (to populate phi for output)
    // ========================================================================
    if (params_.enable_magnetic && !params_.use_reduced_magnetic_field)
        solve_poisson(); //Uses reduced magnetic for dome_setup()
    output_results(0);

    // ========================================================================
    // Time loop
    // ========================================================================
    std::cout << "\n--- Time Integration ---\n";
    ConsoleLogger::print_step_header();
    std::cout << std::setw(8) << "Step"
        << std::setw(12) << "Time"
        << std::setw(14) << "Mass"
        << std::setw(14) << "E_CH"
        << std::setw(14) << "E_kin" << "\n";
    std::cout << std::string(62, '-') << "\n";

    // ========================================================================
    // Adaptive time stepping parameters
    // ========================================================================
    const double dt_default = params_.time.dt;
    const double dt_min = 0.1 * dt_default;
    const double dt_max = 2.0 * dt_default;
    const double cfl_target = 0.5;
    const unsigned int gmres_struggling_threshold = 1200; // 80% of 1500 max
    const unsigned int gmres_easy_threshold = 50;
    const double energy_rate_threshold = 1e8;

    double current_dt = dt_default;
    unsigned int output_counter = 0;

    while (time_ < params_.time.t_final - 1e-12)
    {
        // Adjust for final time
        if (time_ + current_dt > params_.time.t_final)
            current_dt = params_.time.t_final - time_;

        time_step(current_dt);

        // Log magnetic field distribution
        auto field_data = compute_field_distribution(params_, time_, timestep_number_);
        field_logger_.write(field_data);

        // ====================================================================
        // Adaptive dt logic (after time_step computes diagnostics)
        // Only active when NS is enabled
        // ====================================================================
        if (params_.enable_ns && params_.time.use_adaptive_dt)
        {
            double dt_new = current_dt;
            double dt_changed = false;
            std::string reason;

            // 1. CFL-based adjustment
            const double cfl_current = last_step_data_.CFL;
            if (cfl_current > 1e-10)
            {
                double dt_cfl = current_dt * (cfl_target / cfl_current);
                dt_cfl = std::clamp(dt_cfl, dt_min, dt_max);
                if (dt_cfl < dt_new)
                {
                    dt_new = dt_cfl;
                    reason = "CFL=" + std::to_string(cfl_current);
                }
            }

            // 2. Solver struggling → reduce dt
            if (last_ns_gmres_iters_ > gmres_struggling_threshold)
            {
                double dt_solver = std::max(dt_min, 0.5 * current_dt);
                if (dt_solver < dt_new)
                {
                    dt_new = dt_solver;
                    reason = "GMRES=" + std::to_string(last_ns_gmres_iters_);
                    dt_changed = true;
                }
            }
            // Solver easy → can increase (only if below default)
            else if (last_ns_gmres_iters_ < gmres_easy_threshold &&
                last_ns_gmres_iters_ > 0 &&
                current_dt < dt_default)
            {
                dt_new = std::min(dt_default, 1.2 * current_dt);
                if (dt_new > current_dt)
                {
                    reason = "GMRES easy (" + std::to_string(last_ns_gmres_iters_) + ")";
                    dt_changed = true;
                }
            }

            // 3. Energy explosion guard
            if (std::abs(last_step_data_.dE_total_dt) > energy_rate_threshold)
            {
                double dt_energy = std::max(dt_min, 0.5 * current_dt);
                if (dt_energy < dt_new)
                {
                    dt_new = dt_energy;
                    reason = "dE/dt=" + std::to_string(last_step_data_.dE_total_dt);
                    dt_changed = true;
                }
            }

            // Apply bounds
            dt_new = std::clamp(dt_new, dt_min, dt_max);

            // Update dt for next step if changed significantly
            if (std::abs(dt_new - current_dt) / current_dt > 0.01)
            {
                if (params_.output.verbose)
                {
                    std::cout << "[Adaptive dt] " << std::scientific
                        << current_dt << " -> " << dt_new
                        << " (" << reason << ")\n";
                }
                current_dt = dt_new;
            }
        }

        // AMR: Refine mesh every amr_interval steps (Paper Section 6.1)
        if (params_.mesh.use_amr &&
            timestep_number_ % params_.mesh.amr_interval == 0 &&
            timestep_number_ > 0)
        {
            refine_mesh();
        }

        // Output periodically
        if (timestep_number_ % params_.output.frequency == 0 ||
            time_ >= params_.time.t_final - 1e-12)
        {
            ++output_counter;
            output_results(output_counter);

            // Use diagnostics already computed in time_step()
            std::cout << std::setw(8) << timestep_number_
                << std::setw(12) << std::fixed << std::setprecision(4) << time_
                << std::setw(14) << std::scientific << std::setprecision(4) << last_step_data_.mass
                << std::setw(14) << last_step_data_.E_CH
                << std::setw(14) << last_step_data_.E_kin << "\n";
        }
    }

    std::cout << "\n--- Simulation Complete ---\n";
    std::cout << "[Info] Final time: " << time_ << "\n";
    std::cout << "[Info] Total steps: " << timestep_number_ << "\n";

    std::cout << "[Info] Output saved to: " << params_.output.folder << "\n";
    field_logger_.close();
}

// ============================================================================
// do_time_step() - Single time step (staggered approach)
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::time_step(double dt)
{
    // ========================================================================
    // Save old solutions BEFORE Picard iteration (for lagging)
    // ========================================================================
    theta_old_solution_ = theta_solution_;

    if (params_.enable_ns)
    {
        ux_old_solution_ = ux_solution_;
        uy_old_solution_ = uy_solution_;
    }

    if (params_.enable_magnetic)
    {
        mx_old_solution_ = mx_solution_;
        my_old_solution_ = my_solution_;
    }

    const double time_new = time_ + dt;

    // ========================================================================
    // Initialize StepData
    // ========================================================================
    StepData step_data;
    step_data.step = timestep_number_;
    step_data.time = time_new;
    step_data.dt = dt;

    // ========================================================================
    // Picard iteration (Paper: Block-Gauss-Seidel)
    //
    // Scheme (42) is a fully coupled system. We solve it iteratively:
    //   Block 1: CH (42a-42b)
    //   Block 2: Magnetics (42c-42d)
    //   Block 3: NS (42e-42f)
    // ========================================================================
    const unsigned int n_picard = params_.picard_iterations;

    last_ns_gmres_iters_ = 0;

    for (unsigned int picard = 0; picard < n_picard; ++picard)
    {
        if (params_.output.verbose)
            std::cout << "[Picard " << picard << "] Solving CH...\n";

        solve_ch();

        if (params_.enable_magnetic)
        {
            if (params_.output.verbose)
                std::cout << "[Picard " << picard << "] Solving Magnetization...\n";
            solve_magnetization();

            if (params_.output.verbose)
                std::cout << "[Picard " << picard << "] Solving Poisson...\n";
            solve_poisson();
        }

        if (params_.enable_ns)
        {
            if (params_.output.verbose)
                std::cout << "[Picard " << picard << "] Solving NS...\n";
            solve_ns();
        }
    }

    // ========================================================================
    // Diagnostics (after Picard converged)
    // ========================================================================

    // CH diagnostics
    CHDiagnosticData ch_data = compute_ch_diagnostics<dim>(
        theta_dof_handler_, theta_solution_, params_,
        timestep_number_, time_new, dt, ch_energy_old_);


    step_data.theta_min = ch_data.theta_min;
    step_data.theta_max = ch_data.theta_max;
    step_data.mass = ch_data.mass;
    step_data.E_CH = ch_data.energy;
    step_data.dE_CH_dt = ch_data.energy_rate;
    step_data.ch_bounds_violated = ch_data.bounds_violated;
    step_data.ch_energy_increasing = ch_data.energy_increasing;

    // ===== DEBUG WALL 2 =====
    std::cout << "[DEBUG time_step] BEFORE copy: last_ch_info_.iterations="
        << last_ch_info_.iterations << "\n";
    // ========================


    ch_energy_old_ = ch_data.energy;
    step_data.ch_iterations = last_ch_info_.iterations;
    step_data.ch_residual = last_ch_info_.residual;
    step_data.ch_time = last_ch_info_.solve_time;

    // ===== DEBUG WALL 3 =====
    std::cout << "[DEBUG time_step] AFTER copy: step_data.ch_iterations="
        << step_data.ch_iterations << "\n";
    // ========================

    // Poisson diagnostics
    if (params_.enable_magnetic)
    {
        PoissonDiagnostics poisson_diag = compute_poisson_diagnostics<dim>(
            phi_dof_handler_, phi_solution_,
            theta_dof_handler_, theta_old_solution_,
            params_, time_new);

        step_data.phi_min = poisson_diag.phi_min;
        step_data.phi_max = poisson_diag.phi_max;
        step_data.H_max = poisson_diag.H_max;
        step_data.M_max = poisson_diag.M_max;
        step_data.E_mag = poisson_diag.magnetic_energy;
        step_data.mu_min = poisson_diag.mu_min;
        step_data.mu_max = poisson_diag.mu_max;
    }
    step_data.poisson_iterations = last_poisson_info_.iterations;
    step_data.poisson_residual = last_poisson_info_.residual;
    step_data.poisson_time = last_poisson_info_.solve_time;

    // NS diagnostics
    if (params_.enable_ns)
    {
        NSDiagnostics ns_diag = compute_ns_diagnostics<dim>(
            ux_dof_handler_, uy_dof_handler_, p_dof_handler_,
            ux_solution_, uy_solution_, p_solution_,
            dt, get_min_h());

        step_data.ux_min = ns_diag.ux_min;
        step_data.ux_max = ns_diag.ux_max;
        step_data.uy_min = ns_diag.uy_min;
        step_data.uy_max = ns_diag.uy_max;
        step_data.U_max = ns_diag.U_max;
        step_data.E_kin = ns_diag.kinetic_energy;
        step_data.divU_L2 = ns_diag.div_U_L2;
        step_data.divU_Linf = ns_diag.div_U_max;
        step_data.CFL = ns_diag.cfl;
        step_data.p_min = ns_diag.p_min;
        step_data.p_max = ns_diag.p_max;
    }

    /// Interface tracking (for Rosensweig instability)
    InterfacePosition interface_pos = compute_interface_position_robust<dim>(
        theta_dof_handler_, theta_solution_, false);

    step_data.interface_y_min = interface_pos.y_min;
    step_data.interface_y_max = interface_pos.y_max;
    step_data.interface_y_mean = interface_pos.y_mean;

    // Force diagnostics
    ForceDiagnostics force_data = compute_force_diagnostics<dim>(
        theta_dof_handler_, theta_solution_, psi_solution_,
        params_.enable_magnetic ? &phi_solution_ : nullptr,
        params_);

    step_data.F_cap_max = force_data.F_cap_max;
    step_data.F_mag_max = force_data.F_mag_max;
    step_data.F_grav_max = force_data.F_grav_max;

    // =========================================================================
    // Compute derived quantities and total energy
    // =========================================================================
    step_data.E_internal = step_data.E_CH + step_data.E_kin;
    step_data.E_total = step_data.E_CH + step_data.E_kin + step_data.E_mag;

    if (timestep_number_ > 0 && dt > 0)
    {
        step_data.dE_total_dt = (step_data.E_total - E_total_old_) / dt;
        step_data.dE_internal_dt = (step_data.E_internal - E_internal_old_) / dt;
    }
    E_total_old_ = step_data.E_total;
    E_internal_old_ = step_data.E_internal;

    step_data.compute_derived();

    // ========================================================================
    // Verbose energy stability warning (uses step_data, not member functions)
    // ========================================================================
    if (params_.output.verbose && params_.enable_magnetic)
    {
        static double E_total_prev = step_data.E_total;
        double dE = step_data.E_total - E_total_prev;

        bool ramp_complete = (time_new > params_.dipoles.ramp_time);

        if (dE > 1e-6 && timestep_number_ > 1 && ramp_complete)
        {
            std::cout << "[WARNING] Energy increased by " << std::scientific
                << dE << " at step " << timestep_number_
                << " t=" << time_new << " (post-ramp)\n";
            std::cout << "          E_CH=" << step_data.E_CH
                << " E_kin=" << step_data.E_kin
                << " E_mag=" << step_data.E_mag << "\n";
        }
        E_total_prev = step_data.E_total;
    }

    // ========================================================================
    // Logging
    // ========================================================================
    if (metrics_logger_)
        metrics_logger_->log_step(step_data);

    if (step_data.has_warnings())
        ConsoleLogger::print_warnings(step_data);

    // ========================================================================
    // Store step data for adaptive dt (accessible by run())
    // ========================================================================
    last_step_data_ = step_data;

    // ========================================================================
    // Update time
    // ========================================================================
    time_ = time_new;
    ++timestep_number_;
}

// ============================================================================
// solve_ch() - Solve Cahn-Hilliard system
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::solve_ch()
{
    const dealii::Vector<double>& ux_for_ch = params_.enable_ns ? ux_solution_ : ux_old_solution_;
    const dealii::Vector<double>& uy_for_ch = params_.enable_ns ? uy_solution_ : uy_old_solution_;

    ch_matrix_ = 0;
    ch_rhs_ = 0;

    assemble_ch_system<dim>(
        theta_dof_handler_,
        psi_dof_handler_,
        theta_old_solution_,
        ux_for_ch,
        uy_for_ch,
        params_,
        params_.time.dt,
        time_,
        theta_to_ch_map_,
        psi_to_ch_map_,
        ch_matrix_,
        ch_rhs_);

    ch_combined_constraints_.condense(ch_matrix_, ch_rhs_);

    SolverInfo ch_info = solve_ch_system(ch_matrix_, ch_rhs_,
                                         ch_combined_constraints_,
                                         theta_to_ch_map_, psi_to_ch_map_,
                                         theta_solution_, psi_solution_,
                                         params_.solvers.ch,
                                         params_.output.verbose);

    last_ch_info_ = ch_info; // Store for diagnostics

    // ===== DEBUG WALL 1 =====
    std::cout << "[DEBUG solve_ch] ch_info returned: iterations=" << ch_info.iterations
        << ", converged=" << ch_info.converged
        << ", used_direct=" << ch_info.used_direct << "\n";
    std::cout << "[DEBUG solve_ch] After copy: last_ch_info_.iterations="
        << last_ch_info_.iterations << "\n";
    // ========================

    // Debug: verify sizes before constraint distribution
    if (params_.output.verbose)
    {
        std::cout << "[CH Post-solve] theta_solution size: " << theta_solution_.size()
            << ", theta_dof n_dofs: " << theta_dof_handler_.n_dofs() << "\n";
        std::cout << "[CH Post-solve] psi_solution size: " << psi_solution_.size()
            << ", psi_dof n_dofs: " << psi_dof_handler_.n_dofs() << "\n";
        std::cout << "[CH Post-solve] Distributing theta constraints...\n";
    }

    Assert(theta_solution_.size() == theta_dof_handler_.n_dofs(),
           dealii::ExcDimensionMismatch(theta_solution_.size(), theta_dof_handler_.n_dofs()));
    theta_constraints_.distribute(theta_solution_);

    if (params_.output.verbose)
        std::cout << "[CH Post-solve] Distributing psi constraints...\n";

    Assert(psi_solution_.size() == psi_dof_handler_.n_dofs(),
           dealii::ExcDimensionMismatch(psi_solution_.size(), psi_dof_handler_.n_dofs()));
    psi_constraints_.distribute(psi_solution_);

    if (params_.output.verbose)
        std::cout << "[CH Post-solve] Constraints distributed successfully\n";
}

// ============================================================================
// solve_magnetization() - Compute magnetization
//
// QUASI-EQUILIBRIUM MODEL (τ_M → 0):
//   M = χ(θ) H  where H = ∇φ
//
// This is NOT the full DG transport equation (Eq. 42c). The flag
// `use_dg_transport` controls whether M is pre-computed and stored (true)
// or computed inline in NS assembler (false). Both give quasi-equilibrium.
//
// Full Eq. 42c: ∂M/∂t + B_h^m(U,Z,M) = (1/τ_M)(χH - M)
// is NOT YET IMPLEMENTED.
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::solve_magnetization()
{
    if (params_.output.verbose)
    {
        std::cout << "[Magnetization] Starting solve...\n";
        std::cout << "[Magnetization] mx_solution size: " << mx_solution_.size()
            << ", mx_dof n_dofs: " << mx_dof_handler_.n_dofs() << "\n";
    }

    auto start_time = std::chrono::high_resolution_clock::now();

    if (params_.physics.tau_M > 0.0)
    {
        // Full DG transport (Eq. 42c)
        MagnetizationAssembler<dim> assembler(
            params_, mx_dof_handler_, ux_dof_handler_,
            phi_dof_handler_, theta_dof_handler_);

        mx_matrix_ = 0;
        mx_rhs_ = 0;
        my_rhs_ = 0;

        assembler.assemble(mx_matrix_, mx_rhs_, my_rhs_,
                           ux_solution_, uy_solution_, phi_solution_,
                           theta_old_solution_, mx_old_solution_, my_old_solution_,
                           params_.time.dt, time_);

        MagnetizationSolver<dim> solver(params_.solvers.magnetization);
        solver.initialize(mx_matrix_);
        solver.solve(mx_solution_, mx_rhs_);
        solver.solve(my_solution_, my_rhs_);

        auto end_time = std::chrono::high_resolution_clock::now();
        double elapsed = std::chrono::duration<double>(end_time - start_time).count();

        if (params_.output.verbose)
        {
            std::cout << "[Magnetization] Size: " << mx_dof_handler_.n_dofs()
                << ", time: " << std::fixed << std::setprecision(4) << elapsed << "s"
                << " (DG transport, τ_M=" << std::scientific << params_.physics.tau_M << ")\n";
        }
    }
    else
    {
        // Quasi-equilibrium: M = χ(θ) H - use existing function
        initialize_magnetization_equilibrium<dim>(
            mx_dof_handler_,
            theta_dof_handler_,
            phi_dof_handler_,
            theta_old_solution_, // lagged θ
            phi_solution_, // current φ
            params_,
            mx_solution_,
            my_solution_);

        auto end_time = std::chrono::high_resolution_clock::now();
        double elapsed = std::chrono::duration<double>(end_time - start_time).count();

        if (params_.output.verbose)
        {
            std::cout << "[Magnetization] Size: " << mx_dof_handler_.n_dofs()
                << ", time: " << std::fixed << std::setprecision(4) << elapsed << "s"
                << " (quasi-equilibrium M=χH)\n";
        }
    }
}

// ============================================================================
// solve_poisson() - Solve magnetostatic Poisson equation (Paper Eq. 42d)
//
//   (∇φ, ∇χ) = (h_a - M^k, ∇χ)
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::solve_poisson()
{
    phi_matrix_ = 0;
    phi_rhs_ = 0;

    assemble_poisson_system<dim>(
        phi_dof_handler_,
        mx_dof_handler_,
        mx_solution_,
        my_solution_,
        params_,
        time_,
        phi_matrix_,
        phi_rhs_,
        phi_constraints_);

    last_poisson_info_ = solve_poisson_system(
        phi_matrix_, phi_rhs_, phi_solution_,
        phi_constraints_,
        params_.solvers.poisson,
        params_.output.verbose);
}

// ============================================================================
// solve_ns() - Solve Navier-Stokes system
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::solve_ns()
{
    ns_matrix_ = 0;
    ns_rhs_ = 0;

    Assert(ux_old_solution_.size() == ux_dof_handler_.n_dofs(), dealii::ExcInternalError());
    Assert(uy_old_solution_.size() == uy_dof_handler_.n_dofs(), dealii::ExcInternalError());
    Assert(theta_old_solution_.size() == theta_dof_handler_.n_dofs(), dealii::ExcInternalError());
    Assert(psi_solution_.size() == psi_dof_handler_.n_dofs(), dealii::ExcInternalError());
    if (params_.enable_magnetic)
    {
        Assert(phi_solution_.size() == phi_dof_handler_.n_dofs(), dealii::ExcInternalError());
    }

    assemble_ns_system<dim>(
        ux_dof_handler_,
        uy_dof_handler_,
        p_dof_handler_,
        theta_dof_handler_,
        psi_dof_handler_,
        params_.enable_magnetic ? &phi_dof_handler_ : nullptr,
        params_.enable_magnetic ? &mx_dof_handler_ : nullptr,
        ux_old_solution_,
        uy_old_solution_,
        theta_old_solution_,
        psi_solution_,
        params_.enable_magnetic ? &phi_solution_ : nullptr,
        params_.enable_magnetic ? &mx_solution_ : nullptr,
        params_.enable_magnetic ? &my_solution_ : nullptr,
        params_,
        params_.time.dt,
        time_,
        ux_to_ns_map_,
        uy_to_ns_map_,
        p_to_ns_map_,
        ns_combined_constraints_,
        ns_matrix_,
        ns_rhs_);


    SolverInfo ns_info;

    // Use FGMRES + Block Schur preconditioner (following deal.II step-56)
    // Use direct solver if:
    // 1. After AMR (use_direct_after_amr_), OR
    // 2. User requested direct solver (--direct flag)
    if (direct_solve_countdown_ > 0 || !params_.solvers.ns.use_iterative)
    {
        solve_ns_system_direct(
            ns_matrix_,
            ns_rhs_,
            ns_solution_,
            ns_combined_constraints_,
            params_.output.verbose);

        // Decrement counter (only if not user preference)
        if (direct_solve_countdown_ > 0)
        {
            --direct_solve_countdown_;
            if (params_.output.verbose && direct_solve_countdown_ == 0)
                std::cout << "[NS] AMR direct solve period complete, switching to Schur\n";
        }
    }
    else
    {
        if (!schur_preconditioner_)
        {
            // Use average viscosity for Schur scaling (helps convergence for variable nu)
            const double nu_avg = 0.5 * (params_.physics.nu_water + params_.physics.nu_ferro);
            schur_preconditioner_ = std::make_unique<BlockSchurPreconditioner>(
                ns_matrix_, pressure_mass_matrix_,
                ux_to_ns_map_, uy_to_ns_map_, p_to_ns_map_,
                false, // Just apply ILU (fast)
                nu_avg); // Viscosity scaling
        }
        else
        {
            schur_preconditioner_->update(ns_matrix_, pressure_mass_matrix_);
        }

        SolverInfo schur_info = solve_ns_system_schur(
            ns_matrix_, ns_rhs_, ns_solution_, ns_combined_constraints_,
            *schur_preconditioner_,
            params_.solvers.ns.max_iterations,
            params_.solvers.ns.rel_tolerance,
            params_.output.verbose);

        last_ns_gmres_iters_ = std::max(last_ns_gmres_iters_,
                                        static_cast<unsigned int>(schur_info.iterations));
    }

    extract_ns_solutions(
        ns_solution_,
        ux_to_ns_map_,
        uy_to_ns_map_,
        p_to_ns_map_,
        ux_solution_,
        uy_solution_,
        p_solution_);

    ux_constraints_.distribute(ux_solution_);
    uy_constraints_.distribute(uy_solution_);
    p_constraints_.distribute(p_solution_);
}

// ============================================================================
// output_results() - Write VTK output
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::output_results(unsigned int step) const
{
    // Theta
    {
        dealii::DataOut<dim> data_out;
        data_out.attach_dof_handler(theta_dof_handler_);
        data_out.add_data_vector(theta_solution_, "theta");
        data_out.build_patches();

        std::string filename = params_.output.folder + "/theta_" + std::to_string(step) + ".vtk";
        std::ofstream output(filename);
        data_out.write_vtk(output);
    }

    // Psi
    {
        dealii::DataOut<dim> data_out;
        data_out.attach_dof_handler(psi_dof_handler_);
        data_out.add_data_vector(psi_solution_, "psi");
        data_out.build_patches();

        std::string filename = params_.output.folder + "/psi_" + std::to_string(step) + ".vtk";
        std::ofstream output(filename);
        data_out.write_vtk(output);
    }

    // Phi (if magnetic)
    if (params_.enable_magnetic)
    {
        dealii::DataOut<dim> data_out;
        data_out.attach_dof_handler(phi_dof_handler_);
        data_out.add_data_vector(phi_solution_, "phi");
        data_out.build_patches();

        std::string filename = params_.output.folder + "/phi_" + std::to_string(step) + ".vtk";
        std::ofstream output(filename);
        data_out.write_vtk(output);

        // Mx, My (if DG transport)
        if (params_.use_dg_transport)
        {
            {
                dealii::DataOut<dim> data_out_mx;
                data_out_mx.attach_dof_handler(mx_dof_handler_);
                data_out_mx.add_data_vector(mx_solution_, "Mx",
                                            dealii::DataOut<dim>::type_dof_data);
                data_out_mx.build_patches();

                std::string fn = params_.output.folder + "/mx_" + std::to_string(step) + ".vtk";
                std::ofstream out(fn);
                data_out_mx.write_vtk(out);
            }
            {
                dealii::DataOut<dim> data_out_my;
                data_out_my.attach_dof_handler(my_dof_handler_);
                data_out_my.add_data_vector(my_solution_, "My",
                                            dealii::DataOut<dim>::type_dof_data);
                data_out_my.build_patches();

                std::string fn = params_.output.folder + "/my_" + std::to_string(step) + ".vtk";
                std::ofstream out(fn);
                data_out_my.write_vtk(out);
            }
        }
    }

    // Velocity and pressure (if NS)
    if (params_.enable_ns)
    {
        {
            dealii::DataOut<dim> data_out;
            data_out.attach_dof_handler(ux_dof_handler_);
            data_out.add_data_vector(ux_solution_, "ux");
            data_out.build_patches();

            std::string filename = params_.output.folder + "/ux_" + std::to_string(step) + ".vtk";
            std::ofstream output(filename);
            data_out.write_vtk(output);
        }
        {
            dealii::DataOut<dim> data_out;
            data_out.attach_dof_handler(uy_dof_handler_);
            data_out.add_data_vector(uy_solution_, "uy");
            data_out.build_patches();

            std::string filename = params_.output.folder + "/uy_" + std::to_string(step) + ".vtk";
            std::ofstream output(filename);
            data_out.write_vtk(output);
        }
        {
            dealii::DataOut<dim> data_out;
            data_out.attach_dof_handler(p_dof_handler_);
            data_out.add_data_vector(p_solution_, "pressure");
            data_out.build_patches();

            std::string filename = params_.output.folder + "/pressure_" + std::to_string(step) + ".vtk";
            std::ofstream output(filename);
            data_out.write_vtk(output);
        }
    }
}

// ============================================================================
// diagnose_applied_field() - Debug output for applied magnetic field
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::diagnose_applied_field(double time) const
{
    if (!params_.enable_magnetic || params_.dipoles.positions.empty())
        return;

    std::cout << "\n[Dipole Diagnostic] h_a at y=" << params_.ic.pool_depth
              << ", t=" << time << ":\n";

    const double y_sample = params_.ic.pool_depth;
    std::vector<double> x_samples = {0.1, 0.3, 0.5, 0.7, 0.9};

    for (double x : x_samples)
    {
        dealii::Point<dim> p(x, y_sample);
        auto h_a = compute_applied_field<dim>(p, params_, time);
        std::cout << "  x=" << x << ": |h_a|=" << h_a.norm()
                  << ", h_a=(" << h_a[0] << ", " << h_a[1] << ")\n";
    }
    std::cout << "\n";
}

// ============================================================================
// Explicit instantiation
// ============================================================================
template class PhaseFieldProblem<2>;
