// ============================================================================
// core/phase_field_amr.cc - Adaptive Mesh Refinement for PhaseFieldProblem
//
// Reference: Nochetto, Salgado & Tomas, CMAME 309 (2016) 497-531
// Section 6.1, Eq. 99 (Kelly-type error indicator)
//
// CRITICAL FIX (2026-01-04):
// After AMR, ψ must be REPROJECTED from θ, not interpolated!
// ψ = f'(θ) - ε²Δθ is a constitutive relation, not an independent variable.
// Interpolating ψ breaks this relation and causes spurious capillary forces.
//
// COARSENING FIX (2026-01-04):
// Paper Fig. 2 shows aggressive coarsening AWAY from interface, but
// "approximately 20 elements of the finest level resolving the transition layer."
// We enforce:
//   1. Interface protection: |θ| < 0.99 → never coarsen, ensure min refinement
//   2. Maximum coarsening rate: ≤10% cell reduction per AMR cycle
// ============================================================================

#include "core/phase_field.h"

#include <deal.II/base/quadrature_lib.h>       // QGauss
#include <deal.II/grid/grid_refinement.h>
#include <deal.II/numerics/solution_transfer.h>
#include <deal.II/numerics/error_estimator.h>  // KellyErrorEstimator (Paper Eq. 99)
#include <deal.II/lac/precondition.h>
#include <deal.II/lac/solver_cg.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/lac/dynamic_sparsity_pattern.h>
#include <deal.II/dofs/dof_tools.h>

#include <iostream>
#include <memory>
#include <limits>
#include <algorithm>

// ============================================================================
// reproject_psi_from_theta()
//
// After mesh transfer, ψ must be recomputed from θ via L² projection.
// The constitutive relation is: ψ = f'(θ) - ε²Δθ
//
// Weak form (projection): Find ψ_h ∈ V_h such that ∀v_h ∈ V_h:
//   (ψ_h, v_h) = (f'(θ_h), v_h) + ε² (∇θ_h, ∇v_h)
//
// This is a mass matrix solve: M ψ = b
// where b_i = ∫ f'(θ_h) φ_i dx + ε² ∫ ∇θ_h · ∇φ_i dx
//
// Note: f'(θ) = θ³ - θ for standard double-well potential W(θ) = ¼(θ²-1)²
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::reproject_psi_from_theta()
{
    if (params_.output.verbose)
        std::cout << "[AMR] Reprojecting ψ from θ (constitutive relation)...\n";

    const unsigned int n_psi = psi_dof_handler_.n_dofs();
    const double eps = params_.physics.epsilon;
    const double eps2 = eps * eps;

    // Setup quadrature and FEValues
    const dealii::QGauss<dim> quadrature(fe_Q2_.degree + 1);
    dealii::FEValues<dim> fe_values(fe_Q2_, quadrature,
                                    dealii::update_values |
                                    dealii::update_gradients |
                                    dealii::update_JxW_values |
                                    dealii::update_quadrature_points);

    const unsigned int dofs_per_cell = fe_Q2_.n_dofs_per_cell();
    const unsigned int n_q_points = quadrature.size();

    // Local matrices and vectors
    dealii::FullMatrix<double> cell_mass(dofs_per_cell, dofs_per_cell);
    dealii::Vector<double> cell_rhs(dofs_per_cell);

    std::vector<dealii::types::global_dof_index> local_dof_indices(dofs_per_cell);

    // Storage for θ values and gradients at quadrature points
    std::vector<double> theta_values(n_q_points);
    std::vector<dealii::Tensor<1, dim>> theta_gradients(n_q_points);

    // Global mass matrix and RHS
    // We'll use the existing psi sparsity pattern or create a simple one
    dealii::DynamicSparsityPattern dsp(n_psi, n_psi);
    dealii::DoFTools::make_sparsity_pattern(psi_dof_handler_, dsp, psi_constraints_, false);
    dealii::SparsityPattern mass_sparsity;
    mass_sparsity.copy_from(dsp);

    dealii::SparseMatrix<double> mass_matrix(mass_sparsity);
    dealii::Vector<double> rhs(n_psi);
    dealii::Vector<double> psi_new(n_psi);

    // Assemble mass matrix and RHS
    for (const auto& cell : psi_dof_handler_.active_cell_iterators())
    {
        fe_values.reinit(cell);
        cell_mass = 0;
        cell_rhs = 0;

        cell->get_dof_indices(local_dof_indices);

        // Get θ values and gradients at quadrature points
        // Note: θ and ψ share the same FE space (Q2), so we can use psi_dof_handler
        // but we need to get values from theta_solution_
        // Since they share the same mesh and element, DoF numbering is identical
        for (unsigned int q = 0; q < n_q_points; ++q)
        {
            theta_values[q] = 0.0;
            theta_gradients[q] = 0.0;
            for (unsigned int i = 0; i < dofs_per_cell; ++i)
            {
                theta_values[q] += theta_solution_[local_dof_indices[i]] *
                                   fe_values.shape_value(i, q);
                theta_gradients[q] += theta_solution_[local_dof_indices[i]] *
                                      fe_values.shape_grad(i, q);
            }
        }

        // Assemble local contributions
        for (unsigned int q = 0; q < n_q_points; ++q)
        {
            const double JxW = fe_values.JxW(q);
            const double theta_q = theta_values[q];
            const dealii::Tensor<1, dim>& grad_theta_q = theta_gradients[q];

            // f'(θ) = θ³ - θ for double-well potential
            const double f_prime = theta_q * theta_q * theta_q - theta_q;

            for (unsigned int i = 0; i < dofs_per_cell; ++i)
            {
                const double phi_i = fe_values.shape_value(i, q);
                const dealii::Tensor<1, dim>& grad_phi_i = fe_values.shape_grad(i, q);

                // RHS: (f'(θ), φ_i) + ε² (∇θ, ∇φ_i)
                cell_rhs(i) += (f_prime * phi_i + eps2 * (grad_theta_q * grad_phi_i)) * JxW;

                // Mass matrix: (φ_j, φ_i)
                for (unsigned int j = 0; j < dofs_per_cell; ++j)
                {
                    cell_mass(i, j) += phi_i * fe_values.shape_value(j, q) * JxW;
                }
            }
        }

        // Distribute to global
        psi_constraints_.distribute_local_to_global(cell_mass, cell_rhs,
                                                    local_dof_indices,
                                                    mass_matrix, rhs);
    }

    // Solve M ψ = b using CG (mass matrix is SPD)
    dealii::SolverControl solver_control(1000, 1e-12 * rhs.l2_norm());
    dealii::SolverCG<dealii::Vector<double>> cg(solver_control);
    dealii::PreconditionSSOR<dealii::SparseMatrix<double>> preconditioner;
    preconditioner.initialize(mass_matrix, 1.2);

    psi_new = 0;
    cg.solve(mass_matrix, psi_new, rhs, preconditioner);

    // Apply constraints and copy to solution
    psi_constraints_.distribute(psi_new);
    psi_solution_ = psi_new;

    if (params_.output.verbose)
        std::cout << "[AMR] ψ reprojection: " << solver_control.last_step()
                  << " CG iterations\n";
}


template <int dim>
void PhaseFieldProblem<dim>::refine_mesh()
{
    // =========================================================================
    // Check if AMR is enabled
    // =========================================================================
    // Validate parameters (even if AMR disabled, catch config errors)
    Assert(params_.mesh.interface_coarsen_threshold > 0.0 &&
           params_.mesh.interface_coarsen_threshold < 1.0,
           dealii::ExcMessage("interface_coarsen_threshold must be in (0,1)"));
    if (!params_.mesh.use_amr)
    {
        return;
    }

    if (params_.output.verbose)
        std::cout << "[AMR] Starting mesh refinement...\n";

    // =========================================================================
    // Step 1: Compute refinement indicators using Kelly error estimator
    //
    // Paper Eq. 99: η²_T = h_T ∫_{∂T} [[∂Θ/∂n]]² dS
    //
    // This measures the jump in normal derivative of θ across cell faces.
    // KellyErrorEstimator::estimate() computes exactly this indicator.
    // The h_T scaling is built into KellyErrorEstimator.
    // =========================================================================
    dealii::Vector<float> indicators(triangulation_.n_active_cells());

    // Use θ (phase field) for error estimation, as specified in Paper Eq. 99
    dealii::KellyErrorEstimator<dim>::estimate(
        theta_dof_handler_,
        dealii::QGauss<dim - 1>(theta_dof_handler_.get_fe().degree + 1),
        {},                    // No Neumann boundaries for error estimation
        theta_solution_,
        indicators);

    // =========================================================================
    // Step 2: Mark cells for refinement and coarsening
    // Using Dörfler/bulk-chasing marking strategy (Paper Section 6.1)
    //
    // Paper note: "marking for refinement and coarsening (a judiciously SMALL
    // fraction)" - we use conservative coarsening (0.01-0.03)
    // =========================================================================
    dealii::GridRefinement::refine_and_coarsen_fixed_fraction(
        triangulation_,
        indicators,
        params_.mesh.amr_upper_fraction,   // 0.3 (refine)
        params_.mesh.amr_lower_fraction);  // 0.01-0.03 (coarsen - conservative!)

    // Enforce min/max refinement levels
    for (const auto& cell : triangulation_.active_cell_iterators())
    {
        if (cell->level() >= static_cast<int>(params_.mesh.amr_max_level))
            cell->clear_refine_flag();
        if (cell->level() <= static_cast<int>(params_.mesh.amr_min_level))
            cell->clear_coarsen_flag();
    }

    // =========================================================================
    // Step 2b: Enhanced interface protection
    //
    // Paper Fig. 2: "approximately 20 elements of the finest level resolving
    // the transition layer" - this means we must NEVER coarsen near interface!
    //
    // Paper Fig. 3 warning: "with the coarsest mesh the numerical solution
    // exhibits artificial features which do not survive additional refinement"
    //
    // Protection strategy:
    //   1. |θ| < 0.99 (entire transition region) → never coarsen
    //   2. Ensure at least initial_refinement level near interface
    //   3. Limit total coarsening to max 10% of cells (Dörfler "small fraction")
    // =========================================================================
    std::vector<dealii::types::global_dof_index> dof_indices(
        theta_dof_handler_.get_fe().n_dofs_per_cell());

    // Compute minimum refinement level needed for interface resolution
    // Paper requires ~20 elements across interface of width O(ε)
    // h ≤ ε / 3 means we need sufficient refinement
    const unsigned int interface_min_level = std::max(
        params_.mesh.amr_min_level,
        static_cast<unsigned int>(params_.mesh.initial_refinement));

    // Use stricter threshold: 0.99 protects entire transition region
    // tanh profile: |θ| = 0.99 corresponds to ~2.65ε from interface center
    // This ensures the ENTIRE diffuse interface band is protected
    const double interface_threshold = 0.99;

    unsigned int n_interface_cells_protected = 0;

    for (const auto& cell : theta_dof_handler_.active_cell_iterators())
    {
        cell->get_dof_indices(dof_indices);

        double min_abs_theta = std::numeric_limits<double>::max();
        for (const auto idx : dof_indices)
        {
            // Clamp to handle overshoot (θ can exceed ±1 slightly)
            const double v = std::min(std::abs(theta_solution_[idx]), 1.0);
            min_abs_theta = std::min(min_abs_theta, v);
        }

        // Near interface: |θ| < threshold (0.99 = entire transition region)
        if (min_abs_theta < interface_threshold)
        {
            // Never coarsen near interface
            cell->clear_coarsen_flag();
            ++n_interface_cells_protected;

            // Ensure minimum refinement level near interface
            if (cell->level() < static_cast<int>(interface_min_level))
            {
                cell->set_refine_flag();
            }
        }
    }

    // =========================================================================
    // Step 2c: Limit maximum coarsening rate
    //
    // Paper's "judiciously small fraction" for coarsening means the actual
    // mesh reduction should be small (e.g., 10%), not just the parameter value.
    //
    // Problem: fixed_fraction operates on ERROR fraction, not cell fraction.
    // With most cells having |θ| ≈ ±1 (near-zero error), even small error
    // fractions can flag MANY cells for coarsening.
    //
    // Solution: After marking, count flagged cells and clear excess flags
    // if coarsening would be too aggressive.
    // =========================================================================
    const double max_coarsen_rate = 0.10;  // Maximum 10% cell reduction per cycle

    unsigned int n_coarsen_flagged = 0;
    for (const auto& cell : triangulation_.active_cell_iterators())
    {
        if (cell->coarsen_flag_set())
            ++n_coarsen_flagged;
    }

    const unsigned int n_active = triangulation_.n_active_cells();
    const double coarsen_rate = static_cast<double>(n_coarsen_flagged) / n_active;

    if (coarsen_rate > max_coarsen_rate)
    {
        if (params_.output.verbose)
            std::cout << "[AMR] Coarsening rate " << (coarsen_rate * 100.0)
                      << "% exceeds limit (" << (max_coarsen_rate * 100.0)
                      << "%), clearing excess coarsen flags\n";

        // Strategy: Clear coarsen flags on cells with LARGEST error indicators
        // (i.e., keep coarsening only the cells with smallest errors)
        //
        // Simple approach: Clear ALL excess coarsen flags randomly
        // Better approach: Sort by error and keep only lowest-error cells

        // For robustness, we'll clear flags on cells that aren't at minimum level
        // and have larger error indicators (approximated by clearing newer flags)

        const unsigned int max_coarsen_cells =
            static_cast<unsigned int>(max_coarsen_rate * n_active);

        // Collect cells flagged for coarsening with their error indicators
        std::vector<std::pair<float, typename dealii::Triangulation<dim>::active_cell_iterator>>
            coarsen_candidates;

        unsigned int cell_idx = 0;
        for (auto cell = triangulation_.begin_active();
             cell != triangulation_.end(); ++cell, ++cell_idx)
        {
            if (cell->coarsen_flag_set())
            {
                coarsen_candidates.emplace_back(indicators[cell_idx], cell);
            }
        }

        // Sort by error indicator (ascending) - keep lowest error cells for coarsening
        std::sort(coarsen_candidates.begin(), coarsen_candidates.end(),
                  [](const auto& a, const auto& b) { return a.first < b.first; });

        // Clear flags on cells beyond the limit (those with larger errors)
        for (unsigned int i = max_coarsen_cells; i < coarsen_candidates.size(); ++i)
        {
            coarsen_candidates[i].second->clear_coarsen_flag();
        }

        if (params_.output.verbose)
        {
            std::cout << "[AMR] Reduced coarsening from " << n_coarsen_flagged
                      << " to " << max_coarsen_cells << " cells\n";
        }
    }

    // =========================================================================
    // Summary of marking (verbose output)
    // =========================================================================
    if (params_.output.verbose)
    {
        unsigned int n_refine = 0, n_coarsen = 0;
        for (const auto& cell : triangulation_.active_cell_iterators())
        {
            if (cell->refine_flag_set()) ++n_refine;
            if (cell->coarsen_flag_set()) ++n_coarsen;
        }
        std::cout << "[AMR] Marking: " << n_refine << " refine, "
                  << n_coarsen << " coarsen, "
                  << n_interface_cells_protected << " interface-protected\n";
    }

    // Check if any mesh changes will happen
    bool any_change = false;
    for (const auto& cell : triangulation_.active_cell_iterators())
    {
        if (cell->refine_flag_set() || cell->coarsen_flag_set())
        {
            any_change = true;
            break;
        }
    }

    if (!any_change)
    {
        if (params_.output.verbose)
            std::cout << "[AMR] No mesh changes needed\n";
        return;
    }

    const unsigned int old_n_cells = triangulation_.n_active_cells();

    // =========================================================================
    // Step 3: Create SolutionTransfer objects for all ENABLED solution vectors
    //
    // NOTE: We do NOT create a transfer for ψ - it will be reprojected!
    // =========================================================================

    // Cahn-Hilliard θ (always enabled)
    dealii::SolutionTransfer<dim, dealii::Vector<double>> theta_transfer(theta_dof_handler_);
    dealii::SolutionTransfer<dim, dealii::Vector<double>> theta_old_transfer(theta_dof_handler_);
    // NO psi_transfer - ψ will be reprojected from θ!

    // Poisson (only if magnetic enabled)
    std::unique_ptr<dealii::SolutionTransfer<dim, dealii::Vector<double>>> phi_transfer;
    if (params_.enable_magnetic)
    {
        phi_transfer = std::make_unique<dealii::SolutionTransfer<dim, dealii::Vector<double>>>(phi_dof_handler_);
    }

    // Magnetization DG (only if magnetic + DG transport enabled)
    std::unique_ptr<dealii::SolutionTransfer<dim, dealii::Vector<double>>> mx_transfer;
    std::unique_ptr<dealii::SolutionTransfer<dim, dealii::Vector<double>>> my_transfer;
    std::unique_ptr<dealii::SolutionTransfer<dim, dealii::Vector<double>>> mx_old_transfer;
    std::unique_ptr<dealii::SolutionTransfer<dim, dealii::Vector<double>>> my_old_transfer;
    if (params_.enable_magnetic && params_.use_dg_transport)
    {
        mx_transfer = std::make_unique<dealii::SolutionTransfer<dim, dealii::Vector<double>>>(mx_dof_handler_);
        my_transfer = std::make_unique<dealii::SolutionTransfer<dim, dealii::Vector<double>>>(my_dof_handler_);
        mx_old_transfer = std::make_unique<dealii::SolutionTransfer<dim, dealii::Vector<double>>>(mx_dof_handler_);
        my_old_transfer = std::make_unique<dealii::SolutionTransfer<dim, dealii::Vector<double>>>(my_dof_handler_);
    }

    // Navier-Stokes (only if NS enabled)
    std::unique_ptr<dealii::SolutionTransfer<dim, dealii::Vector<double>>> ux_transfer;
    std::unique_ptr<dealii::SolutionTransfer<dim, dealii::Vector<double>>> uy_transfer;
    std::unique_ptr<dealii::SolutionTransfer<dim, dealii::Vector<double>>> ux_old_transfer;
    std::unique_ptr<dealii::SolutionTransfer<dim, dealii::Vector<double>>> uy_old_transfer;
    std::unique_ptr<dealii::SolutionTransfer<dim, dealii::Vector<double>>> p_transfer;
    if (params_.enable_ns)
    {
        ux_transfer = std::make_unique<dealii::SolutionTransfer<dim, dealii::Vector<double>>>(ux_dof_handler_);
        uy_transfer = std::make_unique<dealii::SolutionTransfer<dim, dealii::Vector<double>>>(uy_dof_handler_);
        ux_old_transfer = std::make_unique<dealii::SolutionTransfer<dim, dealii::Vector<double>>>(ux_dof_handler_);
        uy_old_transfer = std::make_unique<dealii::SolutionTransfer<dim, dealii::Vector<double>>>(uy_dof_handler_);
        p_transfer = std::make_unique<dealii::SolutionTransfer<dim, dealii::Vector<double>>>(p_dof_handler_);
    }

    // =========================================================================
    // Step 4: Prepare for coarsening and refinement
    // =========================================================================
    triangulation_.prepare_coarsening_and_refinement();

    // CH θ (always) - NO ψ preparation!
    theta_transfer.prepare_for_coarsening_and_refinement(theta_solution_);
    theta_old_transfer.prepare_for_coarsening_and_refinement(theta_old_solution_);

    // Poisson (if magnetic)
    if (params_.enable_magnetic)
    {
        phi_transfer->prepare_for_coarsening_and_refinement(phi_solution_);
    }

    // Magnetization (if magnetic + DG)
    if (params_.enable_magnetic && params_.use_dg_transport)
    {
        mx_transfer->prepare_for_coarsening_and_refinement(mx_solution_);
        my_transfer->prepare_for_coarsening_and_refinement(my_solution_);
        mx_old_transfer->prepare_for_coarsening_and_refinement(mx_old_solution_);
        my_old_transfer->prepare_for_coarsening_and_refinement(my_old_solution_);
    }

    // NS (if enabled)
    if (params_.enable_ns)
    {
        ux_transfer->prepare_for_coarsening_and_refinement(ux_solution_);
        uy_transfer->prepare_for_coarsening_and_refinement(uy_solution_);
        ux_old_transfer->prepare_for_coarsening_and_refinement(ux_old_solution_);
        uy_old_transfer->prepare_for_coarsening_and_refinement(uy_old_solution_);
        p_transfer->prepare_for_coarsening_and_refinement(p_solution_);
    }

    // =========================================================================
    // Step 5: Execute refinement
    // =========================================================================
    triangulation_.execute_coarsening_and_refinement();

    const unsigned int new_n_cells = triangulation_.n_active_cells();
    const double cell_change_percent = 100.0 * (static_cast<double>(new_n_cells) - old_n_cells) / old_n_cells;

    if (params_.output.verbose)
        std::cout << "[AMR] Cells: " << old_n_cells << " -> " << new_n_cells
                  << " (" << std::showpos << cell_change_percent << std::noshowpos << "%)\n";

    // =========================================================================
    // Step 6: Setup systems on new mesh
    // =========================================================================
    setup_dof_handlers();
    setup_constraints();

    // Reinitialize sparsity patterns and matrices
    setup_ch_system();
    if (params_.enable_magnetic)
    {
        setup_poisson_system();
        if (params_.use_dg_transport)
            setup_magnetization_system();
    }
    if (params_.enable_ns)
        setup_ns_system();

    // =========================================================================
    // Step 7: Interpolate solutions to new mesh
    // =========================================================================

    // θ (always)
    {
        dealii::Vector<double> tmp(theta_dof_handler_.n_dofs());
        theta_transfer.interpolate(tmp);
        theta_solution_ = tmp;
    }
    {
        dealii::Vector<double> tmp(theta_dof_handler_.n_dofs());
        theta_old_transfer.interpolate(tmp);
        theta_old_solution_ = tmp;
    }

    // =========================================================================
    // Enforce maximum principle for phase field after interpolation
    // (Interpolation can create Gibbs-like oscillations near interface)
    // =========================================================================
    for (unsigned int i = 0; i < theta_solution_.size(); ++i)
    {
        theta_solution_(i) = std::max(-1.0, std::min(1.0, theta_solution_(i)));
        theta_old_solution_(i) = std::max(-1.0, std::min(1.0, theta_old_solution_(i)));
    }

    // =========================================================================
    // CRITICAL FIX: Reproject ψ from θ instead of interpolating!
    //
    // The constitutive relation ψ = f'(θ) - ε²Δθ must hold on the NEW mesh.
    // Simple interpolation of ψ breaks this relation, causing:
    //   - Spurious capillary forces (F_cap explosion)
    //   - θ bounds violations
    //   - Energy instability
    //
    // The fix is to solve the L² projection problem:
    //   (ψ_h, v_h) = (f'(θ_h), v_h) + ε² (∇θ_h, ∇v_h)
    // =========================================================================
    reproject_psi_from_theta();

    // φ (if magnetic)
    if (params_.enable_magnetic)
    {
        dealii::Vector<double> tmp(phi_dof_handler_.n_dofs());
        phi_transfer->interpolate(tmp);
        phi_solution_ = tmp;
    }

    // M_x, M_y (if magnetic + DG)
    if (params_.enable_magnetic && params_.use_dg_transport)
    {
        {
            dealii::Vector<double> tmp(mx_dof_handler_.n_dofs());
            mx_transfer->interpolate(tmp);
            mx_solution_ = tmp;
        }
        {
            dealii::Vector<double> tmp(mx_dof_handler_.n_dofs());
            mx_old_transfer->interpolate(tmp);
            mx_old_solution_ = tmp;
        }
        {
            dealii::Vector<double> tmp(my_dof_handler_.n_dofs());
            my_transfer->interpolate(tmp);
            my_solution_ = tmp;
        }
        {
            dealii::Vector<double> tmp(my_dof_handler_.n_dofs());
            my_old_transfer->interpolate(tmp);
            my_old_solution_ = tmp;
        }
    }

    // u_x, u_y, p (if NS)
    if (params_.enable_ns)
    {
        {
            dealii::Vector<double> tmp(ux_dof_handler_.n_dofs());
            ux_transfer->interpolate(tmp);
            ux_solution_ = tmp;
        }
        {
            dealii::Vector<double> tmp(ux_dof_handler_.n_dofs());
            ux_old_transfer->interpolate(tmp);
            ux_old_solution_ = tmp;
        }
        {
            dealii::Vector<double> tmp(uy_dof_handler_.n_dofs());
            uy_transfer->interpolate(tmp);
            uy_solution_ = tmp;
        }
        {
            dealii::Vector<double> tmp(uy_dof_handler_.n_dofs());
            uy_old_transfer->interpolate(tmp);
            uy_old_solution_ = tmp;
        }
        {
            dealii::Vector<double> tmp(p_dof_handler_.n_dofs());
            p_transfer->interpolate(tmp);
            p_solution_ = tmp;
        }
    }

    // =========================================================================
    // Step 8: Apply constraints to ensure consistency
    // =========================================================================
    if (params_.output.verbose)
        std::cout << "[AMR] Applying constraints...\n";

    // Verify sizes before constraint distribution
    Assert(theta_solution_.size() == theta_dof_handler_.n_dofs(),
           dealii::ExcDimensionMismatch(theta_solution_.size(), theta_dof_handler_.n_dofs()));
    Assert(theta_old_solution_.size() == theta_dof_handler_.n_dofs(),
           dealii::ExcDimensionMismatch(theta_old_solution_.size(), theta_dof_handler_.n_dofs()));
    Assert(psi_solution_.size() == psi_dof_handler_.n_dofs(),
           dealii::ExcDimensionMismatch(psi_solution_.size(), psi_dof_handler_.n_dofs()));

    theta_constraints_.distribute(theta_solution_);
    theta_constraints_.distribute(theta_old_solution_);
    // psi_constraints already applied in reproject_psi_from_theta()

    if (params_.enable_magnetic)
    {
        Assert(phi_solution_.size() == phi_dof_handler_.n_dofs(),
               dealii::ExcDimensionMismatch(phi_solution_.size(), phi_dof_handler_.n_dofs()));
        phi_constraints_.distribute(phi_solution_);
    }

    if (params_.enable_ns)
    {
        Assert(ux_solution_.size() == ux_dof_handler_.n_dofs(),
               dealii::ExcDimensionMismatch(ux_solution_.size(), ux_dof_handler_.n_dofs()));
        Assert(uy_solution_.size() == uy_dof_handler_.n_dofs(),
               dealii::ExcDimensionMismatch(uy_solution_.size(), uy_dof_handler_.n_dofs()));
        Assert(p_solution_.size() == p_dof_handler_.n_dofs(),
               dealii::ExcDimensionMismatch(p_solution_.size(), p_dof_handler_.n_dofs()));

        ux_constraints_.distribute(ux_solution_);
        ux_constraints_.distribute(ux_old_solution_);
        uy_constraints_.distribute(uy_solution_);
        uy_constraints_.distribute(uy_old_solution_);
        p_constraints_.distribute(p_solution_);
    }

    if (params_.output.verbose)
    {
        std::cout << "[AMR] New DoFs: theta=" << theta_dof_handler_.n_dofs();
        if (params_.enable_ns)
            std::cout << ", ux=" << ux_dof_handler_.n_dofs()
                << ", p=" << p_dof_handler_.n_dofs();
        std::cout << "\n";

        // Verify CH system sizes
        std::cout << "[AMR] CH system: matrix=" << ch_matrix_.m() << "x" << ch_matrix_.n()
                  << ", rhs=" << ch_rhs_.size()
                  << ", solution=" << ch_solution_.size() << "\n";
        std::cout << "[AMR] Expected CH size: " << (theta_dof_handler_.n_dofs() + psi_dof_handler_.n_dofs()) << "\n";
    }

    // =========================================================================
    // Step 9: Rebuild ns_solution_ and restore divergence-free velocity
    // =========================================================================
    if (params_.enable_ns)
    {
        const unsigned int n_ns = ux_dof_handler_.n_dofs() +
            uy_dof_handler_.n_dofs() +
            p_dof_handler_.n_dofs();

        // Verify maps were rebuilt correctly
        Assert(ux_to_ns_map_.size() == ux_dof_handler_.n_dofs(),
               dealii::ExcMessage("ux_to_ns_map size mismatch after AMR"));
        Assert(uy_to_ns_map_.size() == uy_dof_handler_.n_dofs(),
               dealii::ExcMessage("uy_to_ns_map size mismatch after AMR"));
        Assert(p_to_ns_map_.size() == p_dof_handler_.n_dofs(),
               dealii::ExcMessage("p_to_ns_map size mismatch after AMR"));

        ns_solution_.reinit(n_ns);

        for (unsigned int i = 0; i < ux_to_ns_map_.size(); ++i)
            ns_solution_[ux_to_ns_map_[i]] = ux_solution_[i];
        for (unsigned int i = 0; i < uy_to_ns_map_.size(); ++i)
            ns_solution_[uy_to_ns_map_[i]] = uy_solution_[i];
        for (unsigned int i = 0; i < p_to_ns_map_.size(); ++i)
            ns_solution_[p_to_ns_map_[i]] = p_solution_[i];

        ns_combined_constraints_.distribute(ns_solution_);

        // =====================================================================
        // Step 10: RESTORE DIVERGENCE-FREE VELOCITY
        //
        // After AMR, interpolated velocity is NOT divergence-free.
        // Fix: One NS solve with U_old = U_current enforces div(U) = 0.
        // =====================================================================
        /*if (params_.output.verbose)
            std::cout << "[AMR] Restoring divergence-free velocity...\n";

        // DEBUG: Verify sizes before solve
        const unsigned int n_ns_expected = ux_dof_handler_.n_dofs() +
            uy_dof_handler_.n_dofs() + p_dof_handler_.n_dofs();

        Assert(ns_solution_.size() == n_ns_expected, dealii::ExcInternalError());
        Assert(ns_matrix_.m() == n_ns_expected, dealii::ExcInternalError());
        Assert(ns_rhs_.size() == n_ns_expected, dealii::ExcInternalError());
        Assert(ux_to_ns_map_.size() == ux_dof_handler_.n_dofs(), dealii::ExcInternalError());
        Assert(uy_to_ns_map_.size() == uy_dof_handler_.n_dofs(), dealii::ExcInternalError());
        Assert(p_to_ns_map_.size() == p_dof_handler_.n_dofs(), dealii::ExcInternalError());


        // Set old = current -> time derivative term becomes zero
        ux_old_solution_ = ux_solution_;
        uy_old_solution_ = uy_solution_;*/

        // Paper recommends K ≥ 9 direct solves after AMR for stability.
        // Don't reset if already counting down (frequent AMR case)
        direct_solve_countdown_ = std::max(direct_solve_countdown_, 9);

        // Invalidate Schur preconditioner (must rebuild with new mesh)
        schur_preconditioner_.reset();

        // Solve NS to restore consistency with incompressibility constraint
        // (interpolated velocity after AMR is generally not divergence-free)
        //solve_ns();

        // Update old solutions with the corrected (div-free) velocity
       /* ux_old_solution_ = ux_solution_;
        uy_old_solution_ = uy_solution_;

        if (params_.output.verbose)
            std::cout << "[AMR] Divergence-free velocity restored\n";*/

        // Track first AMR for solver optimization
        if (!first_amr_occurred_)
            first_amr_occurred_ = true;
    }
}

// Explicit instantiation
template class PhaseFieldProblem<2>;