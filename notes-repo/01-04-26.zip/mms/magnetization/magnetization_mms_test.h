// ============================================================================
// mms/magnetization/magnetization_mms_test.h - Magnetization MMS Test Interface
//
// Tests PRODUCTION components:
//   - setup/magnetization_setup.h (sparsity pattern)
//   - assembly/magnetization_assembler.h (DG system assembly)
//   - solvers/magnetization_solver.h (GMRES/Direct solve)
//
// Reference: Nochetto, Salgado & Tomas, CMAME 309 (2016) 497-531
// ============================================================================
#ifndef MAGNETIZATION_MMS_TEST_H
#define MAGNETIZATION_MMS_TEST_H

#include "utilities/parameters.h"

#include <vector>
#include <string>

// ============================================================================
// Solver type for A/B testing
// ============================================================================
enum class MagSolverType
{
    Direct,     // UMFPACK direct solver (default for DG)
    GMRES       // GMRES + Jacobi preconditioner
};

std::string to_string(MagSolverType type);

// ============================================================================
// Single refinement result with timing breakdown
// ============================================================================
struct MagMMSResult
{
    unsigned int refinement = 0;
    unsigned int n_dofs = 0;      // Total (Mx + My)
    double h = 0.0;

    // Errors
    double Mx_L2 = 0.0;
    double My_L2 = 0.0;
    double M_L2 = 0.0;            // Combined ||M||_L2

    // Timing breakdown (seconds)
    double setup_time = 0.0;      // Sparsity pattern
    double assembly_time = 0.0;   // Matrix + RHS
    double solve_time = 0.0;      // Linear solve (both Mx and My)
    double total_time = 0.0;      // Wall clock

    // Solver info
    unsigned int solver_iterations = 0;
    MagSolverType solver_type = MagSolverType::Direct;
};

// ============================================================================
// Convergence study result
// ============================================================================
struct MagMMSConvergenceResult
{
    std::vector<MagMMSResult> results;

    // Computed convergence rates
    std::vector<double> M_L2_rates;

    // Expected rates (based on FE degree)
    double expected_L2_rate = 0.0;  // p+1 for DG_p elements

    // Test configuration
    unsigned int fe_degree = 1;
    MagSolverType solver_type = MagSolverType::Direct;
    bool standalone = true;  // true = U=0, false = with transport

    /// Compute convergence rates from errors
    void compute_rates();

    /// Check if rates meet expectations (within tolerance)
    bool passes(double tolerance = 0.3) const;

    /// Print formatted results table
    void print() const;

    /// Write results to CSV file
    void write_csv(const std::string& filename) const;
};

// ============================================================================
// Test Runners
// ============================================================================

/**
 * @brief Run Magnetization MMS convergence study (STANDALONE, U=0)
 *
 * Tests production code path:
 *   1. setup_magnetization_sparsity() from magnetization_setup.h
 *   2. MagnetizationAssembler::assemble() from magnetization_assembler.h
 *   3. MagnetizationSolver::solve() from magnetization_solver.h
 *
 * @param refinements  List of refinement levels to test (e.g., {3,4,5,6})
 * @param params       Physical and numerical parameters
 * @param solver_type  Which solver to use (Direct, GMRES)
 * @return Convergence study results with timing
 */
MagMMSConvergenceResult run_magnetization_mms_standalone(
    const std::vector<unsigned int>& refinements,
    const Parameters& params,
    MagSolverType solver_type = MagSolverType::Direct);

/**
 * @brief Run single Magnetization MMS test at one refinement level
 *
 * Useful for quick sanity checks or debugging.
 */
MagMMSResult run_magnetization_mms_single(
    unsigned int refinement,
    const Parameters& params,
    MagSolverType solver_type = MagSolverType::Direct);

/**
 * @brief Compare solver performance (Direct vs GMRES)
 *
 * Runs the same problem with both solvers and reports timing.
 */
void compare_magnetization_solvers(
    unsigned int refinement,
    const Parameters& params);

#endif // MAGNETIZATION_MMS_TEST_H