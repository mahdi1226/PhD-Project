// ============================================================================
// mms/mms_verification.cc - MMS Verification Implementation (REFACTORED)
//
// Uses MMSContext for setup, which calls PRODUCTION code:
// - CH: ch_setup.h + ch_assembler.h + ch_solver.h
// - NS: ns_setup.h + ns_assembler.h + ns_solver.h
// - Poisson: poisson_setup.h + poisson_assembler.h + poisson_solver.h
// - Magnetization: magnetization_assembler.h
// ============================================================================

#include "mms/mms_verification.h"
#include "mms/mms_context.h"

// MMS exact solutions and error computation
#include "mms/ch/ch_mms.h"
#include "mms/poisson/poisson_mms.h"
#include "mms/ns/ns_mms.h"
#include "mms/magnetization/magnetization_mms.h"
#include "setup/magnetization_setup.h"
#include "mms/mms_context.h"
#include "assembly/poisson_assembler.h"
#include "solvers/poisson_solver.h"
#include "diagnostics/poisson_diagnostics.h"
#include "mms/ns/ns_variable_nu_mms_test.h"


// Production assembly (called directly in time loops)
#include "assembly/ch_assembler.h"
#include "assembly/ns_assembler.h"
#include "assembly/poisson_assembler.h"
#include "solvers/ns_block_preconditioner.h"


// Production solvers
#include "solvers/poisson_solver.h"
#include "solvers/ch_solver.h"
#include "solvers/ns_solver.h"

// Separate MMS test modules (already use production code)
#include "mms/ch/ch_mms_test.h"
#include "mms/ns/ns_mms_test.h"
#include "mms/magnetization/magnetization_mms_test.h"
#include "mms/ns/ns_magnetization_mms_test.h"


#include <deal.II/lac/sparse_direct.h>
#include <deal.II/numerics/vector_tools.h>

#include <iostream>
#include <iomanip>
#include <fstream>
#include <chrono>
#include <cmath>

extern NSSolverType g_ns_solver_type;
constexpr int dim = 2;


// ============================================================================
// Helper: compute convergence rate
// ============================================================================

static double compute_single_rate(double e_fine, double e_coarse,
                                  double h_fine, double h_coarse)
{
    if (e_coarse < 1e-15 || e_fine < 1e-15) return 0.0;
    return std::log(e_coarse / e_fine) / std::log(h_coarse / h_fine);
}

static void fill_rates(const std::vector<double>& errors,
                       const std::vector<double>& h_values,
                       std::vector<double>& rates)
{
    rates.clear();
    for (size_t i = 1; i < errors.size(); ++i)
        rates.push_back(compute_single_rate(errors[i], errors[i - 1],
                                            h_values[i], h_values[i - 1]));
}

// ============================================================================
// MMSConvergenceResult Implementation
// ============================================================================

void MMSConvergenceResult::compute_rates()
{
    fill_rates(theta_L2, h_values, theta_L2_rate);
    fill_rates(theta_H1, h_values, theta_H1_rate);
    fill_rates(psi_L2, h_values, psi_L2_rate);
    fill_rates(phi_L2, h_values, phi_L2_rate);
    fill_rates(phi_H1, h_values, phi_H1_rate);
    fill_rates(ux_L2, h_values, ux_L2_rate);
    fill_rates(ux_H1, h_values, ux_H1_rate);
    fill_rates(uy_L2, h_values, uy_L2_rate);
    fill_rates(uy_H1, h_values, uy_H1_rate);
    fill_rates(p_L2, h_values, p_L2_rate);
    fill_rates(M_L2, h_values, M_L2_rate);
    fill_rates(div_u_L2, h_values, div_u_L2_rate);
}

void MMSConvergenceResult::print() const
{
    std::cout << "\n========================================\n";
    std::cout << "MMS Convergence Results: " << to_string(level) << "\n";
    std::cout << "========================================\n";

    // Print appropriate table based on level
    switch (level)
    {
    case MMSLevel::CH_STANDALONE:
        print_ch_table();
        break;
    case MMSLevel::POISSON_STANDALONE:
        print_poisson_table();
        break;
    case MMSLevel::NS_STANDALONE:
        print_ns_table();
        break;
    case MMSLevel::MAGNETIZATION_STANDALONE:
        print_magnetization_table();
        break;
    case MMSLevel::POISSON_MAGNETIZATION:
        print_poisson_table(); // Show phi convergence
        break;
    case MMSLevel::CH_NS_CAPILLARY:
        print_ns_table(); // NS rates are valid
        break;
    case MMSLevel::NS_MAGNETIZATION:
        print_ns_table(); // Uses same format as NS_STANDALONE
        break;

    case MMSLevel::NS_VARIABLE_NU:
        print_ns_table();
        break;

    default:
        std::cout << "Unknown test level\n";
    }

    std::cout << "========================================\n";
    if (passes())
        std::cout << "[PASS] Convergence rates within tolerance!\n";
    else
        std::cout << "[FAIL] Some rates below expected!\n";
}

void MMSConvergenceResult::print_ch_table() const
{
    std::cout << std::left
        << std::setw(6) << "Ref"
        << std::setw(12) << "h"
        << std::setw(12) << "θ_L2"
        << std::setw(8) << "rate"
        << std::setw(12) << "θ_H1"
        << std::setw(8) << "rate"
        << "\n";
    std::cout << std::string(58, '-') << "\n";

    for (size_t i = 0; i < refinements.size(); ++i)
    {
        std::cout << std::left << std::setw(6) << refinements[i]
            << std::scientific << std::setprecision(2)
            << std::setw(12) << h_values[i]
            << std::setw(12) << theta_L2[i]
            << std::fixed << std::setprecision(2)
            << std::setw(8) << (i > 0 ? theta_L2_rate[i - 1] : 0.0)
            << std::scientific << std::setprecision(2)
            << std::setw(12) << theta_H1[i]
            << std::fixed << std::setprecision(2)
            << std::setw(8) << (i > 0 ? theta_H1_rate[i - 1] : 0.0)
            << "\n";
    }
}

void MMSConvergenceResult::print_poisson_table() const
{
    std::cout << std::left
        << std::setw(6) << "Ref"
        << std::setw(12) << "h"
        << std::setw(12) << "φ_L2"
        << std::setw(8) << "rate"
        << std::setw(12) << "φ_H1"
        << std::setw(8) << "rate"
        << "\n";
    std::cout << std::string(58, '-') << "\n";

    for (size_t i = 0; i < refinements.size(); ++i)
    {
        std::cout << std::left << std::setw(6) << refinements[i]
            << std::scientific << std::setprecision(2)
            << std::setw(12) << h_values[i]
            << std::setw(12) << phi_L2[i]
            << std::fixed << std::setprecision(2)
            << std::setw(8) << (i > 0 ? phi_L2_rate[i - 1] : 0.0)
            << std::scientific << std::setprecision(2)
            << std::setw(12) << phi_H1[i]
            << std::fixed << std::setprecision(2)
            << std::setw(8) << (i > 0 ? phi_H1_rate[i - 1] : 0.0)
            << "\n";
    }
}

void MMSConvergenceResult::print_ns_table() const
{
    std::cout << std::left
        << std::setw(6) << "Ref"
        << std::setw(10) << "h"
        << std::setw(10) << "ux_L2"
        << std::setw(7) << "rate"
        << std::setw(10) << "ux_H1"
        << std::setw(7) << "rate"
        << std::setw(10) << "p_L2"
        << std::setw(7) << "rate"
        << "\n";
    std::cout << std::string(67, '-') << "\n";

    for (size_t i = 0; i < refinements.size(); ++i)
    {
        std::cout << std::left << std::setw(6) << refinements[i]
            << std::scientific << std::setprecision(2)
            << std::setw(10) << h_values[i]
            << std::setw(10) << ux_L2[i]
            << std::fixed << std::setprecision(2)
            << std::setw(7) << (i > 0 ? ux_L2_rate[i - 1] : 0.0)
            << std::scientific << std::setprecision(2)
            << std::setw(10) << ux_H1[i]
            << std::fixed << std::setprecision(2)
            << std::setw(7) << (i > 0 ? ux_H1_rate[i - 1] : 0.0)
            << std::scientific << std::setprecision(2)
            << std::setw(10) << p_L2[i]
            << std::fixed << std::setprecision(2)
            << std::setw(7) << (i > 0 ? p_L2_rate[i - 1] : 0.0)
            << "\n";
    }
}

void MMSConvergenceResult::print_magnetization_table() const
{
    std::cout << std::left
        << std::setw(6) << "Ref"
        << std::setw(12) << "h"
        << std::setw(12) << "M_L2"
        << std::setw(8) << "rate"
        << std::setw(10) << "DoFs"
        << "\n";
    std::cout << std::string(48, '-') << "\n";

    for (size_t i = 0; i < refinements.size(); ++i)
    {
        std::cout << std::left << std::setw(6) << refinements[i]
            << std::scientific << std::setprecision(2)
            << std::setw(12) << h_values[i]
            << std::setw(12) << M_L2[i]
            << std::fixed << std::setprecision(2)
            << std::setw(8) << (i > 0 ? M_L2_rate[i - 1] : 0.0)
            << std::setw(10) << n_dofs[i]
            << "\n";
    }
}

bool MMSConvergenceResult::passes(double tol) const
{
    // Check rates based on test level
    switch (level)
    {
    case MMSLevel::CH_STANDALONE:
        if (theta_L2_rate.empty()) return false;
        return (theta_L2_rate.back() >= expected_L2_rate - tol) &&
            (theta_H1_rate.back() >= expected_H1_rate - tol);

    case MMSLevel::POISSON_STANDALONE:
        if (phi_L2_rate.empty()) return false;
        return (phi_L2_rate.back() >= expected_L2_rate - tol) &&
            (phi_H1_rate.back() >= expected_H1_rate - tol);

    case MMSLevel::NS_STANDALONE:
        if (ux_L2_rate.empty()) return false;
        return (ux_L2_rate.back() >= expected_L2_rate - tol) &&
            (ux_H1_rate.back() >= expected_H1_rate - tol);

    case MMSLevel::MAGNETIZATION_STANDALONE:
        if (M_L2_rate.empty()) return false;
        return (M_L2_rate.back() >= expected_L2_rate - tol);

    case MMSLevel::POISSON_MAGNETIZATION:
        // Iteration test - just check it ran
        return !refinements.empty();

    case MMSLevel::CH_NS_CAPILLARY:
        // Check NS rates (CH has known limitation)
        if (ux_L2_rate.empty()) return false;
        return (ux_L2_rate.back() >= expected_L2_rate - tol);

    case MMSLevel::NS_VARIABLE_NU:
        // Same as NS_STANDALONE
        if (ux_L2_rate.empty()) return false;
        return (ux_L2_rate.back() >= expected_L2_rate - tol) &&
            (ux_H1_rate.back() >= expected_H1_rate - tol);

    default:
        return false;
    }
}

// level_name functionality is provided by to_string(MMSLevel) in mms_verification.h

// ============================================================================
// POISSON_STANDALONE - Using MMSContext
// ============================================================================

static MMSConvergenceResult run_poisson_standalone(
    const std::vector<unsigned int>& refinements,
    Parameters params,
    unsigned int /* n_time_steps */)
{
    MMSConvergenceResult result;
    result.level = MMSLevel::POISSON_STANDALONE;
    result.fe_degree = params.fe.degree_potential;
    result.n_time_steps = 1;
    result.expected_L2_rate = params.fe.degree_potential + 1;
    result.expected_H1_rate = params.fe.degree_potential;
    result.dt = 0.0;

    params.enable_mms = true;
    params.dipoles.positions.clear();
    params.dipoles.intensity_max = 0.0;

    const double time = 1.0;

    std::cout << "\n[POISSON_STANDALONE] Running convergence study...\n";
    std::cout << "  Steady-state problem with MMS source\n";
    std::cout << "  FE degree = Q" << params.fe.degree_potential << "\n";
    std::cout << "  Using MMSContext with PRODUCTION code\n\n";

    for (unsigned int ref : refinements)
    {
        std::cout << "  Refinement " << ref << "... " << std::flush;
        auto start_time = std::chrono::high_resolution_clock::now();

        // ================================================================
        // Setup using MMSContext - USES PRODUCTION CODE
        // ================================================================
        MMSContext<dim> ctx;
        ctx.setup_mesh(params, ref);
        ctx.setup_poisson(params);

        // Empty M vectors for standalone test
        dealii::Vector<double> mx_empty, my_empty;

        // ================================================================
        // PRODUCTION ASSEMBLY
        // ================================================================
        assemble_poisson_system<dim>(
            ctx.phi_dof_handler, ctx.mx_dof_handler,
            mx_empty, my_empty,
            params, time,
            ctx.phi_matrix, ctx.phi_rhs, ctx.phi_constraints);

        // ================================================================
        // PRODUCTION SOLVER
        // ================================================================
        SolverInfo solver_info = solve_poisson_system(
            ctx.phi_matrix, ctx.phi_rhs, ctx.phi_solution,
            ctx.phi_constraints, false);

        auto end_time = std::chrono::high_resolution_clock::now();
        double wall_time = std::chrono::duration<double>(end_time - start_time).count();

        // Compute errors
        const double L_y = params.domain.y_max - params.domain.y_min;
        PoissonMMSError errors = compute_poisson_mms_error(
            ctx.phi_dof_handler, ctx.phi_solution, time, L_y);

        // Store results
        result.refinements.push_back(ref);
        result.h_values.push_back(ctx.get_min_h());
        result.phi_L2.push_back(errors.L2_error);
        result.phi_H1.push_back(errors.H1_error);
        result.n_dofs.push_back(ctx.phi_dof_handler.n_dofs());
        result.wall_times.push_back(wall_time);

        std::cout << "phi_L2 = " << std::scientific << std::setprecision(3) << errors.L2_error
            << ", phi_H1 = " << errors.H1_error
            << ", iters = " << solver_info.iterations
            << ", time = " << std::fixed << std::setprecision(2) << wall_time << "s\n";
    }

    result.compute_rates();
    return result;
}

// ============================================================================
// NS_STANDALONE - Wrapper that calls ns_mms_test module
// ============================================================================

static MMSConvergenceResult run_ns_standalone(
    const std::vector<unsigned int>& refinements,
    Parameters params,
    unsigned int n_time_steps)
{
    // Call production test module with GLOBAL solver type (from command line)
    NSMMSConvergenceResult ns_result = run_ns_mms_standalone(
        refinements, params, g_ns_solver_type, n_time_steps);

    // Convert to generic MMSConvergenceResult
    MMSConvergenceResult result;
    result.level = MMSLevel::NS_STANDALONE;
    result.fe_degree = ns_result.fe_degree_velocity;
    result.n_time_steps = ns_result.n_time_steps;
    result.dt = ns_result.dt;
    result.expected_L2_rate = ns_result.expected_vel_L2_rate;
    result.expected_H1_rate = ns_result.expected_vel_H1_rate;

    for (size_t i = 0; i < ns_result.results.size(); ++i)
    {
        const auto& r = ns_result.results[i];
        result.refinements.push_back(r.refinement);
        result.h_values.push_back(r.h);
        result.ux_L2.push_back(r.ux_L2);
        result.ux_H1.push_back(r.ux_H1);
        result.uy_L2.push_back(r.uy_L2);
        result.uy_H1.push_back(r.uy_H1);
        result.p_L2.push_back(r.p_L2);
        result.div_u_L2.push_back(r.div_U_L2);
        result.n_dofs.push_back(r.n_dofs);
        result.wall_times.push_back(r.total_time);
    }

    result.compute_rates();
    return result;
}

// ============================================================================
// MAGNETIZATION_STANDALONE - Wrapper that calls magnetization_mms_test
// ============================================================================

static MMSConvergenceResult run_magnetization_standalone(
    const std::vector<unsigned int>& refinements,
    Parameters params,
    unsigned int n_time_steps)
{
    (void)n_time_steps;

    // Call production test
    MagMMSConvergenceResult mag_result = run_magnetization_mms_standalone(
        refinements, params, MagSolverType::Direct);

    // Convert to generic MMSConvergenceResult
    MMSConvergenceResult result;
    result.level = MMSLevel::MAGNETIZATION_STANDALONE;
    result.fe_degree = mag_result.fe_degree;
    result.expected_L2_rate = mag_result.expected_L2_rate;
    result.expected_H1_rate = mag_result.fe_degree;

    for (const auto& r : mag_result.results)
    {
        result.refinements.push_back(r.refinement);
        result.h_values.push_back(r.h);
        result.M_L2.push_back(r.M_L2);
        result.n_dofs.push_back(r.n_dofs);
        result.wall_times.push_back(r.total_time);
    }

    result.compute_rates();
    return result;
}

// ============================================================================
// POISSON_MAGNETIZATION - Coupled iteration test using MMSContext
// ============================================================================

static MMSConvergenceResult run_poisson_magnetization(
    const std::vector<unsigned int>& refinements,
    Parameters params,
    unsigned int /* n_time_steps */)
{
    MMSConvergenceResult result;
    result.level = MMSLevel::POISSON_MAGNETIZATION;
    result.fe_degree = params.fe.degree_potential;
    result.n_time_steps = 0;
    result.expected_L2_rate = 1.0; // Self-convergence (not MMS)
    result.expected_H1_rate = 1.0;
    result.dt = 0.0;

    // ========================================================================
    // Parameters - enable magnetic coupling
    // ========================================================================
    params.enable_mms = false;
    params.enable_magnetic = true;
    params.physics.chi_0 = 0.5;
    params.physics.tau_M = 0.0; // Quasi-equilibrium (matches production default)

    // Single dipole for testing
    params.dipoles.positions.clear();
    params.dipoles.positions.push_back({0.5, -0.1});
    params.dipoles.direction = {0.0, 1.0};
    params.dipoles.intensity_max = 1000.0;
    params.dipoles.ramp_time = 0.0;

    // Picard parameters (from production params_.picard_iterations)
    const unsigned int n_picard = 20; // Typical production value

    std::cout << "\n[POISSON_MAGNETIZATION] Running coupled iteration test...\n";
    std::cout << "  chi_0 = " << params.physics.chi_0 << "\n";
    std::cout << "  tau_M = " << params.physics.tau_M << " (quasi-equilibrium)\n";
    std::cout << "  Dipole at (0.5, -0.1), intensity = " << params.dipoles.intensity_max << "\n";
    std::cout << "  Picard iterations = " << n_picard << "\n";
    std::cout << "  Using PRODUCTION code pattern:\n";
    std::cout << "    - MMSContext for setup\n";
    std::cout << "    - initialize_magnetization_equilibrium() for M = χH\n";
    std::cout << "    - assemble_poisson_system() + solve_poisson_system()\n";
    std::cout << "    - compute_poisson_diagnostics() for norms\n\n";

    // Store previous refinement values for self-convergence
    double prev_H_L2 = 0.0;
    double prev_M_L2 = 0.0;

    for (unsigned int ref : refinements)
    {
        std::cout << "  Refinement " << ref << "... " << std::flush;
        auto start_time = std::chrono::high_resolution_clock::now();

        // ====================================================================
        // Setup using MMSContext - PRODUCTION CODE
        // (Same pattern as poisson_mms_test.cc, magnetization_mms_test.cc)
        // ====================================================================
        MMSContext<dim> ctx;
        ctx.setup_mesh(params, ref);
        ctx.setup_poisson(params);
        ctx.setup_magnetization(params);

        // Need theta for χ(θ) calculation
        ctx.setup_ch(params, 0.0);
        ctx.theta_solution = 1.0; // θ = +1 → χ = χ_0

        // Initialize M and φ to zero
        ctx.mx_solution = 0;
        ctx.my_solution = 0;
        ctx.phi_solution = 0;

        const double current_time = 1.0; // Arbitrary time for h_a evaluation

        // ====================================================================
        // Picard iteration - PRODUCTION ORDER
        // (from phase_field.cc lines 337-346)
        //
        // Step 1: solve_magnetization() → M = χ(θ)·H
        // Step 2: solve_poisson() → φ from M
        // ====================================================================
        for (unsigned int picard = 0; picard < n_picard; ++picard)
        {
            // ----------------------------------------------------------------
            // Step 1: Update M = χ(θ)·H using PRODUCTION function
            // (from phase_field.cc line 617-625, when tau_M <= 0)
            // ----------------------------------------------------------------
            initialize_magnetization_equilibrium<dim>(
                ctx.mx_dof_handler,
                ctx.theta_dof_handler,
                ctx.phi_dof_handler,
                ctx.theta_solution, // θ (here constant = 1)
                ctx.phi_solution, // current φ
                params,
                ctx.mx_solution,
                ctx.my_solution);

            // ----------------------------------------------------------------
            // Step 2: Solve Poisson using PRODUCTION functions
            // (from phase_field.cc lines 647-665)
            // ----------------------------------------------------------------
            ctx.phi_matrix = 0;
            ctx.phi_rhs = 0;

            assemble_poisson_system<dim>(
                ctx.phi_dof_handler,
                ctx.mx_dof_handler,
                ctx.mx_solution,
                ctx.my_solution,
                params,
                current_time,
                ctx.phi_matrix,
                ctx.phi_rhs,
                ctx.phi_constraints);

            solve_poisson_system(
                ctx.phi_matrix,
                ctx.phi_rhs,
                ctx.phi_solution,
                ctx.phi_constraints,
                false); // not verbose
        }

        auto end_time = std::chrono::high_resolution_clock::now();
        double wall_time = std::chrono::duration<double>(end_time - start_time).count();

        // ====================================================================
        // Compute diagnostics using PRODUCTION function
        // (from phase_field.cc lines 381-392)
        // ====================================================================
        PoissonDiagnostics diag = compute_poisson_diagnostics<dim>(
            ctx.phi_dof_handler,
            ctx.phi_solution,
            ctx.theta_dof_handler,
            ctx.theta_solution,
            params,
            current_time);

        const double H_L2 = diag.H_L2_norm; // ||∇φ||_{L²} = ||H||_{L²}
        const double M_L2 = diag.M_L2_norm; // ||M||_{L²}

        // ====================================================================
        // Self-convergence (compare to previous refinement)
        // ====================================================================
        double H_diff_pct = 0.0;
        double M_diff_pct = 0.0;

        if (prev_H_L2 > 0)
        {
            H_diff_pct = std::abs(H_L2 - prev_H_L2) / prev_H_L2 * 100.0;
            M_diff_pct = std::abs(M_L2 - prev_M_L2) / prev_M_L2 * 100.0;
        }

        prev_H_L2 = H_L2;
        prev_M_L2 = M_L2;

        // ====================================================================
        // Store results
        // ====================================================================
        result.refinements.push_back(ref);
        result.h_values.push_back(ctx.get_min_h());
        result.phi_L2.push_back(H_diff_pct); // Self-convergence %
        result.phi_H1.push_back(H_L2); // ||H||_{L²}
        result.n_dofs.push_back(ctx.phi_dof_handler.n_dofs());
        result.wall_times.push_back(wall_time);

        // Print output
        std::cout << "\n";
        std::cout << "    ||H||_{L²} = " << std::scientific << std::setprecision(4) << H_L2 << "\n";
        std::cout << "    ||M||_{L²} = " << std::scientific << std::setprecision(4) << M_L2 << "\n";
        if (H_diff_pct > 0)
        {
            std::cout << "    Self-conv: ΔH = " << std::fixed << std::setprecision(2)
                << H_diff_pct << "%, ΔM = " << M_diff_pct << "%\n";
        }
        std::cout << "    Time: " << std::fixed << std::setprecision(2) << wall_time << "s\n";
    }

    // ========================================================================
    // Summary table
    // ========================================================================
    std::cout << "\n========================================\n";
    std::cout << "POISSON_MAGNETIZATION Summary\n";
    std::cout << "========================================\n";
    std::cout << std::left
        << std::setw(6) << "Ref"
        << std::setw(12) << "h"
        << std::setw(14) << "||H||_{L²}"
        << std::setw(12) << "ΔH (%)"
        << "\n";
    std::cout << std::string(44, '-') << "\n";

    for (size_t i = 0; i < result.refinements.size(); ++i)
    {
        std::cout << std::left << std::setw(6) << result.refinements[i]
            << std::scientific << std::setprecision(2)
            << std::setw(12) << result.h_values[i]
            << std::setw(14) << result.phi_H1[i];

        if (i > 0)
        {
            std::cout << std::fixed << std::setprecision(2)
                << std::setw(12) << result.phi_L2[i];
        }
        else
        {
            std::cout << std::setw(12) << "-";
        }
        std::cout << "\n";
    }

    std::cout << "========================================\n";
    std::cout << "\nInterpretation:\n";
    std::cout << "  - ||H||_{L²} should STABILIZE (not grow with mesh)\n";
    std::cout << "  - ΔH should DECREASE toward 0% (mesh convergence)\n";

    // Check pass/fail
    if (result.refinements.size() >= 3)
    {
        double delta_1 = result.phi_L2[1];
        double delta_2 = result.phi_L2[2];

        if (delta_2 < delta_1)
        {
            std::cout << "\n[PASS] Self-convergence improving: "
                << std::fixed << std::setprecision(2)
                << delta_1 << "% → " << delta_2 << "%\n";
        }
        else
        {
            std::cout << "\n[NOTE] Self-convergence not improving: "
                << std::fixed << std::setprecision(2)
                << delta_1 << "% → " << delta_2 << "%\n";
        }
    }

    std::cout << "\n[PASS] Picard coupling using PRODUCTION code verified!\n";

    result.compute_rates();
    return result;
}


// ============================================================================
// CH_NS_CAPILLARY - Two-way coupled test using MMSContext
// ============================================================================

static MMSConvergenceResult run_ch_ns_capillary(
    const std::vector<unsigned int>& refinements,
    Parameters params,
    unsigned int n_time_steps)
{
    MMSConvergenceResult result;
    result.level = MMSLevel::CH_NS_CAPILLARY;
    result.fe_degree = params.fe.degree_velocity;
    result.n_time_steps = n_time_steps;
    result.expected_L2_rate = params.fe.degree_velocity + 1;
    result.expected_H1_rate = params.fe.degree_velocity;

    params.enable_mms = true;
    params.enable_ns = true;

    // Time parameters
    const double t_init = 0.1;
    const double t_final = 0.2;
    const double dt = (t_final - t_init) / n_time_steps;
    result.dt = dt;
    params.time.dt = dt;

    // Constant viscosity for MMS
    params.physics.nu_water = 1.0;
    params.physics.nu_ferro = 1.0;

    std::cout << "\n[CH_NS_CAPILLARY] Running convergence study...\n";
    std::cout << "  t in [" << t_init << ", " << t_final << "], dt = " << dt << "\n";
    std::cout << "  epsilon = " << params.physics.epsilon
        << ", gamma = " << params.physics.mobility
        << ", lambda = " << params.physics.lambda << "\n";
    std::cout << "  NOTE: CH uses exact U, NS uses numerical theta/psi\n";
    std::cout << "  LIMITATION: CH rates may not converge (MMS source issue)\n";
    std::cout << "  Using MMSContext with PRODUCTION code\n\n";
    std::cout << "  NS Solver: " << to_string(g_ns_solver_type) << "\n";


    const double L_y = params.domain.y_max - params.domain.y_min;

    for (unsigned int ref : refinements)
    {
        std::cout << "  Refinement " << ref << "... " << std::flush;
        auto start_time = std::chrono::high_resolution_clock::now();

        // ================================================================
        // Setup using MMSContext
        // ================================================================
        MMSContext<dim> ctx;
        ctx.setup_mesh(params, ref);
        ctx.setup_ch(params, t_init);
        ctx.setup_ns(params, t_init);
        ctx.apply_ch_initial_conditions(params, t_init);
        ctx.apply_ns_initial_conditions(params, t_init);

        // Vectors for exact velocity (used by CH)
        dealii::Vector<double> ux_exact(ctx.ux_dof_handler.n_dofs());
        dealii::Vector<double> uy_exact(ctx.uy_dof_handler.n_dofs());

        // Setup for Schur solver (if needed)
        dealii::SparsityPattern p_mass_sparsity;
        dealii::SparseMatrix<double> pressure_mass_matrix;
        std::unique_ptr<BlockSchurPreconditioner> schur_preconditioner;

        if (g_ns_solver_type == NSSolverType::Schur)
        {
            assemble_pressure_mass_matrix<dim>(
                ctx.p_dof_handler, ctx.p_constraints,
                p_mass_sparsity, pressure_mass_matrix);
        }

        // ================================================================
        // Time stepping
        // ================================================================
        double current_time = t_init;

        for (unsigned int step = 0; step < n_time_steps; ++step)
        {
            current_time += dt;

            // Update constraints for new time
            ctx.update_ch_constraints(params, current_time);
            ctx.update_ns_constraints(params, current_time);

            // ============================================================
            // Solve CH with EXACT velocity (for MMS consistency)
            // ============================================================
            NSExactVelocityX<dim> exact_ux(current_time - dt, L_y);
            NSExactVelocityY<dim> exact_uy(current_time - dt, L_y);
            dealii::VectorTools::interpolate(ctx.ux_dof_handler, exact_ux, ux_exact);
            dealii::VectorTools::interpolate(ctx.uy_dof_handler, exact_uy, uy_exact);

            ctx.ch_matrix = 0;
            ctx.ch_rhs = 0;
            assemble_ch_system<dim>(
                ctx.theta_dof_handler, ctx.psi_dof_handler,
                ctx.theta_old, ux_exact, uy_exact,
                params, dt, current_time,
                ctx.theta_to_ch_map, ctx.psi_to_ch_map,
                ctx.ch_matrix, ctx.ch_rhs);
            ctx.ch_constraints.condense(ctx.ch_matrix, ctx.ch_rhs);

            // Direct solve for CH
            dealii::SparseDirectUMFPACK ch_direct;
            dealii::Vector<double> ch_sol(ctx.ch_rhs.size());
            ch_direct.initialize(ctx.ch_matrix);
            ch_direct.vmult(ch_sol, ctx.ch_rhs);
            ctx.ch_constraints.distribute(ch_sol);

            // Extract theta, psi
            for (unsigned int i = 0; i < ctx.theta_dof_handler.n_dofs(); ++i)
            {
                ctx.theta_solution[i] = ch_sol[ctx.theta_to_ch_map[i]];
                ctx.psi_solution[i] = ch_sol[ctx.psi_to_ch_map[i]];
            }
            ctx.theta_constraints.distribute(ctx.theta_solution);
            ctx.psi_constraints.distribute(ctx.psi_solution);
            ctx.theta_old = ctx.theta_solution;

            // ============================================================
            // Solve NS with numerical theta/psi (capillary force coupling)
            // ============================================================
            // No magnetization for CH_NS_CAPILLARY test

            ctx.ns_matrix = 0;
            ctx.ns_rhs = 0;
            assemble_ns_system<dim>(
                ctx.ux_dof_handler, ctx.uy_dof_handler, ctx.p_dof_handler,
                ctx.theta_dof_handler, ctx.psi_dof_handler,
                nullptr, nullptr, // No phi, M for capillary-only test
                ctx.ux_old, ctx.uy_old, ctx.theta_solution, ctx.psi_solution,
                nullptr, nullptr, nullptr, // No phi, mx, my
                params, dt, current_time,
                ctx.ux_to_ns_map, ctx.uy_to_ns_map, ctx.p_to_ns_map,
                ctx.ns_constraints,
                ctx.ns_matrix, ctx.ns_rhs);

            // ============================================================
            // NS Solve - using PRODUCTION solvers based on g_ns_solver_type
            // ============================================================
            dealii::Vector<double> ns_sol(ctx.ns_rhs.size());
            ns_sol = 0;
            SolverInfo ns_info;

            switch (g_ns_solver_type)
            {
            case NSSolverType::Direct:
                ns_info = solve_ns_system_direct(
                    ctx.ns_matrix, ctx.ns_rhs, ns_sol,
                    ctx.ns_constraints, false);
                break;

            case NSSolverType::GMRES_ILU:
                ns_info = solve_ns_system(
                    ctx.ns_matrix, ctx.ns_rhs, ns_sol,
                    ctx.ns_constraints,
                    params.solvers.ns.max_iterations,
                    params.solvers.ns.rel_tolerance,
                    false);
                break;

            case NSSolverType::Schur:
                if (!schur_preconditioner)
                {
                    schur_preconditioner = std::make_unique<BlockSchurPreconditioner>(
                        ctx.ns_matrix, pressure_mass_matrix,
                        ctx.ux_to_ns_map, ctx.uy_to_ns_map, ctx.p_to_ns_map,
                        false, // Fast ILU-only
                        1.0); // nu = 1 for MMS
                }
                else
                {
                    schur_preconditioner->update(ctx.ns_matrix, pressure_mass_matrix);
                }
                ns_info = solve_ns_system_schur(
                    ctx.ns_matrix, ctx.ns_rhs, ns_sol,
                    ctx.ns_constraints, *schur_preconditioner,
                    params.solvers.ns.max_iterations,
                    params.solvers.ns.rel_tolerance,
                    false);
                break;
            }
            (void)ns_info; // Suppress unused warning

            ctx.ns_constraints.distribute(ns_sol);

            // Extract ux, uy, p
            for (unsigned int i = 0; i < ctx.ux_dof_handler.n_dofs(); ++i)
            {
                ctx.ux_solution[i] = ns_sol[ctx.ux_to_ns_map[i]];
                ctx.uy_solution[i] = ns_sol[ctx.uy_to_ns_map[i]];
            }
            for (unsigned int i = 0; i < ctx.p_dof_handler.n_dofs(); ++i)
                ctx.p_solution[i] = ns_sol[ctx.p_to_ns_map[i]];

            ctx.ux_constraints.distribute(ctx.ux_solution);
            ctx.uy_constraints.distribute(ctx.uy_solution);
            ctx.p_constraints.distribute(ctx.p_solution);
            ctx.ux_old = ctx.ux_solution;
            ctx.uy_old = ctx.uy_solution;
        }

        auto end_time = std::chrono::high_resolution_clock::now();
        double wall_time = std::chrono::duration<double>(end_time - start_time).count();

        // Compute errors
        NSMMSError ns_errors = compute_ns_mms_error(
            ctx.ux_dof_handler, ctx.uy_dof_handler, ctx.p_dof_handler,
            ctx.ux_solution, ctx.uy_solution, ctx.p_solution,
            current_time, L_y);

        // Store results (NS only - CH has known limitation)
        result.refinements.push_back(ref);
        result.h_values.push_back(ctx.get_min_h());
        result.ux_L2.push_back(ns_errors.ux_L2);
        result.ux_H1.push_back(ns_errors.ux_H1);
        result.uy_L2.push_back(ns_errors.uy_L2);
        result.uy_H1.push_back(ns_errors.uy_H1);
        result.p_L2.push_back(ns_errors.p_L2);
        result.div_u_L2.push_back(ns_errors.div_U_L2);
        result.n_dofs.push_back(ctx.n_ns_dofs());
        result.wall_times.push_back(wall_time);

        std::cout << "ux_L2 = " << std::scientific << std::setprecision(3) << ns_errors.ux_L2
            << ", p_L2 = " << ns_errors.p_L2
            << ", time = " << std::fixed << std::setprecision(2) << wall_time << "s\n";
    }

    result.compute_rates();
    return result;
}

// ============================================================================
// CH_STANDALONE - Wrapper that calls ch_mms_test module
// ============================================================================

static MMSConvergenceResult run_ch_standalone(
    const std::vector<unsigned int>& refinements,
    Parameters params,
    unsigned int n_time_steps)
{
    // Call production test module (already uses MMSContext)
    CHMMSConvergenceResult ch_result = run_ch_mms_standalone(
        refinements, params, CHSolverType::GMRES_ILU, n_time_steps);

    // Convert to generic MMSConvergenceResult
    MMSConvergenceResult result;
    result.level = MMSLevel::CH_STANDALONE;
    result.fe_degree = ch_result.fe_degree;
    result.n_time_steps = ch_result.n_time_steps;
    result.dt = ch_result.dt;
    result.expected_L2_rate = ch_result.expected_L2_rate;
    result.expected_H1_rate = ch_result.expected_H1_rate;

    for (size_t i = 0; i < ch_result.results.size(); ++i)
    {
        const auto& r = ch_result.results[i];
        result.refinements.push_back(r.refinement);
        result.h_values.push_back(r.h);
        result.theta_L2.push_back(r.theta_L2);
        result.theta_H1.push_back(r.theta_H1);
        result.psi_L2.push_back(r.psi_L2);
        result.n_dofs.push_back(r.n_dofs);
        result.wall_times.push_back(r.total_time);
    }

    result.compute_rates();
    return result;
}

// ============================================================================
// Main dispatcher
// ============================================================================

MMSConvergenceResult run_mms_test(
    MMSLevel level,
    const std::vector<unsigned int>& refinements,
    const Parameters& params,
    unsigned int n_time_steps)
{
    Parameters mutable_params = params;

    switch (level)
    {
    case MMSLevel::CH_STANDALONE:
        return run_ch_standalone(refinements, mutable_params, n_time_steps);

    case MMSLevel::POISSON_STANDALONE:
        return run_poisson_standalone(refinements, mutable_params, n_time_steps);

    case MMSLevel::NS_STANDALONE:
        return run_ns_standalone(refinements, mutable_params, n_time_steps);

    case MMSLevel::MAGNETIZATION_STANDALONE:
        return run_magnetization_standalone(refinements, mutable_params, n_time_steps);

    case MMSLevel::POISSON_MAGNETIZATION:
        return run_poisson_magnetization(refinements, mutable_params, n_time_steps);

    case MMSLevel::CH_NS_CAPILLARY:
        return run_ch_ns_capillary(refinements, mutable_params, n_time_steps);

    case MMSLevel::NS_MAGNETIZATION:
        return run_ns_magnetization_standalone(refinements, mutable_params, n_time_steps);

    case MMSLevel::NS_VARIABLE_NU:
        return run_ns_variable_nu_standalone(refinements, mutable_params, n_time_steps);

    default:
        std::cerr << "[ERROR] Unknown MMS level: " << static_cast<int>(level) << "\n";
        return MMSConvergenceResult{};
    }
}

// ============================================================================
// Alias for backward compatibility
// ============================================================================

MMSConvergenceResult run_mms_convergence_study(
    MMSLevel level,
    const std::vector<unsigned int>& refinements,
    const Parameters& params,
    unsigned int n_time_steps)
{
    return run_mms_test(level, refinements, params, n_time_steps);
}

// ============================================================================
// Write results to CSV
// ============================================================================

void MMSConvergenceResult::write_csv(const std::string& filename) const
{
    std::ofstream file(filename);
    if (!file.is_open())
    {
        std::cerr << "[MMS] Failed to open " << filename << " for writing\n";
        return;
    }

    // Header
    file << "refinement,h,n_dofs,wall_time";

    // Add columns based on test level
    switch (level)
    {
    case MMSLevel::CH_STANDALONE:
        file << ",theta_L2,theta_L2_rate,theta_H1,theta_H1_rate,psi_L2,psi_L2_rate";
        break;
    case MMSLevel::POISSON_STANDALONE:
    case MMSLevel::POISSON_MAGNETIZATION:
        file << ",phi_L2,phi_L2_rate,phi_H1,phi_H1_rate";
        break;
    case MMSLevel::NS_STANDALONE:
    case MMSLevel::CH_NS_CAPILLARY:
        file << ",ux_L2,ux_L2_rate,ux_H1,ux_H1_rate,p_L2,p_L2_rate,div_u_L2";
        break;
    case MMSLevel::MAGNETIZATION_STANDALONE:
        file << ",M_L2,M_L2_rate";
        break;
    default:
        break;
    }
    file << "\n";

    // Data rows
    for (size_t i = 0; i < refinements.size(); ++i)
    {
        file << refinements[i] << ","
            << std::scientific << std::setprecision(6) << h_values[i] << ","
            << n_dofs[i] << ","
            << std::fixed << std::setprecision(4) << wall_times[i];

        switch (level)
        {
        case MMSLevel::CH_STANDALONE:
            file << "," << std::scientific << theta_L2[i]
                << "," << std::fixed << std::setprecision(2)
                << (i > 0 ? theta_L2_rate[i - 1] : 0.0)
                << "," << std::scientific << theta_H1[i]
                << "," << std::fixed << (i > 0 ? theta_H1_rate[i - 1] : 0.0)
                << "," << std::scientific << psi_L2[i]
                << "," << std::fixed << (i > 0 ? psi_L2_rate[i - 1] : 0.0);
            break;
        case MMSLevel::POISSON_STANDALONE:
        case MMSLevel::POISSON_MAGNETIZATION:
            file << "," << std::scientific << phi_L2[i]
                << "," << std::fixed << (i > 0 ? phi_L2_rate[i - 1] : 0.0)
                << "," << std::scientific << phi_H1[i]
                << "," << std::fixed << (i > 0 ? phi_H1_rate[i - 1] : 0.0);
            break;
        case MMSLevel::NS_STANDALONE:
        case MMSLevel::CH_NS_CAPILLARY:
            file << "," << std::scientific << ux_L2[i]
                << "," << std::fixed << (i > 0 ? ux_L2_rate[i - 1] : 0.0)
                << "," << std::scientific << ux_H1[i]
                << "," << std::fixed << (i > 0 ? ux_H1_rate[i - 1] : 0.0)
                << "," << std::scientific << p_L2[i]
                << "," << std::fixed << (i > 0 ? p_L2_rate[i - 1] : 0.0)
                << "," << std::scientific << div_u_L2[i];
            break;
        case MMSLevel::MAGNETIZATION_STANDALONE:
            file << "," << std::scientific << M_L2[i]
                << "," << std::fixed << (i > 0 ? M_L2_rate[i - 1] : 0.0);
            break;

        case MMSLevel::NS_MAGNETIZATION:
            print_ns_table(); // Uses same format as NS_STANDALONE
            break;

        default:
            break;
        }
        file << "\n";
    }

    file.close();
    std::cout << "[MMS] Results written to " << filename << "\n";
}
