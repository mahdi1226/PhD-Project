// ============================================================================
// mms/poisson_mms_test.h - Poisson MMS Test Interface
//
// Tests PRODUCTION components:
//   - setup/poisson_setup.h (constraints, sparsity)
//   - assembly/poisson_assembler.h (system assembly)
//   - solvers/poisson_solver.h (AMG/SSOR/Direct solve)
//
// Reference: Nochetto, Salgado & Tomas, CMAME 309 (2016) 497-531
// ============================================================================
#ifndef POISSON_MMS_TEST_H
#define POISSON_MMS_TEST_H

#include "utilities/parameters.h"
#include "solvers/solver_info.h"

#include <vector>
#include <string>

// ============================================================================
// Solver type for A/B testing
// ============================================================================
enum class PoissonSolverType
{
    AMG,      // CG + Trilinos AMG (default, scalable)
    SSOR,     // CG + SSOR (fallback)
    Direct    // UMFPACK direct solver
};

std::string to_string(PoissonSolverType type);

// ============================================================================
// Single refinement result with timing breakdown
// ============================================================================
struct PoissonMMSResult
{
    unsigned int refinement = 0;
    unsigned int n_dofs = 0;
    double h = 0.0;

    // Errors
    double L2_error = 0.0;
    double H1_error = 0.0;
    double Linf_error = 0.0;

    // Timing breakdown (seconds)
    double setup_time = 0.0;      // Constraints + sparsity
    double assembly_time = 0.0;   // Matrix + RHS
    double solve_time = 0.0;      // Linear solve
    double total_time = 0.0;      // Wall clock

    // Solver info
    unsigned int solver_iterations = 0;
    double solver_residual = 0.0;
    bool used_direct_fallback = false;
    PoissonSolverType solver_type = PoissonSolverType::AMG;
};

// ============================================================================
// Convergence study result
// ============================================================================
struct PoissonMMSConvergenceResult
{
    std::vector<PoissonMMSResult> results;

    // Computed convergence rates
    std::vector<double> L2_rates;
    std::vector<double> H1_rates;

    // Expected rates (based on FE degree)
    double expected_L2_rate = 0.0;  // p+1 for Q_p elements
    double expected_H1_rate = 0.0;  // p for Q_p elements

    // Test configuration
    unsigned int fe_degree = 1;
    PoissonSolverType solver_type = PoissonSolverType::AMG;
    bool standalone = true;  // true = M=0, false = coupled with magnetization

    /// Compute convergence rates from errors
    void compute_rates();

    /// Check if rates meet expectations (within tolerance)
    bool passes(double tolerance = 0.3) const;

    /// Print formatted results table
    void print() const;

    /// Write results to CSV file
    void write_csv(const std::string& filename) const;
};

// ============================================================================
// Test Runners
// ============================================================================

/**
 * @brief Run Poisson MMS convergence study (STANDALONE, M=0)
 *
 * Tests production code path:
 *   1. setup_poisson_constraints_and_sparsity() from poisson_setup.h
 *   2. assemble_poisson_system() from poisson_assembler.h
 *   3. solve_poisson_system() from poisson_solver.h
 *
 * @param refinements  List of refinement levels to test (e.g., {3,4,5,6})
 * @param params       Physical and numerical parameters
 * @param solver_type  Which solver to use (AMG, SSOR, Direct)
 * @return Convergence study results with timing
 */
PoissonMMSConvergenceResult run_poisson_mms_standalone(
    const std::vector<unsigned int>& refinements,
    const Parameters& params,
    PoissonSolverType solver_type = PoissonSolverType::AMG);

/**
 * @brief Run single Poisson MMS test at one refinement level
 *
 * Useful for quick sanity checks or debugging.
 */
PoissonMMSResult run_poisson_mms_single(
    unsigned int refinement,
    const Parameters& params,
    PoissonSolverType solver_type = PoissonSolverType::AMG);

/**
 * @brief Compare solver performance (AMG vs SSOR vs Direct)
 *
 * Runs the same problem with all three solvers and reports timing.
 */
void compare_poisson_solvers(
    unsigned int refinement,
    const Parameters& params);

#endif // POISSON_MMS_TEST_H