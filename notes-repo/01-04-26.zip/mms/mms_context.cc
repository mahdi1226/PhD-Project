// ============================================================================
// mms/mms_context.cc - MMS Test Context Implementation
//
// All setup methods call PRODUCTION code from setup/*.h to ensure MMS tests
// validate the actual code paths used in production simulations.
//
// ============================================================================

#include "mms/mms_context.h"

// Production setup functions
#include "setup/ch_setup.h"
#include "setup/ns_setup.h"
#include "setup/poisson_setup.h"
#include "setup/magnetization_setup.h"

// MMS exact solutions and BC functions
#include "mms/ch/ch_mms.h"
#include "mms/ns/ns_mms.h"
#include "mms/poisson/poisson_mms.h"

#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/grid_tools.h>
#include <deal.II/dofs/dof_tools.h>
#include <deal.II/numerics/vector_tools.h>

#include <cmath>
#include <iostream>

// ============================================================================
// Constructor
// ============================================================================
template <int dim>
MMSContext<dim>::MMSContext()
    : theta_dof_handler(triangulation)
    , psi_dof_handler(triangulation)
    , ux_dof_handler(triangulation)
    , uy_dof_handler(triangulation)
    , p_dof_handler(triangulation)
    , phi_dof_handler(triangulation)
    , mx_dof_handler(triangulation)
    , my_dof_handler(triangulation)
{
}

// ============================================================================
// setup_mesh() - Mirrors PhaseFieldProblem::setup_mesh()
// ============================================================================
template <int dim>
void MMSContext<dim>::setup_mesh(const Parameters& params, unsigned int refinement)
{
    // Create rectangular domain with subdivisions
    // EXACTLY like PhaseFieldProblem::setup_mesh()
    dealii::Point<dim> p1(params.domain.x_min, params.domain.y_min);
    dealii::Point<dim> p2(params.domain.x_max, params.domain.y_max);

    std::vector<unsigned int> subdivisions(dim);
    subdivisions[0] = params.domain.initial_cells_x;
    subdivisions[1] = params.domain.initial_cells_y;

    dealii::GridGenerator::subdivided_hyper_rectangle(triangulation, subdivisions, p1, p2);

    // Assign boundary IDs - SAME as production:
    //   0 = bottom (y = y_min)
    //   1 = right  (x = x_max)
    //   2 = top    (y = y_max)
    //   3 = left   (x = x_min)
    for (auto& face : triangulation.active_face_iterators())
    {
        if (!face->at_boundary())
            continue;

        const auto center = face->center();
        const double tol = 1e-10;

        if (std::abs(center[1] - params.domain.y_min) < tol)
            face->set_boundary_id(0);  // bottom
        else if (std::abs(center[0] - params.domain.x_max) < tol)
            face->set_boundary_id(1);  // right
        else if (std::abs(center[1] - params.domain.y_max) < tol)
            face->set_boundary_id(2);  // top
        else if (std::abs(center[0] - params.domain.x_min) < tol)
            face->set_boundary_id(3);  // left
    }

    // Global refinement
    triangulation.refine_global(refinement);

    if (params.output.verbose)
    {
        std::cout << "[MMSContext] Mesh: " << params.domain.initial_cells_x
                  << " x " << params.domain.initial_cells_y << " base cells\n";
        std::cout << "[MMSContext] Refinement " << refinement
                  << " -> " << triangulation.n_active_cells() << " cells\n";
    }
}

// ============================================================================
// setup_ch() - Uses PRODUCTION setup_ch_coupled_system()
// ============================================================================
template <int dim>
void MMSContext<dim>::setup_ch(const Parameters& params, double mms_time)
{
    // Create finite element
    fe_phase = std::make_unique<dealii::FE_Q<dim>>(params.fe.degree_phase);

    // Distribute DoFs
    theta_dof_handler.distribute_dofs(*fe_phase);
    psi_dof_handler.distribute_dofs(*fe_phase);

    const unsigned int n_theta = theta_dof_handler.n_dofs();

    // Reinit solution vectors
    theta_solution.reinit(n_theta);
    theta_old.reinit(n_theta);
    psi_solution.reinit(n_theta);

    // Setup constraints
    if (params.enable_mms)
    {
        // MMS: Apply exact Dirichlet BCs at all boundaries
        apply_ch_mms_boundary_constraints<dim>(
            theta_dof_handler, psi_dof_handler,
            theta_constraints, psi_constraints,
            mms_time);
    }
    else
    {
        // Production BCs: typically no-flux (natural BCs)
        theta_constraints.clear();
        psi_constraints.clear();
        theta_constraints.close();
        psi_constraints.close();
    }

    // PRODUCTION: Setup coupled system (sparsity, combined constraints, maps)
    setup_ch_coupled_system<dim>(
        theta_dof_handler, psi_dof_handler,
        theta_constraints, psi_constraints,
        theta_to_ch_map, psi_to_ch_map,
        ch_constraints, ch_sparsity, false);

    // Reinit matrix and RHS
    ch_matrix.reinit(ch_sparsity);
    ch_rhs.reinit(2 * n_theta);

    if (params.output.verbose)
    {
        std::cout << "[MMSContext] CH DoFs: θ = " << n_theta
                  << ", ψ = " << psi_dof_handler.n_dofs()
                  << ", coupled = " << 2 * n_theta << "\n";
    }
}

// ============================================================================
// setup_ns() - Uses PRODUCTION setup_ns_coupled_system()
// ============================================================================
template <int dim>
void MMSContext<dim>::setup_ns(const Parameters& params, double mms_time)
{
    (void)mms_time;  // Used for L_y calculation if needed

    // Create finite elements (Taylor-Hood: Q2-Q1)
    fe_velocity = std::make_unique<dealii::FE_Q<dim>>(params.fe.degree_velocity);
    fe_pressure = std::make_unique<dealii::FE_Q<dim>>(params.fe.degree_pressure);

    // Distribute DoFs
    ux_dof_handler.distribute_dofs(*fe_velocity);
    uy_dof_handler.distribute_dofs(*fe_velocity);
    p_dof_handler.distribute_dofs(*fe_pressure);

    const unsigned int n_ux = ux_dof_handler.n_dofs();
    const unsigned int n_uy = uy_dof_handler.n_dofs();
    const unsigned int n_p = p_dof_handler.n_dofs();

    // Reinit solution vectors
    ux_solution.reinit(n_ux);
    ux_old.reinit(n_ux);
    uy_solution.reinit(n_uy);
    uy_old.reinit(n_uy);
    p_solution.reinit(n_p);

    // Setup constraints
    if (params.enable_mms)
    {
        // MMS: Exact Dirichlet velocity BCs, mean-zero pressure
        setup_ns_mms_velocity_constraints(
            ux_dof_handler, uy_dof_handler,
            ux_constraints, uy_constraints);
        setup_ns_mms_pressure_constraints(
            p_dof_handler, p_constraints);
    }
    else
    {
        // Production BCs: typically no-slip walls
        ux_constraints.clear();
        uy_constraints.clear();
        p_constraints.clear();

        // No-slip on all boundaries
        dealii::VectorTools::interpolate_boundary_values(
            ux_dof_handler,
            0, dealii::Functions::ZeroFunction<dim>(), ux_constraints);
        dealii::VectorTools::interpolate_boundary_values(
            ux_dof_handler,
            1, dealii::Functions::ZeroFunction<dim>(), ux_constraints);
        dealii::VectorTools::interpolate_boundary_values(
            ux_dof_handler,
            2, dealii::Functions::ZeroFunction<dim>(), ux_constraints);
        dealii::VectorTools::interpolate_boundary_values(
            ux_dof_handler,
            3, dealii::Functions::ZeroFunction<dim>(), ux_constraints);

        dealii::VectorTools::interpolate_boundary_values(
            uy_dof_handler,
            0, dealii::Functions::ZeroFunction<dim>(), uy_constraints);
        dealii::VectorTools::interpolate_boundary_values(
            uy_dof_handler,
            1, dealii::Functions::ZeroFunction<dim>(), uy_constraints);
        dealii::VectorTools::interpolate_boundary_values(
            uy_dof_handler,
            2, dealii::Functions::ZeroFunction<dim>(), uy_constraints);
        dealii::VectorTools::interpolate_boundary_values(
            uy_dof_handler,
            3, dealii::Functions::ZeroFunction<dim>(), uy_constraints);

        ux_constraints.close();
        uy_constraints.close();
        p_constraints.close();
    }

    // PRODUCTION: Setup coupled system
    setup_ns_coupled_system<dim>(
        ux_dof_handler, uy_dof_handler, p_dof_handler,
        ux_constraints, uy_constraints, p_constraints,
        ux_to_ns_map, uy_to_ns_map, p_to_ns_map,
        ns_constraints, ns_sparsity, false);

    // Reinit matrix and vectors
    const unsigned int n_ns = n_ux + n_uy + n_p;
    ns_matrix.reinit(ns_sparsity);
    ns_rhs.reinit(n_ns);
    ns_solution.reinit(n_ns);

    if (params.output.verbose)
    {
        std::cout << "[MMSContext] NS DoFs: ux = " << n_ux
                  << ", uy = " << n_uy
                  << ", p = " << n_p
                  << ", coupled = " << n_ns << "\n";
    }
}

// ============================================================================
// setup_poisson() - Uses PRODUCTION setup_poisson_constraints_and_sparsity()
// ============================================================================
template <int dim>
void MMSContext<dim>::setup_poisson(const Parameters& params)
{
    // Create finite element
    fe_potential = std::make_unique<dealii::FE_Q<dim>>(params.fe.degree_potential);

    // Distribute DoFs
    phi_dof_handler.distribute_dofs(*fe_potential);

    const unsigned int n_phi = phi_dof_handler.n_dofs();

    // Reinit vectors
    phi_solution.reinit(n_phi);
    phi_rhs.reinit(n_phi);

    // PRODUCTION: Setup constraints and sparsity
    setup_poisson_constraints_and_sparsity(
        phi_dof_handler, phi_constraints, phi_sparsity, false);

    // Reinit matrix
    phi_matrix.reinit(phi_sparsity);

    if (params.output.verbose)
    {
        std::cout << "[MMSContext] Poisson DoFs: φ = " << n_phi << "\n";
    }
}

// ============================================================================
// setup_magnetization() - DG setup for Mx, My
// ============================================================================
template <int dim>
void MMSContext<dim>::setup_magnetization(const Parameters& params)
{
    // Create DG finite element
    fe_mag = std::make_unique<dealii::FE_DGQ<dim>>(params.fe.degree_magnetization);

    // Distribute DoFs
    mx_dof_handler.distribute_dofs(*fe_mag);
    my_dof_handler.distribute_dofs(*fe_mag);

    const unsigned int n_M = mx_dof_handler.n_dofs();

    // Setup sparsity pattern using PRODUCTION function
    setup_magnetization_sparsity(mx_dof_handler, mx_sparsity, false);

    // Reinit vectors
    mx_solution.reinit(n_M);
    mx_old.reinit(n_M);
    my_solution.reinit(n_M);
    my_old.reinit(n_M);

    // Initialize to zero
    mx_solution = 0;
    mx_old = 0;
    my_solution = 0;
    my_old = 0;

    if (params.output.verbose)
    {
        std::cout << "[MMSContext] Magnetization DoFs: Mx = My = " << n_M
                  << " (DG" << fe_mag->degree << ")\n";
    }
}

// ============================================================================
// Initial Conditions
// ============================================================================

template <int dim>
void MMSContext<dim>::apply_ch_initial_conditions(const Parameters& params, double t_init)
{
    if (params.enable_mms)
    {
        // MMS: Use exact solutions
        apply_ch_mms_initial_conditions<dim>(
            theta_dof_handler, psi_dof_handler,
            theta_solution, psi_solution,
            t_init);
    }
    else
    {
        // Production: θ = tanh profile, ψ = 0
        theta_solution = 0;
        psi_solution = 0;
    }

    theta_old = theta_solution;
}

template <int dim>
void MMSContext<dim>::apply_ns_initial_conditions(const Parameters& params, double t_init)
{
    const double L_y = params.domain.y_max - params.domain.y_min;

    if (params.enable_mms)
    {
        // MMS: Use exact solutions
        NSExactVelocityX<dim> exact_ux(t_init, L_y);
        NSExactVelocityY<dim> exact_uy(t_init, L_y);
        NSExactPressure<dim> exact_p(t_init, L_y);

        dealii::VectorTools::interpolate(ux_dof_handler, exact_ux, ux_solution);
        dealii::VectorTools::interpolate(uy_dof_handler, exact_uy, uy_solution);
        dealii::VectorTools::interpolate(p_dof_handler, exact_p, p_solution);
    }
    else
    {
        // Production: Zero velocity, zero pressure
        ux_solution = 0;
        uy_solution = 0;
        p_solution = 0;
    }

    ux_old = ux_solution;
    uy_old = uy_solution;
}

template <int dim>
void MMSContext<dim>::apply_poisson_initial_conditions(const Parameters& params, double t_init)
{
    const double L_y = params.domain.y_max - params.domain.y_min;

    if (params.enable_mms)
    {
        // MMS: Use exact solution
        PoissonExactSolution<dim> exact_phi(t_init, L_y);
        dealii::VectorTools::interpolate(phi_dof_handler, exact_phi, phi_solution);
    }
    else
    {
        // Production: Zero
        phi_solution = 0;
    }
}

template <int dim>
void MMSContext<dim>::apply_magnetization_initial_conditions(const Parameters& params)
{
    (void)params;

    // Always initialize to zero; M will relax to equilibrium
    mx_solution = 0;
    mx_old = 0;
    my_solution = 0;
    my_old = 0;
}

// ============================================================================
// Constraint Updates (for time-dependent MMS BCs)
// ============================================================================

template <int dim>
void MMSContext<dim>::update_ch_constraints(const Parameters& params, double time)
{
    if (!params.enable_mms)
        return;

    // Re-apply MMS boundary constraints at new time
    apply_ch_mms_boundary_constraints<dim>(
        theta_dof_handler, psi_dof_handler,
        theta_constraints, psi_constraints,
        time);

    // Rebuild combined constraints
    // Note: This may require rebuilding ch_constraints if inhomogeneities changed
    // For now, assume the sparsity pattern doesn't change, only inhomogeneities
    ch_constraints.clear();

    // Re-merge constraints
    for (unsigned int i = 0; i < theta_dof_handler.n_dofs(); ++i)
    {
        if (theta_constraints.is_constrained(i))
        {
            ch_constraints.add_line(theta_to_ch_map[i]);
            ch_constraints.set_inhomogeneity(
                theta_to_ch_map[i], theta_constraints.get_inhomogeneity(i));
        }
        if (psi_constraints.is_constrained(i))
        {
            ch_constraints.add_line(psi_to_ch_map[i]);
            ch_constraints.set_inhomogeneity(
                psi_to_ch_map[i], psi_constraints.get_inhomogeneity(i));
        }
    }
    ch_constraints.close();
}

template <int dim>
void MMSContext<dim>::update_ns_constraints(const Parameters& params, double time)
{
    if (!params.enable_mms)
        return;

    const double L_y = params.domain.y_max - params.domain.y_min;

    // Re-apply MMS boundary constraints at new time
    // Note: NS MMS uses time-independent zero BCs, so this may not be needed
    // But keeping for generality
    (void)time;
    (void)L_y;
}

// ============================================================================
// Convenience Methods
// ============================================================================

template <int dim>
double MMSContext<dim>::get_min_h() const
{
    return dealii::GridTools::minimal_cell_diameter(triangulation);
}

// ============================================================================
// Explicit Template Instantiation for dim=2
// ============================================================================

template struct MMSContext<2>;

// Uncomment for 3D support:
// template struct MMSContext<3>;