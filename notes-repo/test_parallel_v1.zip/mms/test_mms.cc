// ============================================================================
// mms/test_mms.cc - MMS Test Driver (PARALLEL)
//
// Available: CH_STANDALONE, POISSON_STANDALONE, MAGNETIZATION_STANDALONE
// Other subsystems will throw runtime_error until converted.
// ============================================================================

#include "mms/mms_verification.h"
#include "utilities/parameters.h"

#include <deal.II/base/utilities.h>
#include <deal.II/base/mpi.h>

#include <iostream>
#include <string>
#include <vector>

int main(int argc, char* argv[])
{
    // Initialize MPI
    dealii::Utilities::MPI::MPI_InitFinalize mpi_init(argc, argv);

    const unsigned int this_rank = dealii::Utilities::MPI::this_mpi_process(MPI_COMM_WORLD);
    const unsigned int n_ranks = dealii::Utilities::MPI::n_mpi_processes(MPI_COMM_WORLD);

    // Parse command line
    MMSLevel level = MMSLevel::CH_STANDALONE;
    std::vector<unsigned int> refinements = {3, 4, 5};
    unsigned int n_time_steps = 10;

    for (int i = 1; i < argc; ++i)
    {
        std::string arg = argv[i];
        if (arg == "--level" && i + 1 < argc)
        {
            std::string level_str = argv[++i];
            if (level_str == "CH_STANDALONE")
                level = MMSLevel::CH_STANDALONE;
            else if (level_str == "POISSON_STANDALONE")
                level = MMSLevel::POISSON_STANDALONE;
            else if (level_str == "NS_STANDALONE")
                level = MMSLevel::NS_STANDALONE;
            else if (level_str == "MAGNETIZATION_STANDALONE")
                level = MMSLevel::MAGNETIZATION_STANDALONE;
            else
            {
                if (this_rank == 0)
                    std::cerr << "Unknown level: " << level_str << "\n";
                return 1;
            }
        }
        else if (arg == "--refs" && i + 1 < argc)
        {
            refinements.clear();
            while (i + 1 < argc && argv[i + 1][0] != '-')
            {
                refinements.push_back(std::stoi(argv[++i]));
            }
        }
        else if (arg == "--steps" && i + 1 < argc)
        {
            n_time_steps = std::stoi(argv[++i]);
        }
        else if (arg == "--help" || arg == "-h")
        {
            if (this_rank == 0)
            {
                std::cout << "Usage: " << argv[0] << " [options]\n"
                          << "Options:\n"
                          << "  --level <LEVEL>      MMS test level (default: CH_STANDALONE)\n"
                          << "                       Available: CH_STANDALONE, POISSON_STANDALONE, MAGNETIZATION_STANDALONE\n"
                          << "                       Not yet: NS_STANDALONE\n"
                          << "  --refs <r1> <r2> ... Refinement levels (default: 3 4 5)\n"
                          << "  --steps <n>          Number of time steps (default: 10)\n"
                          << "  --help               Show this help\n";
            }
            return 0;
        }
    }

    // Setup parameters
    Parameters params;
    params.physics.epsilon = 0.01;
    params.physics.mobility = 1.0;
    params.fe.degree_phase = 2;

    // Setup solver parameters
    params.solvers.ch.type = LinearSolverParams::Type::GMRES;
    params.solvers.ch.preconditioner = LinearSolverParams::Preconditioner::AMG;
    params.solvers.ch.rel_tolerance = 1e-8;
    params.solvers.ch.abs_tolerance = 1e-12;
    params.solvers.ch.max_iterations = 500;
    params.solvers.ch.use_iterative = true;
    params.solvers.ch.fallback_to_direct = true;

    if (this_rank == 0)
    {
        std::cout << "\n=== Parallel CH MMS Test ===\n";
        std::cout << "MPI ranks: " << n_ranks << "\n";
        std::cout << "Level: " << to_string(level) << "\n";
        std::cout << "Refinements:";
        for (auto r : refinements) std::cout << " " << r;
        std::cout << "\n";
        std::cout << "Time steps: " << n_time_steps << "\n";
        std::cout << "============================\n\n";
    }

    // Run test
    try
    {
        MMSConvergenceResult result = run_mms_test(
            level, refinements, params, n_time_steps, MPI_COMM_WORLD);

        if (this_rank == 0)
        {
            result.print();
            result.write_csv("ch_mms_parallel_results.csv");
        }

        return result.passes() ? 0 : 1;
    }
    catch (const std::exception& e)
    {
        if (this_rank == 0)
            std::cerr << "\n[ERROR] " << e.what() << "\n";
        return 1;
    }
}