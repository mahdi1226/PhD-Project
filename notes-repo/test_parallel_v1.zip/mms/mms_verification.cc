// ============================================================================
// mms/mms_verification.cc - MMS Verification Implementation (PARALLEL VERSION)
//
// PARALLEL STATUS:
//   - CH_STANDALONE: CONVERTED ✓
//   - POISSON_STANDALONE: CONVERTED ✓
//   - NS_STANDALONE: CONVERTED ✓
//   - MAGNETIZATION_STANDALONE: CONVERTED ✓
//   - All others: NOT YET CONVERTED (will throw runtime_error)
//
// Uses MMSContext for setup, which calls PRODUCTION code:
// - CH: ch_setup.h + ch_assembler.h + ch_solver.h
// - NS: ns_setup.h + ns_assembler.h + ns_solver.h + ns_block_preconditioner.h
// ============================================================================

#include "mms/mms_verification.h"
#include "mms/mms_context.h"

// MMS exact solutions and error computation
#include "mms/ch/ch_mms.h"
#include "mms/poisson/poisson_mms.h"

// Production assembly
#include "assembly/ch_assembler.h"

// Production solvers
#include "solvers/ch_solver.h"

// MMS test modules (converted to parallel)
#include "mms/ch/ch_mms_test.h"
#include "mms/poisson/poisson_mms_test.h"
#include "mms/ns/ns_mms_test.h"
#include "mms/magnetization/magnetization_mms_test.h"

#include <deal.II/base/utilities.h>

#include <iostream>
#include <iomanip>
#include <fstream>
#include <chrono>
#include <cmath>
#include <stdexcept>

//constexpr int dim = 2;

// ============================================================================
// Helper: compute convergence rate
// ============================================================================

static double compute_single_rate(double e_fine, double e_coarse,
                                  double h_fine, double h_coarse)
{
    if (e_coarse < 1e-15 || e_fine < 1e-15) return 0.0;
    return std::log(e_coarse / e_fine) / std::log(h_coarse / h_fine);
}

static void fill_rates(const std::vector<double>& errors,
                       const std::vector<double>& h_values,
                       std::vector<double>& rates)
{
    rates.clear();
    for (size_t i = 1; i < errors.size(); ++i)
        rates.push_back(compute_single_rate(errors[i], errors[i - 1],
                                            h_values[i], h_values[i - 1]));
}

// ============================================================================
// MMSConvergenceResult Implementation
// ============================================================================

void MMSConvergenceResult::compute_rates()
{
    fill_rates(theta_L2, h_values, theta_L2_rate);
    fill_rates(theta_H1, h_values, theta_H1_rate);
    fill_rates(psi_L2, h_values, psi_L2_rate);
    fill_rates(phi_L2, h_values, phi_L2_rate);
    fill_rates(phi_H1, h_values, phi_H1_rate);
    fill_rates(ux_L2, h_values, ux_L2_rate);
    fill_rates(ux_H1, h_values, ux_H1_rate);
    fill_rates(uy_L2, h_values, uy_L2_rate);
    fill_rates(uy_H1, h_values, uy_H1_rate);
    fill_rates(p_L2, h_values, p_L2_rate);
    fill_rates(M_L2, h_values, M_L2_rate);
    fill_rates(div_u_L2, h_values, div_u_L2_rate);
}

void MMSConvergenceResult::print() const
{
    std::cout << "\n========================================\n";
    std::cout << "MMS Convergence Results: " << to_string(level) << "\n";
    std::cout << "========================================\n";

    // Print appropriate table based on level
    switch (level)
    {
    case MMSLevel::CH_STANDALONE:
        print_ch_table();
        break;
    case MMSLevel::POISSON_STANDALONE:
        print_poisson_table();
        break;
    case MMSLevel::NS_STANDALONE:
        print_ns_table();
        break;
    case MMSLevel::MAGNETIZATION_STANDALONE:
        print_magnetization_table();
        break;
    case MMSLevel::POISSON_MAGNETIZATION:
        print_poisson_table();
        break;
    case MMSLevel::CH_NS_CAPILLARY:
        print_ns_table();
        break;
    case MMSLevel::NS_MAGNETIZATION:
        print_ns_table();
        break;
    case MMSLevel::NS_VARIABLE_NU:
        print_ns_table();
        break;
    default:
        std::cout << "Unknown test level\n";
    }

    std::cout << "========================================\n";
    if (passes())
        std::cout << "[PASS] Convergence rates within tolerance!\n";
    else
        std::cout << "[FAIL] Some rates below expected!\n";
}

void MMSConvergenceResult::print_ch_table() const
{
    std::cout << std::left
        << std::setw(6) << "Ref"
        << std::setw(12) << "h"
        << std::setw(12) << "θ_L2"
        << std::setw(8) << "rate"
        << std::setw(12) << "θ_H1"
        << std::setw(8) << "rate"
        << "\n";
    std::cout << std::string(58, '-') << "\n";

    for (size_t i = 0; i < refinements.size(); ++i)
    {
        std::cout << std::left << std::setw(6) << refinements[i]
            << std::scientific << std::setprecision(2)
            << std::setw(12) << h_values[i]
            << std::setw(12) << theta_L2[i]
            << std::fixed << std::setprecision(2)
            << std::setw(8) << (i > 0 ? theta_L2_rate[i - 1] : 0.0)
            << std::scientific << std::setprecision(2)
            << std::setw(12) << theta_H1[i]
            << std::fixed << std::setprecision(2)
            << std::setw(8) << (i > 0 ? theta_H1_rate[i - 1] : 0.0)
            << "\n";
    }
}

void MMSConvergenceResult::print_poisson_table() const
{
    std::cout << std::left
        << std::setw(6) << "Ref"
        << std::setw(12) << "h"
        << std::setw(12) << "φ_L2"
        << std::setw(8) << "rate"
        << std::setw(12) << "φ_H1"
        << std::setw(8) << "rate"
        << "\n";
    std::cout << std::string(58, '-') << "\n";

    for (size_t i = 0; i < refinements.size(); ++i)
    {
        std::cout << std::left << std::setw(6) << refinements[i]
            << std::scientific << std::setprecision(2)
            << std::setw(12) << h_values[i]
            << std::setw(12) << phi_L2[i]
            << std::fixed << std::setprecision(2)
            << std::setw(8) << (i > 0 ? phi_L2_rate[i - 1] : 0.0)
            << std::scientific << std::setprecision(2)
            << std::setw(12) << phi_H1[i]
            << std::fixed << std::setprecision(2)
            << std::setw(8) << (i > 0 ? phi_H1_rate[i - 1] : 0.0)
            << "\n";
    }
}

void MMSConvergenceResult::print_ns_table() const
{
    std::cout << std::left
        << std::setw(6) << "Ref"
        << std::setw(10) << "h"
        << std::setw(10) << "ux_L2"
        << std::setw(7) << "rate"
        << std::setw(10) << "ux_H1"
        << std::setw(7) << "rate"
        << std::setw(10) << "p_L2"
        << std::setw(7) << "rate"
        << "\n";
    std::cout << std::string(67, '-') << "\n";

    for (size_t i = 0; i < refinements.size(); ++i)
    {
        std::cout << std::left << std::setw(6) << refinements[i]
            << std::scientific << std::setprecision(2)
            << std::setw(10) << h_values[i]
            << std::setw(10) << ux_L2[i]
            << std::fixed << std::setprecision(2)
            << std::setw(7) << (i > 0 ? ux_L2_rate[i - 1] : 0.0)
            << std::scientific << std::setprecision(2)
            << std::setw(10) << ux_H1[i]
            << std::fixed << std::setprecision(2)
            << std::setw(7) << (i > 0 ? ux_H1_rate[i - 1] : 0.0)
            << std::scientific << std::setprecision(2)
            << std::setw(10) << p_L2[i]
            << std::fixed << std::setprecision(2)
            << std::setw(7) << (i > 0 ? p_L2_rate[i - 1] : 0.0)
            << "\n";
    }
}

void MMSConvergenceResult::print_magnetization_table() const
{
    std::cout << std::left
        << std::setw(6) << "Ref"
        << std::setw(12) << "h"
        << std::setw(12) << "M_L2"
        << std::setw(8) << "rate"
        << "\n";
    std::cout << std::string(38, '-') << "\n";

    for (size_t i = 0; i < refinements.size(); ++i)
    {
        std::cout << std::left << std::setw(6) << refinements[i]
            << std::scientific << std::setprecision(2)
            << std::setw(12) << h_values[i]
            << std::setw(12) << M_L2[i]
            << std::fixed << std::setprecision(2)
            << std::setw(8) << (i > 0 ? M_L2_rate[i - 1] : 0.0)
            << "\n";
    }
}

bool MMSConvergenceResult::passes(double tolerance) const
{
    // Check based on level
    switch (level)
    {
    case MMSLevel::CH_STANDALONE:
        if (theta_L2_rate.empty()) return false;
        return (theta_L2_rate.back() >= expected_L2_rate - tolerance) &&
               (theta_H1_rate.back() >= expected_H1_rate - tolerance);

    case MMSLevel::POISSON_STANDALONE:
    case MMSLevel::POISSON_MAGNETIZATION:
        if (phi_L2_rate.empty()) return false;
        return (phi_L2_rate.back() >= expected_L2_rate - tolerance) &&
               (phi_H1_rate.back() >= expected_H1_rate - tolerance);

    case MMSLevel::NS_STANDALONE:
    case MMSLevel::CH_NS_CAPILLARY:
    case MMSLevel::NS_MAGNETIZATION:
    case MMSLevel::NS_VARIABLE_NU:
        if (ux_L2_rate.empty()) return false;
        return (ux_L2_rate.back() >= expected_L2_rate - tolerance);

    case MMSLevel::MAGNETIZATION_STANDALONE:
        if (M_L2_rate.empty()) return false;
        return (M_L2_rate.back() >= expected_L2_rate - tolerance);

    default:
        return false;
    }
}

// ============================================================================
// CH_STANDALONE - Wrapper that calls ch_mms_test module (PARALLEL)
// ============================================================================

static MMSConvergenceResult run_ch_standalone(
    const std::vector<unsigned int>& refinements,
    Parameters params,
    unsigned int n_time_steps,
    MPI_Comm mpi_communicator)
{
    // Call production test module (converted to parallel)
    CHMMSConvergenceResult ch_result = run_ch_mms_standalone(
        refinements, params, CHSolverType::GMRES_AMG, n_time_steps, mpi_communicator);

    // Convert to generic MMSConvergenceResult
    MMSConvergenceResult result;
    result.level = MMSLevel::CH_STANDALONE;
    result.fe_degree = ch_result.fe_degree;
    result.n_time_steps = ch_result.n_time_steps;
    result.dt = ch_result.dt;
    result.expected_L2_rate = ch_result.expected_L2_rate;
    result.expected_H1_rate = ch_result.expected_H1_rate;

    for (size_t i = 0; i < ch_result.results.size(); ++i)
    {
        const auto& r = ch_result.results[i];
        result.refinements.push_back(r.refinement);
        result.h_values.push_back(r.h);
        result.theta_L2.push_back(r.theta_L2);
        result.theta_H1.push_back(r.theta_H1);
        result.psi_L2.push_back(r.psi_L2);
        result.n_dofs.push_back(r.n_dofs);
        result.wall_times.push_back(r.total_time);
    }

    result.compute_rates();
    return result;
}

// ============================================================================
// POISSON_STANDALONE - Wrapper that calls poisson_mms_test module
// ============================================================================

static MMSConvergenceResult run_poisson_standalone(
    const std::vector<unsigned int>& refinements,
    Parameters params,
    MPI_Comm mpi_communicator)
{
    // Call production test module (converted to parallel)
    PoissonMMSConvergenceResult poisson_result = run_poisson_mms_standalone(
        refinements, params, PoissonSolverType::AMG, mpi_communicator);

    // Convert to generic MMSConvergenceResult
    MMSConvergenceResult result;
    result.level = MMSLevel::POISSON_STANDALONE;
    result.fe_degree = poisson_result.fe_degree;
    result.expected_L2_rate = poisson_result.expected_L2_rate;
    result.expected_H1_rate = poisson_result.expected_H1_rate;

    for (size_t i = 0; i < poisson_result.results.size(); ++i)
    {
        const auto& r = poisson_result.results[i];
        result.refinements.push_back(r.refinement);
        result.h_values.push_back(r.h);
        result.phi_L2.push_back(r.L2_error);
        result.phi_H1.push_back(r.H1_error);
        result.n_dofs.push_back(r.n_dofs);
        result.wall_times.push_back(r.total_time);
    }

    result.compute_rates();
    return result;
}

// ============================================================================
// MAGNETIZATION_STANDALONE - Wrapper that calls magnetization_mms_test module
// ============================================================================

static MMSConvergenceResult run_magnetization_standalone(
    const std::vector<unsigned int>& refinements,
    Parameters params,
    MPI_Comm mpi_communicator)
{
    // Call production test module (converted to parallel)
    MagMMSConvergenceResult mag_result = run_magnetization_mms_standalone(
        refinements, params, MagSolverType::GMRES, mpi_communicator);

    // Convert to generic MMSConvergenceResult
    MMSConvergenceResult result;
    result.level = MMSLevel::MAGNETIZATION_STANDALONE;
    result.fe_degree = mag_result.fe_degree;
    result.expected_L2_rate = mag_result.expected_L2_rate;

    for (size_t i = 0; i < mag_result.results.size(); ++i)
    {
        const auto& r = mag_result.results[i];
        result.refinements.push_back(r.refinement);
        result.h_values.push_back(r.h);
        result.M_L2.push_back(r.M_L2);
        result.n_dofs.push_back(r.n_dofs);
        result.wall_times.push_back(r.total_time);
    }

    result.compute_rates();
    return result;
}

// ============================================================================
// NS_STANDALONE - Wrapper that calls ns_mms_test module
// ============================================================================

static MMSConvergenceResult run_ns_standalone(
    const std::vector<unsigned int>& refinements,
    Parameters params,
    MPI_Comm mpi_communicator)
{
    // Call production test module (converted to parallel)
    NSMMSConvergenceResult ns_result = run_ns_mms_standalone(
        refinements, params, mpi_communicator);

    // Convert to generic MMSConvergenceResult
    MMSConvergenceResult result;
    result.level = MMSLevel::NS_STANDALONE;
    result.fe_degree = ns_result.fe_degree_velocity;
    result.expected_L2_rate = ns_result.expected_vel_L2_rate;
    result.expected_H1_rate = ns_result.expected_vel_H1_rate;

    for (size_t i = 0; i < ns_result.results.size(); ++i)
    {
        const auto& r = ns_result.results[i];
        result.refinements.push_back(r.refinement);
        result.h_values.push_back(r.h);
        result.n_dofs.push_back(r.n_dofs);
        result.wall_times.push_back(r.total_time);

        // NS errors
        result.ux_L2.push_back(r.ux_L2);
        result.ux_H1.push_back(r.ux_H1);
        result.uy_L2.push_back(r.uy_L2);
        result.uy_H1.push_back(r.uy_H1);
        result.p_L2.push_back(r.p_L2);
        result.div_u_L2.push_back(r.div_U_L2);
    }

    result.compute_rates();
    return result;
}

// ============================================================================
// Main dispatcher (PARALLEL)
// ============================================================================

MMSConvergenceResult run_mms_test(
    MMSLevel level,
    const std::vector<unsigned int>& refinements,
    const Parameters& params,
    unsigned int n_time_steps,
    MPI_Comm mpi_communicator)
{
    Parameters mutable_params = params;

    switch (level)
    {
    case MMSLevel::CH_STANDALONE:
        return run_ch_standalone(refinements, mutable_params, n_time_steps, mpi_communicator);

    case MMSLevel::POISSON_STANDALONE:
        return run_poisson_standalone(refinements, mutable_params, mpi_communicator);

    case MMSLevel::NS_STANDALONE:
        return run_ns_standalone(refinements, mutable_params, mpi_communicator);

    case MMSLevel::MAGNETIZATION_STANDALONE:
        return run_magnetization_standalone(refinements, mutable_params, mpi_communicator);

    // ========================================================================
    // NOT YET CONVERTED TO PARALLEL - Will be added incrementally
    // ========================================================================
    case MMSLevel::POISSON_MAGNETIZATION:
        throw std::runtime_error(
            "POISSON_MAGNETIZATION not yet converted to parallel.\n"
            "Only CH_STANDALONE is currently available.\n"
            "Conversion order: CH → Poisson → NS → Magnetization → Coupled");

    case MMSLevel::CH_NS_CAPILLARY:
        throw std::runtime_error(
            "CH_NS_CAPILLARY not yet converted to parallel.\n"
            "Only CH_STANDALONE is currently available.\n"
            "Conversion order: CH → Poisson → NS → Magnetization → Coupled");

    case MMSLevel::NS_MAGNETIZATION:
        throw std::runtime_error(
            "NS_MAGNETIZATION not yet converted to parallel.\n"
            "Only CH_STANDALONE is currently available.\n"
            "Conversion order: CH → Poisson → NS → Magnetization → Coupled");

    case MMSLevel::NS_VARIABLE_NU:
        throw std::runtime_error(
            "NS_VARIABLE_NU not yet converted to parallel.\n"
            "Only CH_STANDALONE is currently available.\n"
            "Conversion order: CH → Poisson → NS → Magnetization → Coupled");

    default:
        std::cerr << "[ERROR] Unknown MMS level: " << static_cast<int>(level) << "\n";
        return MMSConvergenceResult{};
    }
}

// ============================================================================
// Backward-compatible interface (defaults to MPI_COMM_WORLD)
// ============================================================================

MMSConvergenceResult run_mms_test(
    MMSLevel level,
    const std::vector<unsigned int>& refinements,
    const Parameters& params,
    unsigned int n_time_steps)
{
    return run_mms_test(level, refinements, params, n_time_steps, MPI_COMM_WORLD);
}

MMSConvergenceResult run_mms_convergence_study(
    MMSLevel level,
    const std::vector<unsigned int>& refinements,
    const Parameters& params,
    unsigned int n_time_steps)
{
    return run_mms_test(level, refinements, params, n_time_steps, MPI_COMM_WORLD);
}

// ============================================================================
// Write results to CSV
// ============================================================================

void MMSConvergenceResult::write_csv(const std::string& filename) const
{
    std::ofstream file(filename);
    if (!file.is_open())
    {
        std::cerr << "[MMS] Failed to open " << filename << " for writing\n";
        return;
    }

    // Header
    file << "refinement,h,n_dofs,wall_time";

    // Add columns based on test level
    switch (level)
    {
    case MMSLevel::CH_STANDALONE:
        file << ",theta_L2,theta_L2_rate,theta_H1,theta_H1_rate,psi_L2,psi_L2_rate";
        break;
    case MMSLevel::POISSON_STANDALONE:
    case MMSLevel::POISSON_MAGNETIZATION:
        file << ",phi_L2,phi_L2_rate,phi_H1,phi_H1_rate";
        break;
    case MMSLevel::NS_STANDALONE:
    case MMSLevel::CH_NS_CAPILLARY:
    case MMSLevel::NS_MAGNETIZATION:
    case MMSLevel::NS_VARIABLE_NU:
        file << ",ux_L2,ux_L2_rate,ux_H1,ux_H1_rate,p_L2,p_L2_rate,div_u_L2";
        break;
    case MMSLevel::MAGNETIZATION_STANDALONE:
        file << ",M_L2,M_L2_rate";
        break;
    default:
        break;
    }
    file << "\n";

    // Data rows
    for (size_t i = 0; i < refinements.size(); ++i)
    {
        file << refinements[i] << ","
            << std::scientific << std::setprecision(6) << h_values[i] << ","
            << n_dofs[i] << ","
            << std::fixed << std::setprecision(4) << wall_times[i];

        switch (level)
        {
        case MMSLevel::CH_STANDALONE:
            file << "," << std::scientific << theta_L2[i]
                << "," << std::fixed << std::setprecision(2)
                << (i > 0 ? theta_L2_rate[i - 1] : 0.0)
                << "," << std::scientific << theta_H1[i]
                << "," << std::fixed << (i > 0 ? theta_H1_rate[i - 1] : 0.0)
                << "," << std::scientific << psi_L2[i]
                << "," << std::fixed << (i > 0 ? psi_L2_rate[i - 1] : 0.0);
            break;
        case MMSLevel::POISSON_STANDALONE:
        case MMSLevel::POISSON_MAGNETIZATION:
            file << "," << std::scientific << phi_L2[i]
                << "," << std::fixed << (i > 0 ? phi_L2_rate[i - 1] : 0.0)
                << "," << std::scientific << phi_H1[i]
                << "," << std::fixed << (i > 0 ? phi_H1_rate[i - 1] : 0.0);
            break;
        case MMSLevel::NS_STANDALONE:
        case MMSLevel::CH_NS_CAPILLARY:
        case MMSLevel::NS_MAGNETIZATION:
        case MMSLevel::NS_VARIABLE_NU:
            file << "," << std::scientific << ux_L2[i]
                << "," << std::fixed << (i > 0 ? ux_L2_rate[i - 1] : 0.0)
                << "," << std::scientific << ux_H1[i]
                << "," << std::fixed << (i > 0 ? ux_H1_rate[i - 1] : 0.0)
                << "," << std::scientific << p_L2[i]
                << "," << std::fixed << (i > 0 ? p_L2_rate[i - 1] : 0.0)
                << "," << std::scientific << div_u_L2[i];
            break;
        case MMSLevel::MAGNETIZATION_STANDALONE:
            file << "," << std::scientific << M_L2[i]
                << "," << std::fixed << (i > 0 ? M_L2_rate[i - 1] : 0.0);
            break;
        default:
            break;
        }
        file << "\n";
    }

    file.close();
    std::cout << "[MMS] Results written to " << filename << "\n";
}

// ============================================================================
// to_string helper
// ============================================================================

std::string to_string(MMSLevel level)
{
    switch (level)
    {
    case MMSLevel::CH_STANDALONE:          return "CH_STANDALONE";
    case MMSLevel::POISSON_STANDALONE:     return "POISSON_STANDALONE";
    case MMSLevel::NS_STANDALONE:          return "NS_STANDALONE";
    case MMSLevel::MAGNETIZATION_STANDALONE: return "MAGNETIZATION_STANDALONE";
    case MMSLevel::POISSON_MAGNETIZATION:  return "POISSON_MAGNETIZATION";
    case MMSLevel::CH_NS_CAPILLARY:        return "CH_NS_CAPILLARY";
    case MMSLevel::NS_MAGNETIZATION:       return "NS_MAGNETIZATION";
    case MMSLevel::NS_VARIABLE_NU:         return "NS_VARIABLE_NU";
    default:                               return "UNKNOWN";
    }
}