// ============================================================================
// mms/mms_verification.h - MMS Verification Interface (PARALLEL VERSION)
//
// PARALLEL STATUS:
//   - CH_STANDALONE: CONVERTED ✓
//   - All others: NOT YET CONVERTED (will throw runtime_error)
// ============================================================================
#ifndef MMS_VERIFICATION_H
#define MMS_VERIFICATION_H

#include "utilities/parameters.h"
#include <mpi.h>
#include <vector>
#include <string>

// ============================================================================
// MMS Test Levels
// ============================================================================
enum class MMSLevel
{
    CH_STANDALONE,           // Cahn-Hilliard only (CONVERTED ✓)
    POISSON_STANDALONE,      // Poisson only (NOT YET)
    NS_STANDALONE,           // Navier-Stokes only (NOT YET)
    MAGNETIZATION_STANDALONE,// Magnetization only (NOT YET)
    POISSON_MAGNETIZATION,   // Poisson + Magnetization (NOT YET)
    CH_NS_CAPILLARY,         // CH + NS with capillary (NOT YET)
    NS_MAGNETIZATION,        // NS + Magnetization (NOT YET)
    NS_VARIABLE_NU           // NS with variable viscosity (NOT YET)
};

std::string to_string(MMSLevel level);

// ============================================================================
// Convergence study result
// ============================================================================
struct MMSConvergenceResult
{
    MMSLevel level;
    unsigned int fe_degree = 2;
    unsigned int n_time_steps = 10;
    double dt = 0.0;
    double expected_L2_rate = 3.0;
    double expected_H1_rate = 2.0;

    // Data for each refinement level
    std::vector<unsigned int> refinements;
    std::vector<double> h_values;
    std::vector<unsigned int> n_dofs;
    std::vector<double> wall_times;

    // CH errors
    std::vector<double> theta_L2, theta_H1, psi_L2;
    std::vector<double> theta_L2_rate, theta_H1_rate, psi_L2_rate;

    // Poisson errors
    std::vector<double> phi_L2, phi_H1;
    std::vector<double> phi_L2_rate, phi_H1_rate;

    // NS errors
    std::vector<double> ux_L2, ux_H1, uy_L2, uy_H1, p_L2, div_u_L2;
    std::vector<double> ux_L2_rate, ux_H1_rate, uy_L2_rate, uy_H1_rate, p_L2_rate, div_u_L2_rate;

    // Magnetization errors
    std::vector<double> M_L2;
    std::vector<double> M_L2_rate;

    void compute_rates();
    void print() const;
    void write_csv(const std::string& filename) const;
    bool passes(double tolerance = 0.3) const;

    // Table printers
    void print_ch_table() const;
    void print_poisson_table() const;
    void print_ns_table() const;
    void print_magnetization_table() const;
};

// ============================================================================
// Main test function (PARALLEL)
// ============================================================================

/**
 * @brief Run MMS convergence study
 *
 * @param level Which subsystem(s) to test
 * @param refinements Vector of refinement levels
 * @param params Simulation parameters
 * @param n_time_steps Number of time steps
 * @param mpi_communicator MPI communicator
 * @return Convergence results
 *
 * @throws std::runtime_error if level is not yet converted to parallel
 */
MMSConvergenceResult run_mms_test(
    MMSLevel level,
    const std::vector<unsigned int>& refinements,
    const Parameters& params,
    unsigned int n_time_steps,
    MPI_Comm mpi_communicator);

// Backward-compatible interface (defaults to MPI_COMM_WORLD)
MMSConvergenceResult run_mms_test(
    MMSLevel level,
    const std::vector<unsigned int>& refinements,
    const Parameters& params,
    unsigned int n_time_steps = 10);

// Alias for backward compatibility
MMSConvergenceResult run_mms_convergence_study(
    MMSLevel level,
    const std::vector<unsigned int>& refinements,
    const Parameters& params,
    unsigned int n_time_steps = 10);

#endif // MMS_VERIFICATION_H