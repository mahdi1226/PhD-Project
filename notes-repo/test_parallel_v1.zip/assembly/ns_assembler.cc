// ============================================================================
// ns_assembler.cc - Parallel Navier-Stokes MMS Assembler Implementation
//
// Reference: Nochetto, Salgado & Tomas, CMAME 309 (2016) 497-531
// ============================================================================

#include "ns_assembler.h"
#include "mms/ns/ns_mms.h"

#include <deal.II/base/quadrature_lib.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/lac/full_matrix.h>

#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// ============================================================================
// Helper: Compute symmetric gradient T(U) = ∇U + (∇U)^T
// ============================================================================
template <int dim>
dealii::SymmetricTensor<2, dim> compute_symmetric_gradient_ns(
    const dealii::Tensor<1, dim>& grad_ux,
    const dealii::Tensor<1, dim>& grad_uy)
{
    static_assert(dim == 2, "Only 2D implemented");
    dealii::SymmetricTensor<2, dim> T;
    T[0][0] = 2.0 * grad_ux[0];           // 2 * ∂ux/∂x
    T[1][1] = 2.0 * grad_uy[1];           // 2 * ∂uy/∂y
    T[0][1] = grad_ux[1] + grad_uy[0];    // ∂ux/∂y + ∂uy/∂x
    return T;
}

// Helper: T(V) for test function V = (φ_ux, 0)
template <int dim>
dealii::SymmetricTensor<2, dim> compute_T_test_ux(
    const dealii::Tensor<1, dim>& grad_phi_ux)
{
    static_assert(dim == 2, "Only 2D implemented");
    dealii::SymmetricTensor<2, dim> T;
    T[0][0] = 2.0 * grad_phi_ux[0];
    T[1][1] = 0.0;
    T[0][1] = grad_phi_ux[1];
    return T;
}

// Helper: T(V) for test function V = (0, φ_uy)
template <int dim>
dealii::SymmetricTensor<2, dim> compute_T_test_uy(
    const dealii::Tensor<1, dim>& grad_phi_uy)
{
    static_assert(dim == 2, "Only 2D implemented");
    dealii::SymmetricTensor<2, dim> T;
    T[0][0] = 0.0;
    T[1][1] = 2.0 * grad_phi_uy[1];
    T[0][1] = grad_phi_uy[0];
    return T;
}

// ============================================================================
// Main assembly function
// ============================================================================
template <int dim>
void assemble_ns_mms_system_parallel(
    const dealii::DoFHandler<dim>& ux_dof_handler,
    const dealii::DoFHandler<dim>& uy_dof_handler,
    const dealii::DoFHandler<dim>& p_dof_handler,
    const dealii::TrilinosWrappers::MPI::Vector& ux_old,
    const dealii::TrilinosWrappers::MPI::Vector& uy_old,
    double nu,
    double dt,
    double current_time,
    double L_y,
    bool include_time_derivative,
    bool include_convection,
    const std::vector<dealii::types::global_dof_index>& ux_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& uy_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& p_to_ns_map,
    const dealii::IndexSet& ns_owned,
    const dealii::AffineConstraints<double>& ns_constraints,
    dealii::TrilinosWrappers::SparseMatrix& ns_matrix,
    dealii::TrilinosWrappers::MPI::Vector& ns_rhs,
    MPI_Comm mpi_comm)
{
    (void)mpi_comm;  // Used implicitly by Trilinos

    ns_matrix = 0;
    ns_rhs = 0;

    const auto& fe_Q2 = ux_dof_handler.get_fe();
    const auto& fe_Q1 = p_dof_handler.get_fe();
    const unsigned int dofs_per_cell_Q2 = fe_Q2.n_dofs_per_cell();
    const unsigned int dofs_per_cell_Q1 = fe_Q1.n_dofs_per_cell();

    // Quadrature (degree + 2 for sufficient accuracy)
    dealii::QGauss<dim> quadrature(fe_Q2.degree + 2);
    const unsigned int n_q_points = quadrature.size();

    // FEValues
    dealii::FEValues<dim> ux_fe_values(fe_Q2, quadrature,
        dealii::update_values | dealii::update_gradients |
        dealii::update_quadrature_points | dealii::update_JxW_values);
    dealii::FEValues<dim> uy_fe_values(fe_Q2, quadrature,
        dealii::update_values | dealii::update_gradients);
    dealii::FEValues<dim> p_fe_values(fe_Q1, quadrature,
        dealii::update_values);

    // Local matrices and vectors
    dealii::FullMatrix<double> local_ux_ux(dofs_per_cell_Q2, dofs_per_cell_Q2);
    dealii::FullMatrix<double> local_ux_uy(dofs_per_cell_Q2, dofs_per_cell_Q2);
    dealii::FullMatrix<double> local_ux_p(dofs_per_cell_Q2, dofs_per_cell_Q1);
    dealii::FullMatrix<double> local_uy_ux(dofs_per_cell_Q2, dofs_per_cell_Q2);
    dealii::FullMatrix<double> local_uy_uy(dofs_per_cell_Q2, dofs_per_cell_Q2);
    dealii::FullMatrix<double> local_uy_p(dofs_per_cell_Q2, dofs_per_cell_Q1);
    dealii::FullMatrix<double> local_p_ux(dofs_per_cell_Q1, dofs_per_cell_Q2);
    dealii::FullMatrix<double> local_p_uy(dofs_per_cell_Q1, dofs_per_cell_Q2);

    dealii::Vector<double> local_rhs_ux(dofs_per_cell_Q2);
    dealii::Vector<double> local_rhs_uy(dofs_per_cell_Q2);
    dealii::Vector<double> local_rhs_p(dofs_per_cell_Q1);

    std::vector<dealii::types::global_dof_index> ux_local_dofs(dofs_per_cell_Q2);
    std::vector<dealii::types::global_dof_index> uy_local_dofs(dofs_per_cell_Q2);
    std::vector<dealii::types::global_dof_index> p_local_dofs(dofs_per_cell_Q1);

    // Quadrature point values
    std::vector<double> ux_old_values(n_q_points);
    std::vector<double> uy_old_values(n_q_points);
    std::vector<dealii::Tensor<1, dim>> ux_old_gradients(n_q_points);
    std::vector<dealii::Tensor<1, dim>> uy_old_gradients(n_q_points);

    // Compute t_old for MMS source (semi-implicit scheme)
    const double t_old = include_time_derivative ? current_time - dt : current_time;

    // Cell loop - only locally owned cells
    auto ux_cell = ux_dof_handler.begin_active();
    auto uy_cell = uy_dof_handler.begin_active();
    auto p_cell = p_dof_handler.begin_active();

    for (; ux_cell != ux_dof_handler.end(); ++ux_cell, ++uy_cell, ++p_cell)
    {
        if (!ux_cell->is_locally_owned())
            continue;

        ux_fe_values.reinit(ux_cell);
        uy_fe_values.reinit(uy_cell);
        p_fe_values.reinit(p_cell);

        // Zero local contributions
        local_ux_ux = 0;
        local_ux_uy = 0;
        local_ux_p = 0;
        local_uy_ux = 0;
        local_uy_uy = 0;
        local_uy_p = 0;
        local_p_ux = 0;
        local_p_uy = 0;
        local_rhs_ux = 0;
        local_rhs_uy = 0;
        local_rhs_p = 0;

        // Get DoF indices
        ux_cell->get_dof_indices(ux_local_dofs);
        uy_cell->get_dof_indices(uy_local_dofs);
        p_cell->get_dof_indices(p_local_dofs);

        // Get old velocity values (for convection and time derivative RHS)
        ux_fe_values.get_function_values(ux_old, ux_old_values);
        uy_fe_values.get_function_values(uy_old, uy_old_values);

        if (include_convection)
        {
            ux_fe_values.get_function_gradients(ux_old, ux_old_gradients);
            uy_fe_values.get_function_gradients(uy_old, uy_old_gradients);
        }

        // Quadrature loop
        for (unsigned int q = 0; q < n_q_points; ++q)
        {
            const double JxW = ux_fe_values.JxW(q);
            const dealii::Point<dim>& x_q = ux_fe_values.quadrature_point(q);

            // Old velocity at quadrature point
            const double ux_old_q = ux_old_values[q];
            const double uy_old_q = uy_old_values[q];
            dealii::Tensor<1, dim> U_old;
            U_old[0] = ux_old_q;
            U_old[1] = uy_old_q;

            // Divergence of U_old (for skew-symmetric convection)
            double div_U_old = 0.0;
            if (include_convection)
                div_U_old = ux_old_gradients[q][0] + uy_old_gradients[q][1];

            // ================================================================
            // Compute MMS source term
            // ================================================================
            dealii::Tensor<1, dim> F_mms;

            if (!include_time_derivative && !include_convection)
            {
                // Phase A: Steady Stokes
                F_mms = compute_steady_stokes_mms_source<dim>(x_q, current_time, nu, L_y);
            }
            else if (include_time_derivative && !include_convection)
            {
                // Phase B: Unsteady Stokes
                F_mms = compute_unsteady_stokes_mms_source<dim>(x_q, current_time, nu, L_y);
            }
            else if (!include_time_derivative && include_convection)
            {
                // Phase C: Steady NS
                F_mms = compute_steady_ns_mms_source<dim>(x_q, current_time, nu, L_y);
            }
            else
            {
                // Phase D: Unsteady NS (semi-implicit)
                F_mms = compute_unsteady_ns_mms_source<dim>(x_q, current_time, t_old, nu, L_y);
            }

            // ================================================================
            // Assemble local matrices
            // ================================================================
            for (unsigned int i = 0; i < dofs_per_cell_Q2; ++i)
            {
                const double phi_ux_i = ux_fe_values.shape_value(i, q);
                const double phi_uy_i = uy_fe_values.shape_value(i, q);
                const dealii::Tensor<1, dim> grad_phi_ux_i = ux_fe_values.shape_grad(i, q);
                const dealii::Tensor<1, dim> grad_phi_uy_i = uy_fe_values.shape_grad(i, q);

                auto T_V_x = compute_T_test_ux<dim>(grad_phi_ux_i);
                auto T_V_y = compute_T_test_uy<dim>(grad_phi_uy_i);

                // ============================================================
                // RHS contributions
                // ============================================================
                // MMS source: (f, V)
                local_rhs_ux(i) += F_mms[0] * phi_ux_i * JxW;
                local_rhs_uy(i) += F_mms[1] * phi_uy_i * JxW;

                // Time derivative RHS: (U^{n-1}/τ, V)
                if (include_time_derivative)
                {
                    local_rhs_ux(i) += (ux_old_q / dt) * phi_ux_i * JxW;
                    local_rhs_uy(i) += (uy_old_q / dt) * phi_uy_i * JxW;
                }

                // ============================================================
                // LHS contributions (loop over trial functions)
                // ============================================================
                for (unsigned int j = 0; j < dofs_per_cell_Q2; ++j)
                {
                    const double phi_ux_j = ux_fe_values.shape_value(j, q);
                    const double phi_uy_j = uy_fe_values.shape_value(j, q);
                    const dealii::Tensor<1, dim> grad_phi_ux_j = ux_fe_values.shape_grad(j, q);
                    const dealii::Tensor<1, dim> grad_phi_uy_j = uy_fe_values.shape_grad(j, q);

                    auto T_U_x = compute_T_test_ux<dim>(grad_phi_ux_j);
                    auto T_U_y = compute_T_test_uy<dim>(grad_phi_uy_j);

                    // --------------------------------------------------------
                    // Time derivative LHS: (U/τ, V)
                    // --------------------------------------------------------
                    if (include_time_derivative)
                    {
                        local_ux_ux(i, j) += (1.0 / dt) * phi_ux_j * phi_ux_i * JxW;
                        local_uy_uy(i, j) += (1.0 / dt) * phi_uy_j * phi_uy_i * JxW;
                    }

                    // --------------------------------------------------------
                    // Viscous term: ν(T(U), T(V))
                    // --------------------------------------------------------
                    local_ux_ux(i, j) += nu * (T_U_x * T_V_x) * JxW;
                    local_uy_uy(i, j) += nu * (T_U_y * T_V_y) * JxW;
                    local_ux_uy(i, j) += nu * (T_U_y * T_V_x) * JxW;
                    local_uy_ux(i, j) += nu * (T_U_x * T_V_y) * JxW;

                    // --------------------------------------------------------
                    // Convection: B_h(U^{n-1}, U, V) (skew-symmetric, Eq. 37)
                    //   = (U^{n-1}·∇U, V) + ½(∇·U^{n-1})(U, V)
                    // --------------------------------------------------------
                    if (include_convection)
                    {
                        // Standard convection: (U^{n-1}·∇U, V)
                        const double U_dot_grad_phi_ux_j =
                            U_old[0] * grad_phi_ux_j[0] + U_old[1] * grad_phi_ux_j[1];
                        const double U_dot_grad_phi_uy_j =
                            U_old[0] * grad_phi_uy_j[0] + U_old[1] * grad_phi_uy_j[1];

                        local_ux_ux(i, j) += U_dot_grad_phi_ux_j * phi_ux_i * JxW;
                        local_uy_uy(i, j) += U_dot_grad_phi_uy_j * phi_uy_i * JxW;

                        // Skew term: +0.5*(∇·U^{n-1})(U, V)
                        local_ux_ux(i, j) += 0.5 * div_U_old * phi_ux_j * phi_ux_i * JxW;
                        local_uy_uy(i, j) += 0.5 * div_U_old * phi_uy_j * phi_uy_i * JxW;
                    }
                }

                // ============================================================
                // Pressure gradient: -(p, ∇·V)
                // ============================================================
                for (unsigned int j = 0; j < dofs_per_cell_Q1; ++j)
                {
                    const double phi_p_j = p_fe_values.shape_value(j, q);

                    // -(p, ∂φ_ux/∂x) for V=(φ_ux, 0)
                    local_ux_p(i, j) -= phi_p_j * grad_phi_ux_i[0] * JxW;
                    // -(p, ∂φ_uy/∂y) for V=(0, φ_uy)
                    local_uy_p(i, j) -= phi_p_j * grad_phi_uy_i[1] * JxW;
                }
            }

            // ================================================================
            // Continuity equation: (∇·U, q) = 0
            // ================================================================
            for (unsigned int i = 0; i < dofs_per_cell_Q1; ++i)
            {
                const double phi_p_i = p_fe_values.shape_value(i, q);

                for (unsigned int j = 0; j < dofs_per_cell_Q2; ++j)
                {
                    const dealii::Tensor<1, dim> grad_phi_ux_j = ux_fe_values.shape_grad(j, q);
                    const dealii::Tensor<1, dim> grad_phi_uy_j = uy_fe_values.shape_grad(j, q);

                    // (∂ux/∂x, q)
                    local_p_ux(i, j) += grad_phi_ux_j[0] * phi_p_i * JxW;
                    // (∂uy/∂y, q)
                    local_p_uy(i, j) += grad_phi_uy_j[1] * phi_p_i * JxW;
                }
            }
        }  // end quadrature loop

        // ====================================================================
        // Distribute to global matrix using constraint handling
        // ====================================================================
        // Map local DoFs to coupled system indices
        std::vector<dealii::types::global_dof_index> coupled_ux_dofs(dofs_per_cell_Q2);
        std::vector<dealii::types::global_dof_index> coupled_uy_dofs(dofs_per_cell_Q2);
        std::vector<dealii::types::global_dof_index> coupled_p_dofs(dofs_per_cell_Q1);

        for (unsigned int i = 0; i < dofs_per_cell_Q2; ++i)
        {
            coupled_ux_dofs[i] = ux_to_ns_map[ux_local_dofs[i]];
            coupled_uy_dofs[i] = uy_to_ns_map[uy_local_dofs[i]];
        }
        for (unsigned int i = 0; i < dofs_per_cell_Q1; ++i)
        {
            coupled_p_dofs[i] = p_to_ns_map[p_local_dofs[i]];
        }

        // Distribute using constraints
        // ux-ux block
        ns_constraints.distribute_local_to_global(
            local_ux_ux, local_rhs_ux,
            coupled_ux_dofs,
            ns_matrix, ns_rhs);

        // ux-uy block (matrix only)
        ns_constraints.distribute_local_to_global(
            local_ux_uy,
            coupled_ux_dofs, coupled_uy_dofs,
            ns_matrix);

        // ux-p block (matrix only)
        ns_constraints.distribute_local_to_global(
            local_ux_p,
            coupled_ux_dofs, coupled_p_dofs,
            ns_matrix);

        // uy-ux block (matrix only)
        ns_constraints.distribute_local_to_global(
            local_uy_ux,
            coupled_uy_dofs, coupled_ux_dofs,
            ns_matrix);

        // uy-uy block
        ns_constraints.distribute_local_to_global(
            local_uy_uy, local_rhs_uy,
            coupled_uy_dofs,
            ns_matrix, ns_rhs);

        // uy-p block (matrix only)
        ns_constraints.distribute_local_to_global(
            local_uy_p,
            coupled_uy_dofs, coupled_p_dofs,
            ns_matrix);

        // p-ux block (matrix only)
        ns_constraints.distribute_local_to_global(
            local_p_ux,
            coupled_p_dofs, coupled_ux_dofs,
            ns_matrix);

        // p-uy block (matrix only)
        ns_constraints.distribute_local_to_global(
            local_p_uy,
            coupled_p_dofs, coupled_uy_dofs,
            ns_matrix);

        // p RHS (zero for incompressibility)
        ns_constraints.distribute_local_to_global(
            local_rhs_p, coupled_p_dofs, ns_rhs);

    }  // end cell loop

    // Compress Trilinos objects
    ns_matrix.compress(dealii::VectorOperation::add);
    ns_rhs.compress(dealii::VectorOperation::add);
}

// ============================================================================
// Explicit instantiation
// ============================================================================
template void assemble_ns_mms_system_parallel<2>(
    const dealii::DoFHandler<2>&,
    const dealii::DoFHandler<2>&,
    const dealii::DoFHandler<2>&,
    const dealii::TrilinosWrappers::MPI::Vector&,
    const dealii::TrilinosWrappers::MPI::Vector&,
    double, double, double, double,
    bool, bool,
    const std::vector<dealii::types::global_dof_index>&,
    const std::vector<dealii::types::global_dof_index>&,
    const std::vector<dealii::types::global_dof_index>&,
    const dealii::IndexSet&,
    const dealii::AffineConstraints<double>&,
    dealii::TrilinosWrappers::SparseMatrix&,
    dealii::TrilinosWrappers::MPI::Vector&,
    MPI_Comm);