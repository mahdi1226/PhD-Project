// ============================================================================
// ns_assembler.h - Parallel Navier-Stokes MMS Assembler
//
// Reference: Nochetto, Salgado & Tomas, CMAME 309 (2016) 497-531
// Equation 42e-42f (discrete scheme)
//
// This assembler supports 4 test phases via flags:
//   Phase A: Steady Stokes (no time, no convection)
//   Phase B: Unsteady Stokes (add time derivative)
//   Phase C: Steady NS (add convection, no time)
//   Phase D: Unsteady NS (full equation)
//
// Terms:
//   - Mass: (U^n/τ, V) [if include_time_derivative]
//   - Viscous: ν(T(U), T(V)) where T(U) = ∇U + (∇U)^T
//   - Convection: B_h(U_old, U, V) [if include_convection]
//   - Pressure: -(p, ∇·V) + (∇·U, q)
//   - RHS: MMS source + (U^{n-1}/τ, V) [if include_time_derivative]
//
// ============================================================================
#ifndef NS_ASSEMBLER_H
#define NS_ASSEMBLER_H

#include <deal.II/dofs/dof_handler.h>
#include <deal.II/lac/affine_constraints.h>
#include <deal.II/lac/trilinos_sparse_matrix.h>
#include <deal.II/lac/trilinos_vector.h>

#include <vector>

/**
 * @brief Assemble the Navier-Stokes MMS system (parallel)
 *
 * Assembles the coupled (ux, uy, p) system for MMS verification.
 *
 * @param ux_dof_handler    DoFHandler for velocity x (Q2)
 * @param uy_dof_handler    DoFHandler for velocity y (Q2)
 * @param p_dof_handler     DoFHandler for pressure (Q1)
 * @param ux_old            Previous velocity U^{k-1}_x (ghosted)
 * @param uy_old            Previous velocity U^{k-1}_y (ghosted)
 * @param nu                Kinematic viscosity
 * @param dt                Time step τ
 * @param current_time      Current time t^n (for MMS source)
 * @param L_y               Domain height
 * @param include_time_derivative  If true, include (U/τ, V) term
 * @param include_convection       If true, include B_h(U_old, U, V) term
 * @param ux_to_ns_map      Index map: ux DoF → coupled index
 * @param uy_to_ns_map      Index map: uy DoF → coupled index
 * @param p_to_ns_map       Index map: p DoF → coupled index
 * @param ns_owned          Locally owned DoFs in coupled system
 * @param ns_constraints    Combined constraints for coupled system
 * @param ns_matrix         [OUT] Assembled Trilinos system matrix
 * @param ns_rhs            [OUT] Assembled Trilinos RHS vector
 * @param mpi_comm          MPI communicator
 */
template <int dim>
void assemble_ns_mms_system_parallel(
    const dealii::DoFHandler<dim>& ux_dof_handler,
    const dealii::DoFHandler<dim>& uy_dof_handler,
    const dealii::DoFHandler<dim>& p_dof_handler,
    const dealii::TrilinosWrappers::MPI::Vector& ux_old,
    const dealii::TrilinosWrappers::MPI::Vector& uy_old,
    double nu,
    double dt,
    double current_time,
    double L_y,
    bool include_time_derivative,
    bool include_convection,
    const std::vector<dealii::types::global_dof_index>& ux_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& uy_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& p_to_ns_map,
    const dealii::IndexSet& ns_owned,
    const dealii::AffineConstraints<double>& ns_constraints,
    dealii::TrilinosWrappers::SparseMatrix& ns_matrix,
    dealii::TrilinosWrappers::MPI::Vector& ns_rhs,
    MPI_Comm mpi_comm);

#endif // NS_ASSEMBLER_H