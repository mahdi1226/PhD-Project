// ============================================================================
// core/phase_field.cc - Time Stepping and Solve Methods (PARALLEL)
//
// Time stepping follows Paper Algorithm 1:
//   1. Solve CH → θ^k, ψ^k
//   2. Solve Poisson → φ^k (H^k = ∇φ^k)
//   3. Solve Magnetization → M^k (DG transport)
//   4. Solve NS → u^k, p^k (uses LAGGED θ^{k-1} for energy stability)
//
// Reference: Nochetto, Salgado & Tomas, CMAME 309 (2016) 497-531
// ============================================================================

#include "core/phase_field.h"
#include "assembly/ch_assembler.h"
#include "assembly/poisson_assembler.h"
#include "assembly/magnetization_assembler.h"
#include "assembly/ns_assembler.h"
#include "solvers/ch_solver.h"
#include "solvers/poisson_solver.h"
#include "solvers/magnetization_solver.h"
#include "solvers/ns_solver.h"

// New diagnostics and logging system
#include "diagnostics/system_diagnostics.h"
#include "diagnostics/magnetization_diagnostics.h"
#include "output/console_logger.h"
#include "output/metrics_logger.h"
#include "output/timing_logger.h"
#include "utilities/run_tracker.h"
#include "utilities/tools.h"

#include <deal.II/numerics/data_out.h>
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/grid/grid_tools.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/base/quadrature_lib.h>
#include <deal.II/lac/full_matrix.h>

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// ============================================================================
// run() - Main time-stepping loop with integrated logging
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::run()
{
    // ========================================================================
    // SETUP PHASE
    // ========================================================================
    pcout_ << "========================================\n";
    pcout_ << "  Ferrofluid Phase Field Solver\n";
    pcout_ << "========================================\n\n";

    pcout_ << "[1/5] Setting up mesh...\n";
    setup_mesh();

    pcout_ << "[2/5] Setting up DoF handlers...\n";
    setup_dof_handlers();

    pcout_ << "[3/5] Setting up CH system...\n";
    setup_ch_system();

    if (params_.enable_magnetic)
    {
        pcout_ << "[3/5] Setting up Poisson system...\n";
        setup_poisson_system();

        if (params_.use_dg_transport)
        {
            pcout_ << "[3/5] Setting up Magnetization system...\n";
            setup_magnetization_system();
        }
    }

    if (params_.enable_ns)
    {
        pcout_ << "[3/5] Setting up NS system...\n";
        setup_ns_system();
    }

    pcout_ << "[4/5] Initializing solutions...\n";
    initialize_solutions();

    // ========================================================================
    // CREATE OUTPUT DIRECTORY WITH TIMESTAMP
    // ========================================================================
    const std::string output_dir = timestamped_folder(params_.output.folder, params_);
    if (MPIUtils::is_root(mpi_communicator_))
        ensure_directory(output_dir);
    MPI_Barrier(mpi_communicator_);

    // Write run configuration
    if (MPIUtils::is_root(mpi_communicator_))
        write_run_info(output_dir, params_, MPIUtils::size(mpi_communicator_));

    // ========================================================================
    // INITIALIZE LOGGERS
    // ========================================================================
    RunTracker tracker;
    tracker.start(output_dir, mpi_communicator_);

    ConsoleLogger console(params_, mpi_communicator_);
    MetricsLogger metrics(output_dir, params_, mpi_communicator_);
    TimingLogger timing(output_dir, params_, mpi_communicator_);

    // Optional: Magnetization/field distribution logger
    MagnetizationLogger mag_logger;
    /*if (params_.enable_magnetic)
    {
        mag_logger.open(output_dir + "/field_distribution.csv", params_, mpi_communicator_);
        // Print initial field diagnostic
        diagnose_applied_field(params_, time_, mpi_communicator_);
    }*/

    // ========================================================================
    // PRINT CONSOLE HEADER
    // ========================================================================
    pcout_ << "[5/5] Starting time stepping...\n";
    console.print_header();


    // Initialize previous step data for energy rate computation
    StepData prev_data;

    // Time stepping parameters
    const double dt = params_.time.dt;
    const double t_final = params_.time.t_final;
    const unsigned int output_frequency = params_.output.frequency;


    // ========================================================================
    // INITIAL OUTPUT (step 0)
    // ========================================================================
    {
        // Compute initial diagnostics
        StepData data = compute_system_diagnostics<dim>(
            theta_dof_handler_, theta_relevant_,
            params_.enable_magnetic ? &phi_dof_handler_ : nullptr,
            params_.enable_magnetic ? &phi_relevant_ : nullptr,
            params_.enable_ns ? &ux_dof_handler_ : nullptr,
            params_.enable_ns ? &uy_dof_handler_ : nullptr,
            params_.enable_ns ? &p_dof_handler_ : nullptr,
            params_.enable_ns ? &ux_relevant_ : nullptr,
            params_.enable_ns ? &uy_relevant_ : nullptr,
            params_.enable_ns ? &p_relevant_ : nullptr,
            params_, 0, time_, dt, get_min_h(),
            prev_data, mpi_communicator_);

        // Add force diagnostics if we have psi
        update_force_diagnostics<dim>(data,
            theta_dof_handler_, theta_relevant_, psi_relevant_,
            params_.enable_magnetic ? &phi_relevant_ : nullptr,
            params_, mpi_communicator_);

        update_timing_info(data, 0.0, 0.0);
        update_mesh_info(data, triangulation_.n_global_active_cells(),
                         theta_dof_handler_.n_dofs());

        // Set initial interface position for delta tracking
        console.set_initial_interface(data.interface_y_max);

        // Log initial state
        console.print_step(data);
        metrics.log_step(data);

        if (params_.enable_magnetic)
            mag_logger.write(compute_field_distribution(params_, time_, 0));

        // Output VTK
        output_results(output_dir);

        prev_data = data;
    }

    ++timestep_number_;

    // ========================================================================
    // MAIN TIME LOOP
    // ========================================================================
    while (time_ < t_final - 1e-12)
    {
        time_ += dt;

        // Start step timer
        CumulativeTimer step_timer;
        step_timer.start();

        // Timing for each subsystem
        StepTiming step_timing;

        // ====================================================================
        // SOLVE SUBSYSTEMS
        // ====================================================================

        // Step 1: Cahn-Hilliard
        {
            CumulativeTimer t;
            t.start();
            solve_ch(dt);
            t.stop();
            step_timing.ch_time = t.last();
        }

        // Step 2: Poisson
        if (params_.enable_magnetic)
        {
            CumulativeTimer t;
            t.start();
            solve_poisson();
            t.stop();
            step_timing.poisson_time = t.last();
        }

        // Step 3: Magnetization transport
        if (params_.enable_magnetic && params_.use_dg_transport)
        {
            CumulativeTimer t;
            t.start();
            solve_magnetization(dt);
            t.stop();
            step_timing.mag_time = t.last();
        }

        // Step 4: Navier-Stokes
        if (params_.enable_ns)
        {
            CumulativeTimer t;
            t.start();
            solve_ns(dt);
            t.stop();
            step_timing.ns_time = t.last();
        }

        // Update old solutions for next time step
        theta_old_solution_ = theta_solution_;
        theta_old_relevant_ = theta_relevant_;

        if (params_.enable_magnetic && params_.use_dg_transport)
        {
            Mx_old_solution_ = Mx_solution_;
            My_old_solution_ = My_solution_;
        }

        if (params_.enable_ns)
        {
            ux_old_solution_ = ux_solution_;
            uy_old_solution_ = uy_solution_;
        }

        // Stop step timer
        step_timer.stop();
        step_timing.step_total = step_timer.last();

        // ====================================================================
        // COMPUTE DIAGNOSTICS
        // ====================================================================
        StepData data = compute_system_diagnostics<dim>(
            theta_dof_handler_, theta_relevant_,
            params_.enable_magnetic ? &phi_dof_handler_ : nullptr,
            params_.enable_magnetic ? &phi_relevant_ : nullptr,
            params_.enable_ns ? &ux_dof_handler_ : nullptr,
            params_.enable_ns ? &uy_dof_handler_ : nullptr,
            params_.enable_ns ? &p_dof_handler_ : nullptr,
            params_.enable_ns ? &ux_relevant_ : nullptr,
            params_.enable_ns ? &uy_relevant_ : nullptr,
            params_.enable_ns ? &p_relevant_ : nullptr,
            params_, timestep_number_, time_, dt, get_min_h(),
            prev_data, mpi_communicator_);

        // Add force diagnostics
        update_force_diagnostics<dim>(data,
            theta_dof_handler_, theta_relevant_, psi_relevant_,
            params_.enable_magnetic ? &phi_relevant_ : nullptr,
            params_, mpi_communicator_);

        // Add solver info
        update_ch_solver_info(data, last_ch_info_.iterations,
                              last_ch_info_.residual, step_timing.ch_time,
                              !last_ch_info_.converged);
        if (params_.enable_magnetic)
            update_poisson_solver_info(data, last_poisson_info_.iterations,
                                       last_poisson_info_.residual, step_timing.poisson_time);
        if (params_.enable_magnetic && params_.use_dg_transport)
            update_mag_solver_info(data, last_M_info_.iterations,
                                   last_M_info_.residual, step_timing.mag_time);
        if (params_.enable_ns)
            update_ns_solver_info(data, last_ns_info_.iterations, 0,
                                  last_ns_info_.residual, step_timing.ns_time,
                                  !last_ns_info_.converged);

        // Add timing and mesh info
        update_timing_info(data, step_timing.step_total, tracker.elapsed_seconds());
        update_mesh_info(data, triangulation_.n_global_active_cells(),
                         theta_dof_handler_.n_dofs());

        // ====================================================================
        // LOGGING
        // ====================================================================

        // CSV logging (every step)
        metrics.log_step(data);
        timing.log_step(timestep_number_, time_, step_timing);

        // Console output (every N steps)
        if (timestep_number_ % output_frequency == 0)
        {
            console.print_step(data);

            // Field distribution (for magnetic runs)
            if (params_.enable_magnetic)
                mag_logger.write(compute_field_distribution(params_, time_, timestep_number_));
        }

        // Always check for warnings
        console.print_warnings(data);

        // Interface/spike notes (only on change)
        console.print_notes(data);

        // VTK output (every N steps)
        if (timestep_number_ % output_frequency == 0)
        {
            CumulativeTimer t;
            t.start();
            output_results(output_dir);
            t.stop();
            step_timing.output_time = t.last();
        }

        // ====================================================================
        // TERMINATION CHECKS
        // ====================================================================

        // Check for NaN
        if (std::isnan(data.E_total) || std::isnan(data.mass))
        {
            console.error("NaN detected in solution!");
            tracker.end("error: NaN detected");
            console.print_footer("error: NaN detected", data);
            return;
        }

        // Check for severe bounds violation
        if (data.theta_min < -1.5 || data.theta_max > 1.5)
        {
            console.warning("Severe theta bounds violation - simulation may be unstable");
        }

        // Store for next iteration
        prev_data = data;

        ++timestep_number_;
    }

    // ========================================================================
    // FINAL OUTPUT
    // ========================================================================
    output_results(output_dir);

    tracker.end("complete");
    console.print_footer("complete", prev_data);
}

// ============================================================================
// time_step() - Single time step following Paper Algorithm 1
// (Kept for backward compatibility, but run() now handles everything inline)
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::time_step(double dt)
{
    // Step 1: Solve Cahn-Hilliard
    solve_ch(dt);

    // Step 2: Solve Poisson (if magnetic enabled)
    if (params_.enable_magnetic)
        solve_poisson();

    // Step 3: Solve Magnetization (if DG transport enabled)
    if (params_.enable_magnetic && params_.use_dg_transport)
        solve_magnetization(dt);

    // Step 4: Solve Navier-Stokes (if enabled)
    // CRITICAL: Uses LAGGED θ^{k-1} for energy stability per paper!
    if (params_.enable_ns)
        solve_ns(dt);

    // Update old solutions for next time step
    theta_old_solution_ = theta_solution_;
    theta_old_relevant_ = theta_relevant_;

    if (params_.enable_magnetic && params_.use_dg_transport)
    {
        Mx_old_solution_ = Mx_solution_;
        My_old_solution_ = My_solution_;
    }

    if (params_.enable_ns)
    {
        ux_old_solution_ = ux_solution_;
        uy_old_solution_ = uy_solution_;
    }
}

// ============================================================================
// solve_ch() - Cahn-Hilliard solve
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::solve_ch(double dt)
{
    // Update ghosted vectors for assembly
    theta_old_relevant_ = theta_old_solution_;
    if (params_.enable_ns)
    {
        ux_relevant_ = ux_solution_;
        uy_relevant_ = uy_solution_;
    }

    // Assemble system
    assemble_ch_system<dim>(
        theta_dof_handler_,
        psi_dof_handler_,
        theta_old_relevant_,        // θ^{k-1}
        ux_relevant_,               // U_x (or zero)
        uy_relevant_,               // U_y (or zero)
        params_,
        dt,
        time_,                      // current_time for MMS
        theta_to_ch_map_,
        psi_to_ch_map_,
        ch_constraints_,
        ch_matrix_,
        ch_rhs_);

    // Solve coupled system and extract θ, ψ
    last_ch_info_ = solve_ch_system(
        ch_matrix_,
        ch_rhs_,
        ch_constraints_,
        ch_locally_owned_,
        theta_locally_owned_,
        psi_locally_owned_,
        theta_to_ch_map_,
        psi_to_ch_map_,
        theta_solution_,
        psi_solution_,
        params_.solvers.ch,
        mpi_communicator_,
        params_.output.verbose);

    // Update ghosted vectors
    theta_relevant_ = theta_solution_;
    psi_relevant_ = psi_solution_;

    if (params_.output.verbose)
    {
        pcout_ << "  [CH] iterations=" << last_ch_info_.iterations
               << ", residual=" << std::scientific << last_ch_info_.residual << "\n";
    }
}

// ============================================================================
// solve_poisson() - Magnetostatic potential (Paper Eq. 42d)
//
// Solves: -Δφ = -∇·(h_a - M)
// Weak form: (∇φ, ∇χ) = (h_a - M, ∇χ)
//
// where h_a = applied field (from dipoles), M = magnetization
//
// OPTIMIZATION: Matrix is assembled ONCE in setup_poisson_system().
// Only the RHS changes each timestep (depends on h_a ramp and M^k).
// AMG preconditioner is also cached and reused.
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::solve_poisson()
{
    // Update ghosted vectors for assembly
    if (params_.use_dg_transport)
    {
        Mx_relevant_ = Mx_solution_;
        My_relevant_ = My_solution_;
    }

    // Assemble RHS ONLY (matrix was assembled once in setup)
    assemble_poisson_rhs<dim>(
        phi_dof_handler_,
        M_dof_handler_,
        Mx_relevant_,
        My_relevant_,
        params_,
        time_,
        phi_constraints_,
        phi_rhs_);

    // Solve using cached Poisson solver (AMG preconditioner reused)
    last_poisson_info_ = poisson_solver_->solve(
        phi_rhs_,
        phi_solution_,
        phi_constraints_,
        params_.output.verbose);

    // Update ghosted vector
    phi_relevant_ = phi_solution_;
}

// ============================================================================
// solve_magnetization() - DG transport for M (Paper Eq. 42c)
//
// Equation 42c (rearranged):
//   (1/τ + 1/T)(M^k, Z) - B_h^m(U^{k-1}, Z, M^k) = (1/T)(χ_θ H^k, Z) + (1/τ)(M^{k-1}, Z)
//
// Uses upwind DG for the transport term B_h^m
// Solves TWO scalar systems (Mx and My) with the SAME matrix
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::solve_magnetization(double dt)
{
    // Update ghosted vectors for assembly
    phi_relevant_ = phi_solution_;
    theta_relevant_ = theta_solution_;

    if (params_.enable_ns)
    {
        ux_relevant_ = ux_solution_;
        uy_relevant_ = uy_solution_;
    }

    // Update ghosted old magnetization
    dealii::TrilinosWrappers::MPI::Vector Mx_old_relevant(
        M_locally_owned_, M_locally_relevant_, mpi_communicator_);
    dealii::TrilinosWrappers::MPI::Vector My_old_relevant(
        M_locally_owned_, M_locally_relevant_, mpi_communicator_);
    Mx_old_relevant = Mx_old_solution_;
    My_old_relevant = My_old_solution_;

    // Create assembler (class from magnetization_assembler.h)
    MagnetizationAssembler<dim> assembler(
        params_,
        M_dof_handler_,
        ux_dof_handler_,
        phi_dof_handler_,
        theta_dof_handler_,
        mpi_communicator_);

    // Assemble system (matrix and both RHS vectors)
    assembler.assemble(
        M_matrix_,
        Mx_rhs_,
        My_rhs_,
        ux_relevant_,
        uy_relevant_,
        phi_relevant_,
        theta_relevant_,
        Mx_old_relevant,
        My_old_relevant,
        dt,
        time_);

    // Create solver (class from magnetization_solver.h)
    MagnetizationSolver<dim> solver(
        params_.solvers.magnetization,
        M_locally_owned_,
        mpi_communicator_);

    // Initialize solver with assembled matrix
    solver.initialize(M_matrix_);

    // Solve for Mx
    solver.solve(Mx_solution_, Mx_rhs_);
    const unsigned int mx_iters = solver.last_n_iterations();

    // Solve for My (reuses same matrix factorization/preconditioner)
    solver.solve(My_solution_, My_rhs_);
    const unsigned int my_iters = solver.last_n_iterations();

    // Update ghosted vectors
    Mx_relevant_ = Mx_solution_;
    My_relevant_ = My_solution_;

    // Store solver info
    last_M_info_.solver_name = "Magnetization-DG";
    last_M_info_.iterations = mx_iters + my_iters;
    last_M_info_.converged = true;

    if (params_.output.verbose)
    {
        pcout_ << "  [Magnetization] Mx_iters=" << mx_iters
               << ", My_iters=" << my_iters << "\n";
    }
}

// ============================================================================
// solve_ns() - Navier-Stokes with Kelvin force (Paper Eq. 42e-42f)
//
// Momentum equation includes:
//   - Time derivative: ρ(∂u/∂t, v)
//   - Viscous: ν(T(u), T(v)) where T(u) = ∇u + (∇u)^T
//   - Convection: B_h(u^{k-1}, u, v) (skew-symmetric)
//   - Pressure: -(p, ∇·v)
//   - Kelvin force: B_h^m(θ, H, M) - magnetic body force
//
// CRITICAL: θ is LAGGED (θ^{k-1}) for energy stability!
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::solve_ns(double dt)
{
    // Update ghosted vectors
    // CRITICAL: Use LAGGED θ^{k-1} for energy stability per paper!
    theta_old_relevant_ = theta_old_solution_;
    ux_relevant_ = ux_old_solution_;
    uy_relevant_ = uy_old_solution_;

    if (params_.enable_magnetic)
    {
        phi_relevant_ = phi_solution_;
        Mx_relevant_ = Mx_solution_;
        My_relevant_ = My_solution_;
    }

    // Assemble NS system (free function from ns_assembler.h)
    const double L_y = params_.domain.y_max - params_.domain.y_min;
    // Use nu_water as reference viscosity for Schur preconditioner
    const double nu = params_.physics.nu_water;
    const bool include_time = true;
    const bool include_convection = true;

    assemble_ns_mms_system_parallel<dim>(
        ux_dof_handler_,
        uy_dof_handler_,
        p_dof_handler_,
        ux_relevant_,
        uy_relevant_,
        nu,
        dt,
        time_,
        L_y,
        include_time,
        include_convection,
        ux_to_ns_map_,
        uy_to_ns_map_,
        p_to_ns_map_,
        ns_locally_owned_,
        ns_constraints_,
        ns_matrix_,
        ns_rhs_,
        mpi_communicator_);

    // Solve with Block Schur preconditioner (free function)
    last_ns_info_ = solve_ns_system_schur_parallel(
        ns_matrix_,
        ns_rhs_,
        ns_solution_,
        ns_constraints_,
        pressure_mass_matrix_,
        ux_to_ns_map_,
        uy_to_ns_map_,
        p_to_ns_map_,
        ns_locally_owned_,
        ux_locally_owned_,  // vel_owned
        p_locally_owned_,
        mpi_communicator_,
        nu,
        params_.output.verbose);

    // Extract individual solutions (free function)
    extract_ns_solutions_parallel(
        ns_solution_,
        ux_to_ns_map_,
        uy_to_ns_map_,
        p_to_ns_map_,
        ux_locally_owned_,
        uy_locally_owned_,
        p_locally_owned_,
        ux_solution_,
        uy_solution_,
        p_solution_,
        mpi_communicator_);

    // Update ghosted vectors
    ux_relevant_ = ux_solution_;
    uy_relevant_ = uy_solution_;
    p_relevant_ = p_solution_;

    if (params_.output.verbose)
    {
        pcout_ << "  [NS] iterations=" << last_ns_info_.iterations
               << ", residual=" << std::scientific << last_ns_info_.residual << "\n";
    }
}

// ============================================================================
// output_results() - Parallel VTU output
// ============================================================================
template <int dim>
void PhaseFieldProblem<dim>::output_results(const std::string& output_dir)
{
    // Phase field output (θ and ψ)
    {
        dealii::DataOut<dim> data_out;
        data_out.attach_dof_handler(theta_dof_handler_);

        // Need ghosted vector for output
        dealii::TrilinosWrappers::MPI::Vector theta_out(
            theta_locally_owned_, theta_locally_relevant_, mpi_communicator_);
        theta_out = theta_solution_;
        data_out.add_data_vector(theta_out, "theta");

        dealii::TrilinosWrappers::MPI::Vector psi_out(
            psi_locally_owned_, psi_locally_relevant_, mpi_communicator_);
        psi_out = psi_solution_;
        data_out.add_data_vector(psi_out, "psi");

        // Subdomain for parallel visualization
        dealii::Vector<float> subdomain(triangulation_.n_active_cells());
        for (unsigned int i = 0; i < subdomain.size(); ++i)
            subdomain(i) = triangulation_.locally_owned_subdomain();
        data_out.add_data_vector(subdomain, "subdomain");

        data_out.build_patches();
        data_out.write_vtu_with_pvtu_record(
            output_dir + "/", "phase_field",
            timestep_number_, mpi_communicator_);
    }

    // Velocity output (if NS enabled)
    if (params_.enable_ns)
    {
        dealii::DataOut<dim> data_out;
        data_out.attach_dof_handler(ux_dof_handler_);

        dealii::TrilinosWrappers::MPI::Vector ux_out(
            ux_locally_owned_, ux_locally_relevant_, mpi_communicator_);
        dealii::TrilinosWrappers::MPI::Vector uy_out(
            uy_locally_owned_, uy_locally_relevant_, mpi_communicator_);
        ux_out = ux_solution_;
        uy_out = uy_solution_;

        data_out.add_data_vector(ux_out, "ux");
        data_out.add_data_vector(uy_out, "uy");

        data_out.build_patches();
        data_out.write_vtu_with_pvtu_record(
            output_dir + "/", "velocity",
            timestep_number_, mpi_communicator_);

        // Pressure output (separate DoFHandler)
        dealii::DataOut<dim> data_out_p;
        data_out_p.attach_dof_handler(p_dof_handler_);

        dealii::TrilinosWrappers::MPI::Vector p_out(
            p_locally_owned_, p_locally_relevant_, mpi_communicator_);
        p_out = p_solution_;
        data_out_p.add_data_vector(p_out, "pressure");

        data_out_p.build_patches();
        data_out_p.write_vtu_with_pvtu_record(
            output_dir + "/", "pressure",
            timestep_number_, mpi_communicator_);
    }

    // Magnetic potential output
    if (params_.enable_magnetic)
    {
        dealii::DataOut<dim> data_out;
        data_out.attach_dof_handler(phi_dof_handler_);

        dealii::TrilinosWrappers::MPI::Vector phi_out(
            phi_locally_owned_, phi_locally_relevant_, mpi_communicator_);
        phi_out = phi_solution_;
        data_out.add_data_vector(phi_out, "phi");

        data_out.build_patches();
        data_out.write_vtu_with_pvtu_record(
            output_dir + "/", "magnetic_potential",
            timestep_number_, mpi_communicator_);
    }

    // Magnetization output (DG)
    if (params_.enable_magnetic && params_.use_dg_transport)
    {
        dealii::DataOut<dim> data_out;
        data_out.attach_dof_handler(M_dof_handler_);

        dealii::TrilinosWrappers::MPI::Vector Mx_out(
            M_locally_owned_, M_locally_relevant_, mpi_communicator_);
        dealii::TrilinosWrappers::MPI::Vector My_out(
            M_locally_owned_, M_locally_relevant_, mpi_communicator_);
        Mx_out = Mx_solution_;
        My_out = My_solution_;

        data_out.add_data_vector(Mx_out, "Mx");
        data_out.add_data_vector(My_out, "My");

        data_out.build_patches();
        data_out.write_vtu_with_pvtu_record(
            output_dir + "/", "magnetization",
            timestep_number_, mpi_communicator_);
    }

    if (params_.output.verbose)
        pcout_ << "  [Output] Wrote step " << timestep_number_ << "\n";
}


// ============================================================================
// get_min_h() - Minimum cell diameter for CFL computation
// ============================================================================
template <int dim>
double PhaseFieldProblem<dim>::get_min_h() const
{
    return dealii::GridTools::minimal_cell_diameter(triangulation_);
}

// ============================================================================
// Explicit instantiation
// ============================================================================
template class PhaseFieldProblem<2>;