// ============================================================================
// solvers/ns_solver.h - Parallel Navier-Stokes Solver Interface
//
// Provides FGMRES + Block Schur preconditioner for saddle-point systems.
// This is the mathematically correct approach for Stokes/NS.
// ============================================================================
#ifndef NS_SOLVER_H
#define NS_SOLVER_H

#include "solvers/solver_info.h"  // SolverInfo struct

#include <deal.II/lac/trilinos_sparse_matrix.h>
#include <deal.II/lac/trilinos_vector.h>
#include <deal.II/lac/trilinos_sparsity_pattern.h>
#include <deal.II/lac/affine_constraints.h>
#include <deal.II/dofs/dof_handler.h>

#include <vector>
#include <mpi.h>

/**
 * @brief Solve NS system with Block Schur preconditioner
 *
 * Uses FGMRES with block Schur preconditioner:
 *   - AMG for velocity block
 *   - Pressure mass matrix for Schur approximation
 *
 * This is the correct approach for saddle-point systems.
 *
 * @param matrix          Full NS system matrix [A, B^T; B, 0]
 * @param rhs             Right-hand side
 * @param solution        [OUT] Solution vector
 * @param constraints     Constraints for distribution
 * @param pressure_mass   Pressure mass matrix (for Schur approximation)
 * @param ux_to_ns_map    ux DoF -> coupled index
 * @param uy_to_ns_map    uy DoF -> coupled index
 * @param p_to_ns_map     p DoF -> coupled index
 * @param vel_owned       Locally owned velocity DoFs
 * @param p_owned         Locally owned pressure DoFs
 * @param mpi_comm        MPI communicator
 * @param viscosity       Viscosity (for Schur scaling)
 * @param verbose         Print diagnostics
 */
SolverInfo solve_ns_system_schur_parallel(
    const dealii::TrilinosWrappers::SparseMatrix& matrix,
    const dealii::TrilinosWrappers::MPI::Vector& rhs,
    dealii::TrilinosWrappers::MPI::Vector& solution,
    const dealii::AffineConstraints<double>& constraints,
    const dealii::TrilinosWrappers::SparseMatrix& pressure_mass,
    const std::vector<dealii::types::global_dof_index>& ux_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& uy_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& p_to_ns_map,
    const dealii::IndexSet& ns_owned,
    const dealii::IndexSet& vel_owned,
    const dealii::IndexSet& p_owned,
    MPI_Comm mpi_comm,
    double viscosity = 1.0,
    bool verbose = false);

/**
 * @brief Simple GMRES + AMG solver (for comparison/fallback)
 *
 * Note: AMG alone struggles with saddle-point systems. Use Schur version
 * for better pressure accuracy.
 */
SolverInfo solve_ns_system_direct_parallel(
    const dealii::TrilinosWrappers::SparseMatrix& matrix,
    const dealii::TrilinosWrappers::MPI::Vector& rhs,
    dealii::TrilinosWrappers::MPI::Vector& solution,
    const dealii::AffineConstraints<double>& constraints,
    MPI_Comm mpi_comm,
    bool verbose = false);

/**
 * @brief Extract individual field solutions from coupled NS solution
 */
void extract_ns_solutions_parallel(
    const dealii::TrilinosWrappers::MPI::Vector& ns_solution,
    const std::vector<dealii::types::global_dof_index>& ux_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& uy_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& p_to_ns_map,
    const dealii::IndexSet& ux_owned,
    const dealii::IndexSet& uy_owned,
    const dealii::IndexSet& p_owned,
    dealii::TrilinosWrappers::MPI::Vector& ux_solution,
    dealii::TrilinosWrappers::MPI::Vector& uy_solution,
    dealii::TrilinosWrappers::MPI::Vector& p_solution,
    MPI_Comm mpi_comm);

/**
 * @brief Assemble pressure mass matrix for Schur preconditioner
 */
template <int dim>
void assemble_pressure_mass_matrix_parallel(
    const dealii::DoFHandler<dim>& p_dof_handler,
    const dealii::AffineConstraints<double>& p_constraints,
    const dealii::IndexSet& p_owned,
    const dealii::IndexSet& p_relevant,
    dealii::TrilinosWrappers::SparseMatrix& pressure_mass,
    MPI_Comm mpi_comm);

#endif // NS_SOLVER_H