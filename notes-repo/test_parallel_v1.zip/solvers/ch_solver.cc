// ============================================================================
// solvers/ch_solver.cc - Parallel Cahn-Hilliard Solver (Trilinos)
//
// Uses Trilinos GMRES + AMG for distributed CH system.
// ============================================================================

#include "solvers/ch_solver.h"
#include "solvers/solver_info.h"

#include <deal.II/lac/trilinos_precondition.h>
#include <deal.II/lac/trilinos_solver.h>
#include <deal.II/lac/solver_gmres.h>
#include <deal.II/lac/solver_control.h>
#include <deal.II/base/utilities.h>

#include <chrono>
#include <iostream>

// ============================================================================
// solve_ch_system - Solve and extract in one call
// ============================================================================
SolverInfo solve_ch_system(
    const dealii::TrilinosWrappers::SparseMatrix& matrix,
    const dealii::TrilinosWrappers::MPI::Vector& rhs,
    const dealii::AffineConstraints<double>& constraints,
    const dealii::IndexSet& ch_locally_owned,
    const dealii::IndexSet& theta_locally_owned,
    const dealii::IndexSet& psi_locally_owned,
    const std::vector<dealii::types::global_dof_index>& theta_to_ch_map,
    const std::vector<dealii::types::global_dof_index>& psi_to_ch_map,
    dealii::TrilinosWrappers::MPI::Vector& theta_solution,
    dealii::TrilinosWrappers::MPI::Vector& psi_solution,
    const LinearSolverParams& params,
    MPI_Comm mpi_comm,
    bool verbose)
{
    SolverInfo info;
    info.solver_name = "CH";
    info.matrix_size = matrix.m();
    info.nnz = matrix.n_nonzero_elements();

    auto start = std::chrono::high_resolution_clock::now();

    const unsigned int rank = dealii::Utilities::MPI::this_mpi_process(mpi_comm);

    // Create coupled solution vector
    dealii::TrilinosWrappers::MPI::Vector coupled_solution(ch_locally_owned, mpi_comm);
    coupled_solution = 0;

    // Check for zero RHS
    const double rhs_norm = rhs.l2_norm();
    if (rhs_norm < 1e-14)
    {
        constraints.distribute(coupled_solution);

        // Extract to θ and ψ
        for (auto idx = theta_locally_owned.begin(); idx != theta_locally_owned.end(); ++idx)
            theta_solution[*idx] = coupled_solution[theta_to_ch_map[*idx]];
        for (auto idx = psi_locally_owned.begin(); idx != psi_locally_owned.end(); ++idx)
            psi_solution[*idx] = coupled_solution[psi_to_ch_map[*idx]];

        // CRITICAL: Compress after element-wise insertion
        theta_solution.compress(dealii::VectorOperation::insert);
        psi_solution.compress(dealii::VectorOperation::insert);

        info.iterations = 0;
        info.residual = 0.0;
        info.converged = true;

        auto end = std::chrono::high_resolution_clock::now();
        info.solve_time = std::chrono::duration<double>(end - start).count();
        return info;
    }

    // Setup solver control
    dealii::SolverControl solver_control(
        params.max_iterations,
        params.rel_tolerance * rhs_norm,
        /*log_history=*/false,
        /*log_result=*/false);

    bool converged = false;

    // ========================================================================
    // Direct solver (if requested or as fallback)
    // ========================================================================
    if (!params.use_iterative)
    {
        try
        {
            dealii::TrilinosWrappers::SolverDirect direct_solver(solver_control);
            direct_solver.solve(matrix, coupled_solution, rhs);

            info.iterations = 1;
            info.residual = 0.0;
            info.converged = true;
            info.used_direct = true;
            converged = true;

            if (verbose && rank == 0)
                std::cout << "[CH] Direct solver completed\n";
        }
        catch (std::exception& e)
        {
            if (verbose && rank == 0)
                std::cerr << "[CH] Direct solver failed: " << e.what() << "\n";
            converged = false;
        }
    }

    // ========================================================================
    // Iterative solver (GMRES + AMG)
    // ========================================================================
    if (!converged && params.use_iterative)
    {
        // GMRES solver
        dealii::SolverGMRES<dealii::TrilinosWrappers::MPI::Vector>::AdditionalData gmres_data;
        gmres_data.max_n_tmp_vectors = params.gmres_restart;
        gmres_data.right_preconditioning = true;

        dealii::SolverGMRES<dealii::TrilinosWrappers::MPI::Vector> solver(solver_control, gmres_data);

        // AMG preconditioner
        dealii::TrilinosWrappers::PreconditionAMG preconditioner;
        dealii::TrilinosWrappers::PreconditionAMG::AdditionalData amg_data;
        amg_data.smoother_sweeps = 2;
        amg_data.aggregation_threshold = 1e-4;
        amg_data.elliptic = false;
        amg_data.higher_order_elements = true;

        try
        {
            preconditioner.initialize(matrix, amg_data);

            // Solve
            solver.solve(matrix, coupled_solution, rhs, preconditioner);

            info.iterations = solver_control.last_step();
            info.residual = solver_control.last_value();
            info.converged = true;
            converged = true;
        }
        catch (dealii::SolverControl::NoConvergence& e)
        {
            info.iterations = solver_control.last_step();
            info.residual = solver_control.last_value();
            info.converged = false;

            if (verbose && rank == 0)
            {
                std::cerr << "[CH] GMRES failed after " << info.iterations
                          << " iterations, residual = " << info.residual << "\n";
            }
        }
        catch (std::exception& e)
        {
            if (verbose && rank == 0)
            {
                std::cerr << "[CH] Exception: " << e.what() << "\n";
            }
            info.converged = false;
        }
    }

    // ========================================================================
    // Fallback to direct if iterative failed
    // ========================================================================
    if (!converged && params.fallback_to_direct)
    {
        if (verbose && rank == 0)
            std::cerr << "[CH] Falling back to direct solver\n";

        try
        {
            dealii::TrilinosWrappers::SolverDirect direct_solver(solver_control);
            direct_solver.solve(matrix, coupled_solution, rhs);

            info.iterations = 1;
            info.residual = 0.0;
            info.converged = true;
            info.used_direct = true;
        }
        catch (std::exception& e)
        {
            if (verbose && rank == 0)
                std::cerr << "[CH] Direct fallback failed: " << e.what() << "\n";
        }
    }

    // Distribute constraints
    constraints.distribute(coupled_solution);

    // Extract θ and ψ from coupled solution
    for (auto idx = theta_locally_owned.begin(); idx != theta_locally_owned.end(); ++idx)
        theta_solution[*idx] = coupled_solution[theta_to_ch_map[*idx]];
    for (auto idx = psi_locally_owned.begin(); idx != psi_locally_owned.end(); ++idx)
        psi_solution[*idx] = coupled_solution[psi_to_ch_map[*idx]];

    // CRITICAL: Compress after element-wise insertion
    theta_solution.compress(dealii::VectorOperation::insert);
    psi_solution.compress(dealii::VectorOperation::insert);

    auto end = std::chrono::high_resolution_clock::now();
    info.solve_time = std::chrono::duration<double>(end - start).count();

    if (verbose && rank == 0)
    {
        std::cout << "[CH] iterations=" << info.iterations
                  << ", residual=" << std::scientific << info.residual
                  << ", time=" << std::fixed << info.solve_time << "s\n";
    }

    return info;
}