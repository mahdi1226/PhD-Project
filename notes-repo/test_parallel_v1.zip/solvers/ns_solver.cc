// ============================================================================
// solvers/ns_solver.cc - Parallel Navier-Stokes Solver Implementation
//
// FGMRES + Block Schur preconditioner for saddle-point systems.
// This is the mathematically correct approach for Stokes/NS.
// ============================================================================

#include "solvers/ns_solver.h"
#include "solvers/ns_block_preconditioner.h"

#include <deal.II/lac/solver_gmres.h>
#include <deal.II/lac/trilinos_precondition.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/base/quadrature_lib.h>
#include <deal.II/lac/dynamic_sparsity_pattern.h>
#include <deal.II/dofs/dof_tools.h>

#include <chrono>
#include <iostream>
#include <iomanip>

// ============================================================================
// Block Schur solver (recommended for saddle-point)
// ============================================================================
SolverInfo solve_ns_system_schur_parallel(
    const dealii::TrilinosWrappers::SparseMatrix& matrix,
    const dealii::TrilinosWrappers::MPI::Vector& rhs,
    dealii::TrilinosWrappers::MPI::Vector& solution,
    const dealii::AffineConstraints<double>& constraints,
    const dealii::TrilinosWrappers::SparseMatrix& pressure_mass,
    const std::vector<dealii::types::global_dof_index>& ux_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& uy_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& p_to_ns_map,
    const dealii::IndexSet& ns_owned,
    const dealii::IndexSet& vel_owned,
    const dealii::IndexSet& p_owned,
    MPI_Comm mpi_comm,
    double viscosity,
    bool verbose)
{
    SolverInfo info;
    info.solver_name = "NS-FGMRES-Schur";
    info.matrix_size = matrix.m();
    info.nnz = matrix.n_nonzero_elements();

    int rank;
    MPI_Comm_rank(mpi_comm, &rank);

    const double rhs_norm = rhs.l2_norm();
    if (rhs_norm < 1e-14)
    {
        solution = 0;
        constraints.distribute(solution);
        info.converged = true;
        info.residual = 0.0;
        info.iterations = 0;
        return info;
    }

    auto start = std::chrono::high_resolution_clock::now();

    // Create block Schur preconditioner
    BlockSchurPreconditionerParallel preconditioner(
        matrix, pressure_mass,
        ux_to_ns_map, uy_to_ns_map, p_to_ns_map,
        ns_owned, vel_owned, p_owned,
        mpi_comm, viscosity);

    preconditioner.inner_tolerance = 1e-4;  // Relaxed inner tolerance
    preconditioner.max_inner_iterations = 100;

    // FGMRES (flexible GMRES) because preconditioner changes each iteration
    const double rel_tol = 1e-8;
    const double tol = rel_tol * rhs_norm;

    dealii::SolverControl solver_control(1500, tol, false, false);

    dealii::SolverFGMRES<dealii::TrilinosWrappers::MPI::Vector>::AdditionalData fgmres_data;
    fgmres_data.max_basis_size = 100;

    dealii::SolverFGMRES<dealii::TrilinosWrappers::MPI::Vector> solver(solver_control, fgmres_data);

    solution = 0;

    try
    {
        solver.solve(matrix, solution, rhs, preconditioner);
        info.converged = true;
        info.iterations = solver_control.last_step();
    }
    catch (const dealii::SolverControl::NoConvergence& e)
    {
        info.converged = false;
        info.iterations = e.last_step;
        if (rank == 0)
        {
            std::cout << "[NS Schur] FGMRES did not converge in " << e.last_step
                      << " iterations, res = " << e.last_residual << "\n";
        }
    }

    auto end = std::chrono::high_resolution_clock::now();
    info.solve_time = std::chrono::duration<double>(end - start).count();

    // Distribute constraints
    constraints.distribute(solution);

    // Compute true residual
    dealii::TrilinosWrappers::MPI::Vector residual(rhs);
    matrix.vmult(residual, solution);
    residual -= rhs;
    info.residual = residual.l2_norm() / rhs_norm;

    if (verbose && rank == 0)
    {
        std::cout << "[NS Schur] FGMRES: " << info.iterations << " iters"
                  << ", inner A: " << preconditioner.n_iterations_A
                  << ", inner S: " << preconditioner.n_iterations_S
                  << ", rel_res: " << std::scientific << std::setprecision(2) << info.residual
                  << ", time: " << std::fixed << std::setprecision(2) << info.solve_time << "s\n";
    }

    return info;
}

// ============================================================================
// Simple GMRES + AMG (fallback, struggles with pressure)
// ============================================================================
SolverInfo solve_ns_system_direct_parallel(
    const dealii::TrilinosWrappers::SparseMatrix& matrix,
    const dealii::TrilinosWrappers::MPI::Vector& rhs,
    dealii::TrilinosWrappers::MPI::Vector& solution,
    const dealii::AffineConstraints<double>& constraints,
    MPI_Comm mpi_comm,
    bool verbose)
{
    SolverInfo info;
    info.solver_name = "NS-GMRES-AMG";
    info.matrix_size = matrix.m();
    info.nnz = matrix.n_nonzero_elements();

    int rank;
    MPI_Comm_rank(mpi_comm, &rank);

    const double rhs_norm = rhs.l2_norm();
    if (rhs_norm < 1e-14)
    {
        solution = 0;
        constraints.distribute(solution);
        info.converged = true;
        info.residual = 0.0;
        info.iterations = 0;
        return info;
    }

    auto start = std::chrono::high_resolution_clock::now();

    const double rel_tol = 1e-10;
    const double tol = rel_tol * rhs_norm;
    const unsigned int max_iter = (matrix.m() > 10000) ? 5000 : 2000;

    dealii::SolverControl solver_control(max_iter, tol, false, false);

    dealii::SolverGMRES<dealii::TrilinosWrappers::MPI::Vector>::AdditionalData gmres_data;
    gmres_data.max_n_tmp_vectors = 150;

    dealii::SolverGMRES<dealii::TrilinosWrappers::MPI::Vector> solver(solver_control, gmres_data);

    // AMG preconditioner (note: not optimal for saddle-point)
    dealii::TrilinosWrappers::PreconditionAMG preconditioner;
    dealii::TrilinosWrappers::PreconditionAMG::AdditionalData amg_data;
    amg_data.elliptic = false;
    amg_data.higher_order_elements = true;
    amg_data.smoother_sweeps = 2;
    amg_data.aggregation_threshold = 0.02;

    preconditioner.initialize(matrix, amg_data);

    try
    {
        solver.solve(matrix, solution, rhs, preconditioner);
        info.converged = true;
        info.iterations = solver_control.last_step();
    }
    catch (const dealii::SolverControl::NoConvergence&)
    {
        info.converged = false;
        info.iterations = solver_control.last_step();
    }

    auto end = std::chrono::high_resolution_clock::now();
    info.solve_time = std::chrono::duration<double>(end - start).count();

    constraints.distribute(solution);

    // Compute true residual
    dealii::TrilinosWrappers::MPI::Vector residual(rhs);
    matrix.vmult(residual, solution);
    residual -= rhs;
    info.residual = residual.l2_norm() / rhs_norm;

    info.converged = (info.residual < 1e-8) || info.converged;

    if (!info.converged && rank == 0)
    {
        std::cout << "[NS AMG] WARNING: rel_residual = " << std::scientific
                  << std::setprecision(2) << info.residual
                  << " after " << info.iterations << " iterations\n";
    }

    return info;
}

// ============================================================================
// Extract solutions
// ============================================================================
void extract_ns_solutions_parallel(
    const dealii::TrilinosWrappers::MPI::Vector& ns_solution,
    const std::vector<dealii::types::global_dof_index>& ux_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& uy_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& p_to_ns_map,
    const dealii::IndexSet& ux_owned,
    const dealii::IndexSet& uy_owned,
    const dealii::IndexSet& p_owned,
    dealii::TrilinosWrappers::MPI::Vector& ux_solution,
    dealii::TrilinosWrappers::MPI::Vector& uy_solution,
    dealii::TrilinosWrappers::MPI::Vector& p_solution,
    MPI_Comm mpi_comm)
{
    if (ux_solution.size() != ux_to_ns_map.size())
        ux_solution.reinit(ux_owned, mpi_comm);
    if (uy_solution.size() != uy_to_ns_map.size())
        uy_solution.reinit(uy_owned, mpi_comm);
    if (p_solution.size() != p_to_ns_map.size())
        p_solution.reinit(p_owned, mpi_comm);

    for (auto it = ux_owned.begin(); it != ux_owned.end(); ++it)
        ux_solution[*it] = ns_solution[ux_to_ns_map[*it]];

    for (auto it = uy_owned.begin(); it != uy_owned.end(); ++it)
        uy_solution[*it] = ns_solution[uy_to_ns_map[*it]];

    for (auto it = p_owned.begin(); it != p_owned.end(); ++it)
        p_solution[*it] = ns_solution[p_to_ns_map[*it]];

    ux_solution.compress(dealii::VectorOperation::insert);
    uy_solution.compress(dealii::VectorOperation::insert);
    p_solution.compress(dealii::VectorOperation::insert);
}

// ============================================================================
// Assemble pressure mass matrix
// ============================================================================
template <int dim>
void assemble_pressure_mass_matrix_parallel(
    const dealii::DoFHandler<dim>& p_dof_handler,
    const dealii::AffineConstraints<double>& p_constraints,
    const dealii::IndexSet& p_owned,
    const dealii::IndexSet& p_relevant,
    dealii::TrilinosWrappers::SparseMatrix& pressure_mass,
    MPI_Comm mpi_comm)
{
    const dealii::FiniteElement<dim>& fe = p_dof_handler.get_fe();
    const unsigned int dofs_per_cell = fe.n_dofs_per_cell();

    // Build sparsity pattern
    dealii::DynamicSparsityPattern dsp(p_relevant);
    dealii::DoFTools::make_sparsity_pattern(p_dof_handler, dsp, p_constraints, false);

    dealii::TrilinosWrappers::SparsityPattern sp;
    sp.reinit(p_owned, p_owned, dsp, mpi_comm);

    pressure_mass.reinit(sp);

    // Assemble
    dealii::QGauss<dim> quadrature(fe.degree + 1);
    dealii::FEValues<dim> fe_values(fe, quadrature,
        dealii::update_values | dealii::update_JxW_values);

    const unsigned int n_q_points = quadrature.size();
    dealii::FullMatrix<double> cell_matrix(dofs_per_cell, dofs_per_cell);
    std::vector<dealii::types::global_dof_index> local_dof_indices(dofs_per_cell);

    for (const auto& cell : p_dof_handler.active_cell_iterators())
    {
        if (cell->is_locally_owned())
        {
            fe_values.reinit(cell);
            cell_matrix = 0;

            for (unsigned int q = 0; q < n_q_points; ++q)
                for (unsigned int i = 0; i < dofs_per_cell; ++i)
                    for (unsigned int j = 0; j < dofs_per_cell; ++j)
                        cell_matrix(i, j) += fe_values.shape_value(i, q) *
                                             fe_values.shape_value(j, q) *
                                             fe_values.JxW(q);

            cell->get_dof_indices(local_dof_indices);
            p_constraints.distribute_local_to_global(cell_matrix, local_dof_indices, pressure_mass);
        }
    }

    pressure_mass.compress(dealii::VectorOperation::add);
}

// Explicit instantiations
template void assemble_pressure_mass_matrix_parallel<2>(
    const dealii::DoFHandler<2>&,
    const dealii::AffineConstraints<double>&,
    const dealii::IndexSet&,
    const dealii::IndexSet&,
    dealii::TrilinosWrappers::SparseMatrix&,
    MPI_Comm);

template void assemble_pressure_mass_matrix_parallel<3>(
    const dealii::DoFHandler<3>&,
    const dealii::AffineConstraints<double>&,
    const dealii::IndexSet&,
    const dealii::IndexSet&,
    dealii::TrilinosWrappers::SparseMatrix&,
    MPI_Comm);