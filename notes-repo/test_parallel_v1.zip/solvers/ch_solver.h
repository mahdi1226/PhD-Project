// ============================================================================
// solvers/ch_solver.h - Parallel Cahn-Hilliard Solver (Trilinos)
//
// Parallel version using TrilinosWrappers for distributed linear algebra.
// ============================================================================
#ifndef CH_SOLVER_H
#define CH_SOLVER_H

#include <deal.II/lac/trilinos_sparse_matrix.h>
#include <deal.II/lac/trilinos_vector.h>
#include <deal.II/lac/affine_constraints.h>
#include <deal.II/base/index_set.h>

#include "solvers/solver_info.h"
#include "utilities/parameters.h"

#include <vector>
#include <mpi.h>

/**
 * @brief Solve the coupled CH system (parallel version)
 *
 * Uses GMRES with AMG preconditioner from Trilinos.
 * Solves the coupled [θ, ψ] system and extracts solutions.
 *
 * @param matrix          Coupled CH system matrix [θ-θ, θ-ψ; ψ-θ, ψ-ψ]
 * @param rhs             Right-hand side vector
 * @param constraints     Constraints for coupled system
 * @param ch_locally_owned  Locally owned DoFs for coupled system
 * @param theta_locally_owned  Locally owned DoFs for θ
 * @param psi_locally_owned    Locally owned DoFs for ψ
 * @param theta_to_ch_map Index map from θ to coupled
 * @param psi_to_ch_map   Index map from ψ to coupled
 * @param theta_solution  [OUT] θ solution vector
 * @param psi_solution    [OUT] ψ solution vector
 * @param params          Solver parameters
 * @param mpi_comm        MPI communicator
 * @param verbose         Print solver output
 * @return SolverInfo with iterations, residual, time
 */
SolverInfo solve_ch_system(
    const dealii::TrilinosWrappers::SparseMatrix& matrix,
    const dealii::TrilinosWrappers::MPI::Vector& rhs,
    const dealii::AffineConstraints<double>& constraints,
    const dealii::IndexSet& ch_locally_owned,
    const dealii::IndexSet& theta_locally_owned,
    const dealii::IndexSet& psi_locally_owned,
    const std::vector<dealii::types::global_dof_index>& theta_to_ch_map,
    const std::vector<dealii::types::global_dof_index>& psi_to_ch_map,
    dealii::TrilinosWrappers::MPI::Vector& theta_solution,
    dealii::TrilinosWrappers::MPI::Vector& psi_solution,
    const LinearSolverParams& params,
    MPI_Comm mpi_comm,
    bool verbose = false);

#endif // CH_SOLVER_H