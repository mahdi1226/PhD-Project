// ============================================================================
// assembly/magnetization_assembler.h - DG Magnetization Assembler Header
//
// Reference: Nochetto, Salgado & Tomas, CMAME 309 (2016) 497-531
// Eq. 42c, Eq. 57
//
// EQUATION 42c (rearranged):
//   (1/τ + 1/T)(M^k, Z) - B_h^m(U^{k-1}, Z, M^k) = (1/T)(χ_θ H^k, Z) + (1/τ)(M^{k-1}, Z)
//
// ============================================================================
#ifndef MAGNETIZATION_ASSEMBLER_H
#define MAGNETIZATION_ASSEMBLER_H

#include "utilities/parameters.h"

#include <deal.II/dofs/dof_handler.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/vector.h>
#include <deal.II/base/point.h>
#include <deal.II/base/tensor.h>
#include <cmath>
#include <algorithm>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif



template <int dim>
class MagnetizationAssembler
{
public:
    /// Constructor
    MagnetizationAssembler(
        const Parameters& params,
        const dealii::DoFHandler<dim>& M_dof,
        const dealii::DoFHandler<dim>& U_dof,
        const dealii::DoFHandler<dim>& phi_dof,
        const dealii::DoFHandler<dim>& theta_dof);

    /// Assemble the DG magnetization system
    /// @param system_matrix Output sparse matrix (same for Mx and My)
    /// @param rhs_x Output RHS vector for Mx component
    /// @param rhs_y Output RHS vector for My component
    /// @param Ux x-velocity solution
    /// @param Uy y-velocity solution
    /// @param phi Magnetic potential solution
    /// @param theta Phase field solution
    /// @param Mx_old Previous time step Mx
    /// @param My_old Previous time step My
    /// @param dt Time step size
    /// @param current_time Current time (for MMS source term)
    void assemble(
        dealii::SparseMatrix<double>& system_matrix,
        dealii::Vector<double>& rhs_x,
        dealii::Vector<double>& rhs_y,
        const dealii::Vector<double>& Ux,
        const dealii::Vector<double>& Uy,
        const dealii::Vector<double>& phi,
        const dealii::Vector<double>& theta,
        const dealii::Vector<double>& Mx_old,
        const dealii::Vector<double>& My_old,
        double dt,
        double current_time = 0.0) const;

    /// Assemble only the RHS (for fixed matrix reuse)
    void assemble_rhs_only(
        dealii::Vector<double>& rhs_x,
        dealii::Vector<double>& rhs_y,
        const dealii::Vector<double>& phi,
        const dealii::Vector<double>& theta,
        const dealii::Vector<double>& Mx_old,
        const dealii::Vector<double>& My_old,
        double dt) const;

private:
    const Parameters& params_;
    const dealii::DoFHandler<dim>& M_dof_handler_;
    const dealii::DoFHandler<dim>& U_dof_handler_;
    const dealii::DoFHandler<dim>& phi_dof_handler_;
    const dealii::DoFHandler<dim>& theta_dof_handler_;

    /// Susceptibility function: χ(θ)
    double chi(double theta_val) const;
};

#endif // MAGNETIZATION_ASSEMBLER_H