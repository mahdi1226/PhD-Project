// ============================================================================
// assembly/ns_assembler.h - Navier-Stokes Assembly
//
// Reference: Nochetto, Salgado & Tomas, CMAME 309 (2016) 497-531
// Equation 42e (discrete scheme), p.505
//
// Paper's discrete NS scheme:
//
//   (δU^k/τ, V) + B_h(U^{k-1}, U^k, V) + (ν(θ^{k-1})T(U^k), T(V))
//     - (P^k, div V) + (div U^k, Q) = (F^{k-1}, V)
//
// where:
//   - δU^k = U^k - U^{k-1}
//   - T(U) = ∇U + (∇U)^T (symmetric gradient)
//   - B_h(w,u,v) = (w·∇u, v) + ½(∇·w)(u, v) (skew convection)
//   - ν(θ^{k-1}) = viscosity at LAGGED θ
//   - F^{k-1} = F_cap + F_mag with LAGGED fields
//
// ============================================================================
#ifndef NS_ASSEMBLER_H
#define NS_ASSEMBLER_H

#include <deal.II/dofs/dof_handler.h>
#include <deal.II/lac/affine_constraints.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/vector.h>

#include "utilities/parameters.h"

#include <vector>

/**
 * @brief Assemble the Navier-Stokes system (Paper Eq. 42e)
 *
 * Assembles the coupled (ux, uy, p) system with all forces.
 * Constraints are applied via condense() to preserve saddle-point structure.
 *
 * @param ux_dof_handler    DoFHandler for velocity x (Q2)
 * @param uy_dof_handler    DoFHandler for velocity y (Q2)
 * @param p_dof_handler     DoFHandler for pressure (Q1)
 * @param theta_dof_handler DoFHandler for phase field θ (Q2)
 * @param psi_dof_handler   DoFHandler for chemical potential ψ (Q2)
 * @param phi_dof_handler   DoFHandler for magnetic potential φ (Q2, can be nullptr)
 * @param M_dof_handler     DoFHandler for magnetization M (DG, can be nullptr)
 * @param ux_old            Previous velocity U^{k-1}_x
 * @param uy_old            Previous velocity U^{k-1}_y
 * @param theta_old         Previous phase field θ^{k-1} (LAGGED)
 * @param psi_solution      Current chemical potential ψ^k
 * @param phi_solution      Current magnetic potential φ^k (can be nullptr)
 * @param mx_solution       Current magnetization M^k_x (can be nullptr)
 * @param my_solution       Current magnetization M^k_y (can be nullptr)
 * @param params            Physical parameters
 * @param dt                Time step τ
 * @param current_time      Current time (for MMS)
 * @param ux_to_ns_map      Index map: ux DoF → coupled index
 * @param uy_to_ns_map      Index map: uy DoF → coupled index
 * @param p_to_ns_map       Index map: p DoF → coupled index
 * @param ns_constraints    Combined constraints (hanging nodes + BCs)
 * @param ns_matrix         [OUT] Assembled system matrix
 * @param ns_rhs            [OUT] Assembled RHS vector
 */
template <int dim>
void assemble_ns_system(
    const dealii::DoFHandler<dim>& ux_dof_handler,
    const dealii::DoFHandler<dim>& uy_dof_handler,
    const dealii::DoFHandler<dim>& p_dof_handler,
    const dealii::DoFHandler<dim>& theta_dof_handler,
    const dealii::DoFHandler<dim>& psi_dof_handler,
    const dealii::DoFHandler<dim>* phi_dof_handler,
    const dealii::DoFHandler<dim>* M_dof_handler,
    const dealii::Vector<double>& ux_old,
    const dealii::Vector<double>& uy_old,
    const dealii::Vector<double>& theta_old,
    const dealii::Vector<double>& psi_solution,
    const dealii::Vector<double>* phi_solution,
    const dealii::Vector<double>* mx_solution,
    const dealii::Vector<double>* my_solution,
    const Parameters& params,
    double dt,
    double current_time,
    const std::vector<dealii::types::global_dof_index>& ux_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& uy_to_ns_map,
    const std::vector<dealii::types::global_dof_index>& p_to_ns_map,
    const dealii::AffineConstraints<double>& ns_constraints,
    dealii::SparseMatrix<double>& ns_matrix,
    dealii::Vector<double>& ns_rhs,
    bool projection_only = false);

#endif // NS_ASSEMBLER_H