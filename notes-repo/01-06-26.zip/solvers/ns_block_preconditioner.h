// ============================================================================
// solvers/ns_block_preconditioner.h - Schur Complement Preconditioner with AMG
//
// OPTIMIZED VERSION:
//   1. Uses Trilinos AMG for velocity block (instead of ILU)
//   2. ILU retained for pressure mass (small, SPD)
//   3. GMRES for velocity solve (non-symmetric due to convection)
//   4. CG for Schur solve (pressure mass is SPD)
//
// Key performance improvement: AMG on velocity block gives mesh-independent
// convergence (10-30 inner iterations instead of 100+ with ILU).
//
// References:
//   - deal.II step-22, step-56
//   - Elman, Silvester & Wathen, "Finite Elements and Fast Iterative Solvers"
// ============================================================================
#ifndef NS_BLOCK_PRECONDITIONER_H
#define NS_BLOCK_PRECONDITIONER_H

#include <deal.II/base/subscriptor.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/vector.h>
#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/solver_gmres.h>
#include <deal.II/lac/solver_control.h>
#include <deal.II/lac/sparse_ilu.h>
#include <deal.II/lac/sparse_direct.h>
#include <deal.II/lac/precondition.h>
#include <deal.II/lac/sparsity_pattern.h>

#ifdef DEAL_II_WITH_TRILINOS
#include <deal.II/lac/trilinos_sparse_matrix.h>
#include <deal.II/lac/trilinos_vector.h>
#include <deal.II/lac/trilinos_precondition.h>
#include <deal.II/lac/trilinos_solver.h>
#endif

#include <vector>
#include <memory>

/**
 * @brief Block Schur complement preconditioner for Navier-Stokes with AMG
 *
 * Uses Trilinos AMG for velocity block (if available), otherwise ILU.
 * Pressure mass matrix solved with CG + ILU (always fast).
 *
 * Expected performance with AMG:
 *   - Inner velocity solve: 10-30 iterations
 *   - Outer FGMRES: 20-50 iterations
 *   - Total time: ~3-5s per step (vs 30-70s with ILU)
 */
class BlockSchurPreconditioner : public dealii::EnableObserverPointer
{
public:
    /**
     * @brief Full initialization (first call or after AMR)
     *
     * @param system_matrix  Full NS system matrix [A, B^T; B, 0]
     * @param pressure_mass  Pressure mass matrix for Schur approximation
     * @param ux_to_ns_map   Mapping from ux DoFs to coupled system
     * @param uy_to_ns_map   Mapping from uy DoFs to coupled system
     * @param p_to_ns_map    Mapping from p DoFs to coupled system
     * @param do_solve_A     If true, solve A*x=b; if false, just apply preconditioner
     * @param viscosity      Viscosity for Schur scaling (recommended)
     */
    BlockSchurPreconditioner(
        const dealii::SparseMatrix<double>& system_matrix,
        const dealii::SparseMatrix<double>& pressure_mass,
        const std::vector<dealii::types::global_dof_index>& ux_to_ns_map,
        const std::vector<dealii::types::global_dof_index>& uy_to_ns_map,
        const std::vector<dealii::types::global_dof_index>& p_to_ns_map,
        bool do_solve_A = true,
        double viscosity = 1.0);

    /**
     * @brief Update with new matrix values (same sparsity, between AMR events)
     */
    void update(const dealii::SparseMatrix<double>& system_matrix,
                const dealii::SparseMatrix<double>& pressure_mass);

    /**
     * @brief Apply preconditioner: dst = P^{-1} * src
     */
    void vmult(dealii::Vector<double>& dst,
               const dealii::Vector<double>& src) const;

    // Statistics (accumulated, reset manually if needed)
    mutable unsigned int n_iterations_A;
    mutable unsigned int n_iterations_S;

    // Tuning parameters (can be set after construction)
    double inner_tolerance;
    unsigned int max_inner_iterations;

private:
    void extract_velocity_block();
    void initialize_preconditioners();

    void extract_velocity(const dealii::Vector<double>& src,
                          dealii::Vector<double>& vel) const;

    void extract_pressure(const dealii::Vector<double>& src,
                          dealii::Vector<double>& p) const;

    void insert_velocity(const dealii::Vector<double>& vel,
                         dealii::Vector<double>& dst) const;

    void insert_pressure(const dealii::Vector<double>& p,
                         dealii::Vector<double>& dst) const;

    void apply_BT(const dealii::Vector<double>& p,
                  dealii::Vector<double>& vel) const;

    const dealii::SparseMatrix<double>* system_matrix_ptr_;
    const dealii::SparseMatrix<double>* pressure_mass_ptr_;

    std::vector<dealii::types::global_dof_index> ux_map_;
    std::vector<dealii::types::global_dof_index> uy_map_;
    std::vector<dealii::types::global_dof_index> p_map_;

    unsigned int n_ux_, n_uy_, n_p_, n_vel_, n_total_;

    std::vector<int> global_to_vel_;
    std::vector<int> global_to_p_;

    dealii::SparsityPattern velocity_sparsity_;
    dealii::SparseMatrix<double> velocity_block_;

#ifdef DEAL_II_WITH_TRILINOS
    mutable dealii::TrilinosWrappers::SparseMatrix trilinos_velocity_block_;
    mutable dealii::TrilinosWrappers::PreconditionAMG A_amg_preconditioner_;
    bool amg_initialized_;
#endif

    dealii::SparseILU<double> A_ilu_preconditioner_;
    dealii::SparseILU<double> S_preconditioner_;

    bool do_solve_A_;
    double viscosity_;
};

#endif // NS_BLOCK_PRECONDITIONER_H