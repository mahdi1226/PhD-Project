// ============================================================================
// solvers/poisson_solver.cc - Magnetostatic Poisson Solver
//
// UPDATED: Now with Trilinos AMG preconditioning for scalability
//
// Solver hierarchy:
//   1. CG + AMG (Trilinos ML) - default, scalable
//   2. CG + SSOR - fallback if AMG unavailable
//   3. Direct (UMFPACK) - fallback if iterative fails
//
// Reference: Nochetto, Salgado & Tomas, CMAME 309 (2016) 497-531
// ============================================================================

#include "solvers/poisson_solver.h"
#include "utilities/parameters.h"

#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/solver_control.h>
#include <deal.II/lac/precondition.h>
#include <deal.II/lac/sparse_direct.h>
#include <deal.II/lac/dynamic_sparsity_pattern.h>

// Trilinos AMG support
#ifdef DEAL_II_WITH_TRILINOS
#include <deal.II/lac/trilinos_sparse_matrix.h>
#include <deal.II/lac/trilinos_vector.h>
#include <deal.II/lac/trilinos_precondition.h>
#include <deal.II/lac/trilinos_solver.h>
#endif

#include <iostream>
#include <chrono>

// ============================================================================
// AMG Solver Implementation (Trilinos ML)
// ============================================================================
#ifdef DEAL_II_WITH_TRILINOS

namespace
{
    /**
     * @brief Convert deal.II SparseMatrix to Trilinos format
     *
     * This is done on-the-fly to minimize code changes.
     * For maximum performance, store in Trilinos format from the start.
     */
    void copy_to_trilinos(
        const dealii::SparseMatrix<double>& src,
        dealii::TrilinosWrappers::SparseMatrix& dst)
    {
        // For serial case, use the sparsity pattern directly
        const unsigned int n = src.m();

        // Build sparsity pattern info for Trilinos
        dealii::IndexSet locally_owned(n);
        locally_owned.add_range(0, n);

        // Create dynamic sparsity pattern from source matrix
        dealii::DynamicSparsityPattern dsp(n, n);
        for (unsigned int row = 0; row < n; ++row)
        {
            for (auto it = src.begin(row); it != src.end(row); ++it)
            {
                dsp.add(row, it->column());
            }
        }

        // Initialize Trilinos matrix with sparsity pattern
        dst.reinit(locally_owned, locally_owned, dsp, MPI_COMM_SELF);

        // Copy values
        for (unsigned int row = 0; row < n; ++row)
        {
            for (auto it = src.begin(row); it != src.end(row); ++it)
            {
                dst.set(row, it->column(), it->value());
            }
        }
        dst.compress(dealii::VectorOperation::insert);
    }

    /**
     * @brief Solve using CG + Trilinos ML AMG preconditioner
     */
    bool solve_with_amg(
        const dealii::SparseMatrix<double>& matrix,
        const dealii::Vector<double>& rhs,
        dealii::Vector<double>& solution,
        const LinearSolverParams& params,
        unsigned int& iterations,
        double& final_residual,
        double& amg_setup_time,
        bool log_output)
    {
        const unsigned int n = matrix.m();

        // Create index set for serial case
        dealii::IndexSet locally_owned(n);
        locally_owned.add_range(0, n);

        // Convert matrix to Trilinos format
        auto convert_start = std::chrono::high_resolution_clock::now();
        dealii::TrilinosWrappers::SparseMatrix trilinos_matrix;
        copy_to_trilinos(matrix, trilinos_matrix);
        auto convert_end = std::chrono::high_resolution_clock::now();

        if (log_output)
        {
            double convert_time = std::chrono::duration<double>(convert_end - convert_start).count();
            std::cout << "[Poisson AMG] Matrix conversion: " << convert_time << "s\n";
        }

        // Copy vectors to Trilinos format
        dealii::TrilinosWrappers::MPI::Vector trilinos_rhs(locally_owned, MPI_COMM_SELF);
        dealii::TrilinosWrappers::MPI::Vector trilinos_solution(locally_owned, MPI_COMM_SELF);

        for (unsigned int i = 0; i < n; ++i)
        {
            trilinos_rhs[i] = rhs[i];
            trilinos_solution[i] = solution[i];
        }
        trilinos_rhs.compress(dealii::VectorOperation::insert);
        trilinos_solution.compress(dealii::VectorOperation::insert);

        // Setup AMG preconditioner
        auto amg_start = std::chrono::high_resolution_clock::now();

        dealii::TrilinosWrappers::PreconditionAMG preconditioner;
        dealii::TrilinosWrappers::PreconditionAMG::AdditionalData amg_data;

        // AMG parameters tuned for Poisson/Laplacian problems
        amg_data.elliptic = true;              // Poisson is elliptic
        amg_data.higher_order_elements = true; // We use Q2 elements
        amg_data.smoother_sweeps = 2;          // Pre/post smoothing sweeps
        amg_data.aggregation_threshold = 0.02; // Coarsening threshold
        amg_data.output_details = false;       // Quiet unless debugging

        preconditioner.initialize(trilinos_matrix, amg_data);

        auto amg_end = std::chrono::high_resolution_clock::now();
        amg_setup_time = std::chrono::duration<double>(amg_end - amg_start).count();

        if (log_output)
        {
            std::cout << "[Poisson AMG] Preconditioner setup: " << amg_setup_time << "s\n";
        }

        // Solve with CG + AMG
        const double tol = std::max(params.abs_tolerance,
                                    params.rel_tolerance * rhs.l2_norm());

        dealii::SolverControl solver_control(params.max_iterations, tol);

        try
        {
            dealii::TrilinosWrappers::SolverCG solver(solver_control);
            solver.solve(trilinos_matrix, trilinos_solution, trilinos_rhs, preconditioner);

            iterations = solver_control.last_step();
            final_residual = solver_control.last_value();

            // Copy solution back
            for (unsigned int i = 0; i < n; ++i)
            {
                solution[i] = trilinos_solution[i];
            }

            return true;
        }
        catch (dealii::SolverControl::NoConvergence& e)
        {
            iterations = e.last_step;
            final_residual = e.last_residual;

            // Still copy partial solution
            for (unsigned int i = 0; i < n; ++i)
            {
                solution[i] = trilinos_solution[i];
            }

            return false;
        }
    }
}

#endif // DEAL_II_WITH_TRILINOS

// ============================================================================
// Fallback: CG + SSOR (no Trilinos dependency)
// ============================================================================
namespace
{
    bool solve_with_ssor(
        const dealii::SparseMatrix<double>& matrix,
        const dealii::Vector<double>& rhs,
        dealii::Vector<double>& solution,
        const LinearSolverParams& params,
        unsigned int& iterations,
        double& final_residual)
    {
        const double tol = std::max(params.abs_tolerance,
                                    params.rel_tolerance * rhs.l2_norm());

        dealii::SolverControl solver_control(params.max_iterations, tol);
        dealii::SolverCG<dealii::Vector<double>> solver(solver_control);

        dealii::PreconditionSSOR<dealii::SparseMatrix<double>> preconditioner;
        preconditioner.initialize(matrix, params.ssor_omega);

        try
        {
            solver.solve(matrix, solution, rhs, preconditioner);
            iterations = solver_control.last_step();
            final_residual = solver_control.last_value();
            return true;
        }
        catch (dealii::SolverControl::NoConvergence& e)
        {
            iterations = e.last_step;
            final_residual = e.last_residual;
            return false;
        }
    }
}

// ============================================================================
// Main solver with explicit parameters - RETURNS SolverInfo
// ============================================================================
SolverInfo solve_poisson_system(
    const dealii::SparseMatrix<double>& matrix,
    const dealii::Vector<double>& rhs,
    dealii::Vector<double>& solution,
    const dealii::AffineConstraints<double>& constraints,
    const LinearSolverParams& params,
    bool log_output)
{
    SolverInfo info;
    info.solver_name = "Poisson";
    info.matrix_size = matrix.m();
    info.nnz = matrix.n_nonzero_elements();

    const double rhs_norm = rhs.l2_norm();
    if (rhs_norm < 1e-14)
    {
        solution = 0;
        constraints.distribute(solution);
        if (log_output)
            std::cout << "[Poisson] Zero RHS, solution set to zero\n";
        info.converged = true;
        return info;
    }



    if (solution.size() != rhs.size())
        solution.reinit(rhs.size());

    auto start = std::chrono::high_resolution_clock::now();
    bool converged = false;
    unsigned int iterations = 0;
    double final_residual = 0.0;

    if (params.use_iterative)
    {
#ifdef DEAL_II_WITH_TRILINOS
        // Try AMG first (much better for large problems)
        double amg_setup_time = 0.0;
        converged = solve_with_amg(matrix, rhs, solution, params,
                                   iterations, final_residual,
                                   amg_setup_time, log_output);

        if (!converged && log_output)
        {
            std::cerr << "[Poisson] WARNING: CG+AMG did not converge after "
                      << iterations << " iterations. "
                      << "Residual = " << final_residual << "\n";

            converged = solve_with_ssor(matrix, rhs, solution, params,
                                    iterations, final_residual);
        }
#else
        // Fallback to SSOR if no Trilinos
        converged = solve_with_ssor(matrix, rhs, solution, params,
                                    iterations, final_residual);

        if (!converged && log_output)
        {
            std::cerr << "[Poisson] WARNING: CG+SSOR did not converge after "
                      << iterations << " iterations. "
                      << "Residual = " << final_residual << "\n";
        }
#endif
    }

    // Direct solver fallback
    if (!converged && params.fallback_to_direct)
    {
        if (log_output)
            std::cerr << "[Poisson] Falling back to direct solver.\n";

        dealii::SparseDirectUMFPACK direct_solver;
        direct_solver.initialize(matrix);
        direct_solver.vmult(solution, rhs);
        converged = true;
        iterations = 1;
        final_residual = 0.0;
        info.used_direct = true;
    }

    auto end = std::chrono::high_resolution_clock::now();
    double solve_time = std::chrono::duration<double>(end - start).count();

    constraints.distribute(solution);

    // Fill SolverInfo
    info.iterations = iterations;
    info.residual = final_residual;
    info.solve_time = solve_time;
    info.converged = converged;

    if (log_output || params.verbose)
    {
        std::cout << "[Poisson] Size: " << matrix.m()
                  << ", iterations: " << iterations
                  << ", residual: " << std::scientific << final_residual
                  << ", time: " << std::fixed << solve_time << "s";
#ifdef DEAL_II_WITH_TRILINOS
        std::cout << " (AMG)";
#else
        std::cout << " (SSOR)";
#endif
        if (info.used_direct)
            std::cout << " [DIRECT]";
        std::cout << "\n";
    }

    return info;
}

// ============================================================================
// Legacy interface with default parameters
// ============================================================================
SolverInfo solve_poisson_system(
    const dealii::SparseMatrix<double>& matrix,
    const dealii::Vector<double>& rhs,
    dealii::Vector<double>& solution,
    const dealii::AffineConstraints<double>& constraints,
    bool verbose)
{
    // Default Poisson parameters (SPD system: CG + AMG)
    LinearSolverParams default_params;
    default_params.type = LinearSolverParams::Type::CG;
    default_params.preconditioner = LinearSolverParams::Preconditioner::SSOR; // Fallback
    default_params.rel_tolerance = 1e-8;
    default_params.abs_tolerance = 1e-12;
    default_params.max_iterations = 500;  // AMG should converge much faster
    default_params.ssor_omega = 1.2;
    default_params.use_iterative = true;
    default_params.fallback_to_direct = true;
    default_params.verbose = verbose;

    return solve_poisson_system(matrix, rhs, solution, constraints,
                                default_params, /*log_output=*/true);
}