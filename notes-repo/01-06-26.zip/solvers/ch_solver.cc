// ============================================================================
// solvers/ch_solver.cc - Cahn-Hilliard System Solver with AMG
//
// OPTIMIZED VERSION: Replaces ILU with Trilinos AMG preconditioner
//
// Why this works:
// - The CH system [M+τγA, -τM; B, εM] has a dominant shifted-Laplacian (1,1) block
// - AMG handles elliptic operators with mesh-independent convergence
// - Expected: 20-80 iterations (vs 2000+ with ILU failing)
//
// Reference: Nochetto, Salgado & Tomas, CMAME 309 (2016) 497-531
// ============================================================================

#include "solvers/ch_solver.h"
#include "utilities/parameters.h"

#include <deal.II/lac/solver_gmres.h>
#include <deal.II/lac/solver_control.h>
#include <deal.II/lac/sparse_ilu.h>
#include <deal.II/lac/sparse_direct.h>

#ifdef DEAL_II_WITH_TRILINOS
#include <deal.II/lac/trilinos_sparse_matrix.h>
#include <deal.II/lac/trilinos_vector.h>
#include <deal.II/lac/trilinos_precondition.h>
#include <deal.II/lac/trilinos_solver.h>
#include <deal.II/lac/dynamic_sparsity_pattern.h>
#endif

#include <iostream>
#include <chrono>
#include <cmath>

// ============================================================================
// Helper: Convert deal.II SparseMatrix to Trilinos format
// ============================================================================
#ifdef DEAL_II_WITH_TRILINOS
static void copy_matrix_to_trilinos(
    const dealii::SparseMatrix<double>& src,
    dealii::TrilinosWrappers::SparseMatrix& dst)
{
    const unsigned int n = src.m();

    dealii::IndexSet locally_owned(n);
    locally_owned.add_range(0, n);

    dealii::DynamicSparsityPattern dsp(n, n);
    for (unsigned int row = 0; row < n; ++row)
    {
        for (auto it = src.begin(row); it != src.end(row); ++it)
            dsp.add(row, it->column());
    }

    dst.reinit(locally_owned, locally_owned, dsp, MPI_COMM_SELF);

    for (unsigned int row = 0; row < n; ++row)
    {
        for (auto it = src.begin(row); it != src.end(row); ++it)
            dst.set(row, it->column(), it->value());
    }
    dst.compress(dealii::VectorOperation::insert);
}
#endif

// ============================================================================
// Helper: Solve CH system using GMRES + Trilinos AMG preconditioner
// ============================================================================
#ifdef DEAL_II_WITH_TRILINOS
static bool solve_ch_with_amg(
    const dealii::SparseMatrix<double>& matrix,
    const dealii::Vector<double>& rhs,
    dealii::Vector<double>& solution,
    const LinearSolverParams& params,
    unsigned int& iterations,
    double& final_residual,
    double& setup_time,
    bool log_output)
{
    const unsigned int n = matrix.m();

    dealii::IndexSet locally_owned(n);
    locally_owned.add_range(0, n);

    // Convert matrix to Trilinos format
    auto convert_start = std::chrono::high_resolution_clock::now();
    dealii::TrilinosWrappers::SparseMatrix trilinos_matrix;
    copy_matrix_to_trilinos(matrix, trilinos_matrix);

    // Copy vectors
    dealii::TrilinosWrappers::MPI::Vector trilinos_rhs(locally_owned, MPI_COMM_SELF);
    dealii::TrilinosWrappers::MPI::Vector trilinos_solution(locally_owned, MPI_COMM_SELF);

    for (unsigned int i = 0; i < n; ++i)
    {
        trilinos_rhs[i] = rhs[i];
        trilinos_solution[i] = solution[i];
    }
    trilinos_rhs.compress(dealii::VectorOperation::insert);
    trilinos_solution.compress(dealii::VectorOperation::insert);

    auto convert_end = std::chrono::high_resolution_clock::now();

    // Setup AMG preconditioner
    auto amg_start = std::chrono::high_resolution_clock::now();

    dealii::TrilinosWrappers::PreconditionAMG preconditioner;
    dealii::TrilinosWrappers::PreconditionAMG::AdditionalData amg_data;

    // AMG parameters for CH system (non-symmetric saddle-point-like)
    amg_data.elliptic = true;
    amg_data.higher_order_elements = true;
    amg_data.smoother_sweeps = 2;
    amg_data.aggregation_threshold = 0.02;
    amg_data.output_details = false;
    amg_data.smoother_type = "Chebyshev";  // Good for non-symmetric

    preconditioner.initialize(trilinos_matrix, amg_data);

    auto amg_end = std::chrono::high_resolution_clock::now();
    setup_time = std::chrono::duration<double>(amg_end - amg_start).count();

    if (log_output)
    {
        double convert_time = std::chrono::duration<double>(convert_end - convert_start).count();
        std::cout << "[CH AMG] Matrix conversion: " << convert_time
                  << "s, AMG setup: " << setup_time << "s\n";
    }

    // Solve with GMRES + AMG preconditioner
    const double tol = std::max(params.abs_tolerance,
                                params.rel_tolerance * rhs.l2_norm());

    dealii::SolverControl solver_control(params.max_iterations, tol);

    try
    {
        dealii::TrilinosWrappers::SolverGMRES solver(solver_control);
        solver.solve(trilinos_matrix, trilinos_solution, trilinos_rhs, preconditioner);

        iterations = solver_control.last_step();
        final_residual = solver_control.last_value();

        // Copy solution back
        for (unsigned int i = 0; i < n; ++i)
            solution[i] = trilinos_solution[i];

        return true;
    }
    catch (dealii::SolverControl::NoConvergence& e)
    {
        iterations = e.last_step;
        final_residual = e.last_residual;

        for (unsigned int i = 0; i < n; ++i)
            solution[i] = trilinos_solution[i];

        return false;
    }
}
#endif // DEAL_II_WITH_TRILINOS

// ============================================================================
// Helper: Fallback GMRES + ILU solver
// ============================================================================
static bool solve_ch_with_ilu(
    const dealii::SparseMatrix<double>& matrix,
    const dealii::Vector<double>& rhs,
    dealii::Vector<double>& solution,
    const LinearSolverParams& params,
    unsigned int& iterations,
    double& final_residual)
{
    const double tol = std::max(params.abs_tolerance,
                                params.rel_tolerance * rhs.l2_norm());

    dealii::SolverControl solver_control(params.max_iterations, tol);

    typename dealii::SolverGMRES<dealii::Vector<double>>::AdditionalData gmres_data;
    gmres_data.max_n_tmp_vectors = params.gmres_restart + 2;
    dealii::SolverGMRES<dealii::Vector<double>> solver(solver_control, gmres_data);

    dealii::SparseILU<double> preconditioner;
    typename dealii::SparseILU<double>::AdditionalData ilu_data;
    ilu_data.strengthen_diagonal = (params.ilu_strengthen > 0.0)
                                    ? params.ilu_strengthen : 1.2;

    try
    {
        preconditioner.initialize(matrix, ilu_data);
    }
    catch (const std::exception& e)
    {
        std::cerr << "[CH ILU] Initialization failed: " << e.what() << "\n";
        return false;
    }

    try
    {
        solver.solve(matrix, solution, rhs, preconditioner);
        iterations = solver_control.last_step();
        final_residual = solver_control.last_value();

        if (!std::isfinite(final_residual) || !std::isfinite(solution.l2_norm()))
        {
            std::cerr << "[CH ILU] NaN detected in solution\n";
            return false;
        }

        return true;
    }
    catch (dealii::SolverControl::NoConvergence& e)
    {
        iterations = e.last_step;
        final_residual = e.last_residual;
        return false;
    }
}

// ============================================================================
// Main solver with explicit parameters - RETURNS SolverInfo
// ============================================================================
SolverInfo solve_ch_system(
    const dealii::SparseMatrix<double>& matrix,
    const dealii::Vector<double>& rhs,
    const dealii::AffineConstraints<double>& constraints,
    const std::vector<dealii::types::global_dof_index>& theta_to_ch_map,
    const std::vector<dealii::types::global_dof_index>& psi_to_ch_map,
    dealii::Vector<double>& theta_solution,
    dealii::Vector<double>& psi_solution,
    const LinearSolverParams& params,
    bool log_output)
{
    SolverInfo info;
    info.solver_name = "CH";
    info.matrix_size = matrix.m();
    info.nnz = matrix.n_nonzero_elements();
    info.iterations = 0;
    info.residual = 0.0;
    info.converged = false;
    info.used_direct = false;

    dealii::Vector<double> coupled_solution(rhs.size());

    const double rhs_norm = rhs.l2_norm();
    if (rhs_norm < 1e-14)
    {
        coupled_solution = 0;
        constraints.distribute(coupled_solution);

        for (unsigned int i = 0; i < theta_solution.size(); ++i)
            theta_solution[i] = coupled_solution[theta_to_ch_map[i]];
        for (unsigned int i = 0; i < psi_solution.size(); ++i)
            psi_solution[i] = coupled_solution[psi_to_ch_map[i]];

        if (log_output)
            std::cout << "[CH Solver] Zero RHS, solution set to zero\n";

        info.converged = true;
        info.iterations = 0;
        return info;
    }

    auto start = std::chrono::high_resolution_clock::now();

    if (params.use_iterative)
    {
        unsigned int iterations = 0;
        double final_residual = 0.0;
        bool converged = false;

#ifdef DEAL_II_WITH_TRILINOS
        // Try AMG first
        double setup_time = 0.0;
        converged = solve_ch_with_amg(matrix, rhs, coupled_solution, params,
                                      iterations, final_residual,
                                      setup_time, log_output);

        if (converged)
        {
            info.converged = true;
            info.iterations = iterations;
            info.residual = final_residual;

            if (log_output)
            {
                std::cout << "[CH AMG] Converged in " << iterations
                          << " iterations, residual = " << std::scientific
                          << final_residual << "\n";
            }
        }
        else
        {
            if (log_output)
            {
                std::cerr << "[CH AMG] Did not converge after " << iterations
                          << " iterations, residual = " << final_residual << "\n";
                std::cerr << "[CH AMG] Falling back to ILU...\n";
            }

            coupled_solution = 0;
            converged = solve_ch_with_ilu(matrix, rhs, coupled_solution, params,
                                          iterations, final_residual);

            info.iterations = iterations;
            info.residual = final_residual;
            info.converged = converged;
        }
#else
        // No Trilinos, use ILU directly
        converged = solve_ch_with_ilu(matrix, rhs, coupled_solution, params,
                                      iterations, final_residual);
        info.iterations = iterations;
        info.residual = final_residual;
        info.converged = converged;
#endif
    }

    // Fallback to direct solver
    if (!info.converged && params.fallback_to_direct)
    {
        if (log_output)
            std::cerr << "[CH Solver] Falling back to direct solver.\n";

        dealii::SparseDirectUMFPACK direct_solver;
        direct_solver.initialize(matrix);
        direct_solver.vmult(coupled_solution, rhs);

        info.converged = true;
        info.iterations = 1;
        info.residual = 0.0;
        info.used_direct = true;
    }

    auto end = std::chrono::high_resolution_clock::now();
    info.solve_time = std::chrono::duration<double>(end - start).count();

    constraints.distribute(coupled_solution);

    // Extract individual solutions
    for (unsigned int i = 0; i < theta_solution.size(); ++i)
        theta_solution[i] = coupled_solution[theta_to_ch_map[i]];

    for (unsigned int i = 0; i < psi_solution.size(); ++i)
        psi_solution[i] = coupled_solution[psi_to_ch_map[i]];

    if (log_output || params.verbose)
    {
        std::cout << "[CH Solver] Size: " << matrix.m()
                  << ", nnz: " << matrix.n_nonzero_elements()
                  << ", iterations: " << info.iterations
                  << ", residual: " << std::scientific << std::setprecision(4) << info.residual
                  << ", time: " << std::fixed << std::setprecision(4) << info.solve_time << "s";
#ifdef DEAL_II_WITH_TRILINOS
        if (!info.used_direct)
            std::cout << " (AMG)";
#endif
        if (info.used_direct)
            std::cout << " (DIRECT)";
        std::cout << "\n";
    }

    return info;
}

// ============================================================================
// Legacy interface with default parameters
// ============================================================================
SolverInfo solve_ch_system(
    const dealii::SparseMatrix<double>& matrix,
    const dealii::Vector<double>& rhs,
    const dealii::AffineConstraints<double>& constraints,
    const std::vector<dealii::types::global_dof_index>& theta_to_ch_map,
    const std::vector<dealii::types::global_dof_index>& psi_to_ch_map,
    dealii::Vector<double>& theta_solution,
    dealii::Vector<double>& psi_solution)
{
    LinearSolverParams default_params;
    default_params.type = LinearSolverParams::Type::GMRES;
    default_params.preconditioner = LinearSolverParams::Preconditioner::AMG;
    default_params.rel_tolerance = 1e-8;
    default_params.abs_tolerance = 1e-12;
    default_params.max_iterations = 500;
    default_params.gmres_restart = 50;
    default_params.ilu_strengthen = 1.2;
    default_params.use_iterative = true;
    default_params.fallback_to_direct = true;
    default_params.verbose = false;

    return solve_ch_system(matrix, rhs, constraints,
                           theta_to_ch_map, psi_to_ch_map,
                           theta_solution, psi_solution,
                           default_params, /*log_output=*/true);
}