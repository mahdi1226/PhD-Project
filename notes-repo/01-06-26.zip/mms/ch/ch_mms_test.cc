// ============================================================================
// mms/ch/ch_mms_test.cc - CH MMS Test Implementation
//
// Uses MMSContext for setup, which calls PRODUCTION code:
//   - setup_ch_coupled_system() from setup/ch_setup.h
//   - assemble_ch_system() from assembly/ch_assembler.h
//   - solve_ch_system() from solvers/ch_solver.h
//
// Reference: Nochetto, Salgado & Tomas, CMAME 309 (2016) 497-531
// ============================================================================

#include "mms/ch/ch_mms_test.h"
#include "mms/ch/ch_mms.h"
#include "mms/mms_context.h"

// PRODUCTION components
#include "assembly/ch_assembler.h"
#include "solvers/ch_solver.h"

#include <deal.II/lac/sparse_direct.h>

#include <iostream>
#include <iomanip>
#include <fstream>
#include <chrono>
#include <cmath>

// ============================================================================
// CHMMSConvergenceResult Implementation
// ============================================================================

void CHMMSConvergenceResult::compute_rates()
{
    theta_L2_rates.clear();
    theta_H1_rates.clear();
    psi_L2_rates.clear();

    for (size_t i = 1; i < results.size(); ++i)
    {
        const double h_ratio = results[i-1].h / results[i].h;
        const double log_h_ratio = std::log(h_ratio);

        if (results[i-1].theta_L2 > 1e-15 && results[i].theta_L2 > 1e-15)
        {
            theta_L2_rates.push_back(
                std::log(results[i-1].theta_L2 / results[i].theta_L2) / log_h_ratio);
        }
        else
        {
            theta_L2_rates.push_back(0.0);
        }

        if (results[i-1].theta_H1 > 1e-15 && results[i].theta_H1 > 1e-15)
        {
            theta_H1_rates.push_back(
                std::log(results[i-1].theta_H1 / results[i].theta_H1) / log_h_ratio);
        }
        else
        {
            theta_H1_rates.push_back(0.0);
        }

        if (results[i-1].psi_L2 > 1e-15 && results[i].psi_L2 > 1e-15)
        {
            psi_L2_rates.push_back(
                std::log(results[i-1].psi_L2 / results[i].psi_L2) / log_h_ratio);
        }
        else
        {
            psi_L2_rates.push_back(0.0);
        }
    }
}

void CHMMSConvergenceResult::print() const
{
    std::cout << "\n========================================\n";
    std::cout << "MMS Convergence Results: CH_STANDALONE\n";
    std::cout << "========================================\n";

    std::cout << std::left
              << std::setw(6) << "Ref"
              << std::setw(12) << "h"
              << std::setw(12) << "θ_L2"
              << std::setw(8) << "rate"
              << std::setw(12) << "θ_H1"
              << std::setw(8) << "rate"
              << std::setw(12) << "ψ_L2"
              << std::setw(8) << "rate"
              << std::setw(10) << "time(s)"
              << "\n";
    std::cout << std::string(88, '-') << "\n";

    for (size_t i = 0; i < results.size(); ++i)
    {
        const auto& r = results[i];
        std::cout << std::left << std::setw(6) << r.refinement
                  << std::scientific << std::setprecision(2)
                  << std::setw(12) << r.h
                  << std::setw(12) << r.theta_L2
                  << std::fixed << std::setprecision(2)
                  << std::setw(8) << (i > 0 ? theta_L2_rates[i-1] : 0.0)
                  << std::scientific << std::setprecision(2)
                  << std::setw(12) << r.theta_H1
                  << std::fixed << std::setprecision(2)
                  << std::setw(8) << (i > 0 ? theta_H1_rates[i-1] : 0.0)
                  << std::scientific << std::setprecision(2)
                  << std::setw(12) << r.psi_L2
                  << std::fixed << std::setprecision(2)
                  << std::setw(8) << (i > 0 ? psi_L2_rates[i-1] : 0.0)
                  << std::setw(10) << r.total_time
                  << "\n";
    }
    std::cout << "========================================\n";

    if (passes())
        std::cout << "[PASS] All convergence rates within tolerance!\n";
    else
        std::cout << "[FAIL] Some convergence rates below expected!\n";
}

void CHMMSConvergenceResult::write_csv(const std::string& filename) const
{
    std::ofstream file(filename);
    if (!file.is_open())
    {
        std::cerr << "[CH MMS] Failed to open " << filename << " for writing\n";
        return;
    }

    file << "refinement,h,n_dofs,theta_L2,theta_L2_rate,theta_H1,theta_H1_rate,"
         << "psi_L2,psi_L2_rate,setup_time,assembly_time,solve_time,total_time,"
         << "solver_iterations,solver_residual\n";

    for (size_t i = 0; i < results.size(); ++i)
    {
        const auto& r = results[i];
        file << r.refinement << ","
             << std::scientific << std::setprecision(6) << r.h << ","
             << r.n_dofs << ","
             << r.theta_L2 << ","
             << (i > 0 ? theta_L2_rates[i-1] : 0.0) << ","
             << r.theta_H1 << ","
             << (i > 0 ? theta_H1_rates[i-1] : 0.0) << ","
             << r.psi_L2 << ","
             << (i > 0 ? psi_L2_rates[i-1] : 0.0) << ","
             << std::fixed << std::setprecision(4)
             << r.setup_time << ","
             << r.assembly_time << ","
             << r.solve_time << ","
             << r.total_time << ","
             << r.solver_iterations << ","
             << std::scientific << r.solver_residual << "\n";
    }

    file.close();
    std::cout << "[CH MMS] Results written to " << filename << "\n";
}

bool CHMMSConvergenceResult::passes(double tol) const
{
    if (theta_L2_rates.empty())
        return false;

    // Check last rate is within tolerance of expected
    const double last_L2_rate = theta_L2_rates.back();
    const double last_H1_rate = theta_H1_rates.back();

    return (last_L2_rate >= expected_L2_rate - tol) &&
           (last_H1_rate >= expected_H1_rate - tol);
}

// ============================================================================
// run_ch_mms_single - Single refinement test using MMSContext
// ============================================================================

template <int dim>
static CHMMSResult run_ch_mms_single_impl(
    unsigned int refinement,
    Parameters params,
    CHSolverType solver_type,
    unsigned int n_time_steps)
{
    CHMMSResult result;
    result.refinement = refinement;

    auto total_start = std::chrono::high_resolution_clock::now();

    // ========================================================================
    // MMS Parameters
    // ========================================================================
    const double t_init = 0.1;
    const double t_final = 0.2;
    const double dt = (t_final - t_init) / n_time_steps;

    params.enable_mms = true;
    params.enable_ns = false;  // Standalone CH
    params.time.dt = dt;

    // Domain: unit square for MMS
    params.domain.x_min = 0.0;
    params.domain.x_max = 1.0;
    params.domain.y_min = 0.0;
    params.domain.y_max = 1.0;
    params.domain.initial_cells_x = 1;
    params.domain.initial_cells_y = 1;

    // ========================================================================
    // Setup using MMSContext - USES PRODUCTION CODE
    // ========================================================================
    auto setup_start = std::chrono::high_resolution_clock::now();

    MMSContext<dim> ctx;
    ctx.setup_mesh(params, refinement);
    ctx.setup_ch(params, t_init);
    ctx.apply_ch_initial_conditions(params, t_init);

    auto setup_end = std::chrono::high_resolution_clock::now();
    double total_setup_time = std::chrono::duration<double>(setup_end - setup_start).count();

    // Zero velocity for standalone CH (no NS coupling)
    dealii::Vector<double> ux_zero(ctx.theta_dof_handler.n_dofs());
    dealii::Vector<double> uy_zero(ctx.theta_dof_handler.n_dofs());
    ux_zero = 0;
    uy_zero = 0;

    const unsigned int n_theta = ctx.theta_dof_handler.n_dofs();

    // ========================================================================
    // Time stepping loop
    // ========================================================================
    double current_time = t_init;
    double total_assembly_time = 0.0;
    double total_solve_time = 0.0;
    unsigned int total_iterations = 0;
    double last_residual = 0.0;

    for (unsigned int step = 0; step < n_time_steps; ++step)
    {
        current_time += dt;
        ctx.theta_old = ctx.theta_solution;

        // Update boundary constraints for new time
        ctx.update_ch_constraints(params, current_time);

        // ====================================================================
        // ASSEMBLY - Using PRODUCTION code
        // ====================================================================
        auto assembly_start = std::chrono::high_resolution_clock::now();

        ctx.ch_matrix = 0;
        ctx.ch_rhs = 0;

        assemble_ch_system<dim>(
            ctx.theta_dof_handler, ctx.psi_dof_handler,
            ctx.theta_old, ux_zero, uy_zero,
            params, dt, current_time,
            ctx.theta_to_ch_map, ctx.psi_to_ch_map,
            ctx.ch_matrix, ctx.ch_rhs);

        ctx.ch_constraints.condense(ctx.ch_matrix, ctx.ch_rhs);

        auto assembly_end = std::chrono::high_resolution_clock::now();
        total_assembly_time += std::chrono::duration<double>(assembly_end - assembly_start).count();

        // ====================================================================
        // SOLVE - Using PRODUCTION code
        // ====================================================================
        auto solve_start = std::chrono::high_resolution_clock::now();

        dealii::Vector<double> ch_solution(ctx.ch_rhs.size());

        if (solver_type == CHSolverType::Direct)
        {
            // Direct solver (for comparison/debugging)
            dealii::SparseDirectUMFPACK direct_solver;
            direct_solver.initialize(ctx.ch_matrix);
            direct_solver.vmult(ch_solution, ctx.ch_rhs);
            ctx.ch_constraints.distribute(ch_solution);
            total_iterations += 1;
        }
        else
        {
            // PRODUCTION solver (GMRES + ILU)
            SolverInfo info = solve_ch_system(
                ctx.ch_matrix, ctx.ch_rhs, ctx.ch_constraints,
                ctx.theta_to_ch_map, ctx.psi_to_ch_map,
                ctx.theta_solution, ctx.psi_solution,
                params.solvers.ch, false);

            total_iterations += info.iterations;
            last_residual = info.residual;
        }

        // Extract θ and ψ from coupled solution (if direct solver)
        if (solver_type == CHSolverType::Direct)
        {
            for (unsigned int i = 0; i < n_theta; ++i)
            {
                ctx.theta_solution[i] = ch_solution[ctx.theta_to_ch_map[i]];
                ctx.psi_solution[i] = ch_solution[ctx.psi_to_ch_map[i]];
            }
            ctx.theta_constraints.distribute(ctx.theta_solution);
            ctx.psi_constraints.distribute(ctx.psi_solution);
        }

        auto solve_end = std::chrono::high_resolution_clock::now();
        total_solve_time += std::chrono::duration<double>(solve_end - solve_start).count();
    }

    // ========================================================================
    // Compute errors
    // ========================================================================
    CHMMSErrors errors = compute_ch_mms_errors<dim>(
        ctx.theta_dof_handler, ctx.psi_dof_handler,
        ctx.theta_solution, ctx.psi_solution,
        current_time);

    auto total_end = std::chrono::high_resolution_clock::now();

    // Fill result
    result.h = ctx.get_min_h();
    result.n_dofs = ctx.n_ch_dofs();
    result.theta_L2 = errors.theta_L2;
    result.theta_H1 = errors.theta_H1;
    result.psi_L2 = errors.psi_L2;
    result.setup_time = total_setup_time;
    result.assembly_time = total_assembly_time;
    result.solve_time = total_solve_time;
    result.total_time = std::chrono::duration<double>(total_end - total_start).count();
    result.solver_iterations = total_iterations;
    result.solver_residual = last_residual;

    return result;
}

CHMMSResult run_ch_mms_single(
    unsigned int refinement,
    const Parameters& params,
    CHSolverType solver_type,
    unsigned int n_time_steps)
{
    return run_ch_mms_single_impl<2>(refinement, params, solver_type, n_time_steps);
}

// ============================================================================
// run_ch_mms_standalone - Full convergence study
// ============================================================================

CHMMSConvergenceResult run_ch_mms_standalone(
    const std::vector<unsigned int>& refinements,
    const Parameters& params,
    CHSolverType solver_type,
    unsigned int n_time_steps)
{
    CHMMSConvergenceResult result;
    result.fe_degree = params.fe.degree_phase;
    result.n_time_steps = n_time_steps;
    result.expected_L2_rate = params.fe.degree_phase + 1;
    result.expected_H1_rate = params.fe.degree_phase;

    const double t_init = 0.1;
    const double t_final = 0.2;
    result.dt = (t_final - t_init) / n_time_steps;

    std::cout << "\n[CH_STANDALONE] Running convergence study...\n";
    std::cout << "  t ∈ [" << t_init << ", " << t_final << "], dt = " << result.dt << "\n";
    std::cout << "  ε = " << params.physics.epsilon
              << ", γ = " << params.physics.mobility << "\n";
    std::cout << "  FE degree = Q" << params.fe.degree_phase << "\n";
    std::cout << "  Solver = " << (solver_type == CHSolverType::Direct ? "Direct" : "GMRES+ILU") << "\n";
    std::cout << "  Using MMSContext with PRODUCTION: ch_setup + ch_assembler + ch_solver\n";

    for (unsigned int ref : refinements)
    {
        std::cout << "  Refinement " << ref << "... " << std::flush;

        CHMMSResult single = run_ch_mms_single(ref, params, solver_type, n_time_steps);
        result.results.push_back(single);

        std::cout << "θ_L2=" << std::scientific << std::setprecision(2) << single.theta_L2
                  << ", θ_H1=" << single.theta_H1
                  << ", time=" << std::fixed << std::setprecision(1) << single.total_time << "s\n";
    }

    result.compute_rates();
    return result;
}

// ============================================================================
// compare_ch_solvers - Compare direct vs iterative
// ============================================================================

void compare_ch_solvers(
    unsigned int refinement,
    const Parameters& params,
    unsigned int n_time_steps)
{
    std::cout << "\n[CH Solver Comparison] Refinement " << refinement << "\n";
    std::cout << std::string(60, '=') << "\n";

    // Direct solver
    std::cout << "Direct (UMFPACK):\n";
    CHMMSResult direct = run_ch_mms_single(refinement, params, CHSolverType::Direct, n_time_steps);
    std::cout << "  θ_L2 = " << std::scientific << direct.theta_L2
              << ", time = " << std::fixed << std::setprecision(3) << direct.total_time << "s\n";

    // Iterative solver
    std::cout << "Iterative (GMRES+ILU):\n";
    CHMMSResult iterative = run_ch_mms_single(refinement, params, CHSolverType::GMRES_ILU, n_time_steps);
    std::cout << "  θ_L2 = " << std::scientific << iterative.theta_L2
              << ", iters = " << iterative.solver_iterations
              << ", time = " << std::fixed << std::setprecision(3) << iterative.total_time << "s\n";

    std::cout << "\nSpeedup (direct/iterative): "
              << std::setprecision(2) << direct.total_time / iterative.total_time << "x\n";
}