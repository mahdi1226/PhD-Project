// ============================================================================
// mms/magnetization/magnetization_mms_test.cc - Magnetization MMS Test (REFACTORED)
//
// Uses MMSContext for setup, which calls PRODUCTION code:
//   - setup/magnetization_setup.h: setup_magnetization_sparsity()
//   - assembly/magnetization_assembler.h: MagnetizationAssembler::assemble()
//   - solvers/magnetization_solver.h: MagnetizationSolver::solve()
//
// Reference: Nochetto, Salgado & Tomas, CMAME 309 (2016) 497-531
// ============================================================================

#include "mms/magnetization/magnetization_mms_test.h"
#include "mms/magnetization/magnetization_mms.h"
#include "mms/mms_context.h"

// Production assembler and solver
#include "assembly/magnetization_assembler.h"
#include "solvers/magnetization_solver.h"

#include <deal.II/numerics/vector_tools.h>

#include <iostream>
#include <iomanip>
#include <fstream>
#include <chrono>
#include <cmath>

constexpr int dim = 2;

// ============================================================================
// Helper
// ============================================================================

std::string to_string(MagSolverType type)
{
    switch (type)
    {
        case MagSolverType::Direct: return "Direct";
        case MagSolverType::GMRES:  return "GMRES";
        default: return "Unknown";
    }
}

// ============================================================================
// MagMMSConvergenceResult implementation
// ============================================================================

void MagMMSConvergenceResult::compute_rates()
{
    M_L2_rates.clear();
    for (size_t i = 1; i < results.size(); ++i)
    {
        const double e_fine = results[i].M_L2;
        const double e_coarse = results[i-1].M_L2;
        const double h_fine = results[i].h;
        const double h_coarse = results[i-1].h;

        if (e_coarse > 1e-15 && e_fine > 1e-15)
            M_L2_rates.push_back(std::log(e_coarse / e_fine) / std::log(h_coarse / h_fine));
        else
            M_L2_rates.push_back(0.0);
    }
}

bool MagMMSConvergenceResult::passes(double tolerance) const
{
    if (M_L2_rates.empty())
        return false;
    return M_L2_rates.back() >= expected_L2_rate - tolerance;
}

void MagMMSConvergenceResult::print() const
{
    std::cout << "\n========================================\n";
    std::cout << "Magnetization MMS Convergence Results\n";
    std::cout << "========================================\n";
    std::cout << "Solver: " << to_string(solver_type) << "\n";
    std::cout << "FE degree: DG" << fe_degree << "\n";
    std::cout << "Expected L2 rate: " << expected_L2_rate << "\n\n";

    std::cout << std::left
              << std::setw(6) << "Ref"
              << std::setw(12) << "h"
              << std::setw(12) << "M_L2"
              << std::setw(8) << "rate"
              << std::setw(12) << "Mx_L2"
              << std::setw(12) << "My_L2"
              << std::setw(10) << "time(s)"
              << "\n";
    std::cout << std::string(72, '-') << "\n";

    for (size_t i = 0; i < results.size(); ++i)
    {
        const auto& r = results[i];
        std::cout << std::left << std::setw(6) << r.refinement
                  << std::scientific << std::setprecision(2)
                  << std::setw(12) << r.h
                  << std::setw(12) << r.M_L2
                  << std::fixed << std::setprecision(2)
                  << std::setw(8) << (i > 0 ? M_L2_rates[i-1] : 0.0)
                  << std::scientific << std::setprecision(2)
                  << std::setw(12) << r.Mx_L2
                  << std::setw(12) << r.My_L2
                  << std::fixed << std::setprecision(2)
                  << std::setw(10) << r.total_time
                  << "\n";
    }

    std::cout << "========================================\n";
    if (passes())
        std::cout << "[PASS] Convergence rate within tolerance!\n";
    else
        std::cout << "[FAIL] Rate below expected!\n";
}

void MagMMSConvergenceResult::write_csv(const std::string& filename) const
{
    std::ofstream file(filename);
    if (!file.is_open())
    {
        std::cerr << "[MAG MMS] Failed to open " << filename << "\n";
        return;
    }

    file << "refinement,h,n_dofs,M_L2,M_L2_rate,Mx_L2,My_L2,total_time\n";

    for (size_t i = 0; i < results.size(); ++i)
    {
        const auto& r = results[i];
        file << r.refinement << ","
             << std::scientific << std::setprecision(6) << r.h << ","
             << r.n_dofs << ","
             << r.M_L2 << ","
             << (i > 0 ? M_L2_rates[i-1] : 0.0) << ","
             << r.Mx_L2 << ","
             << r.My_L2 << ","
             << std::fixed << std::setprecision(4) << r.total_time << "\n";
    }

    file.close();
    std::cout << "[MAG MMS] Results written to " << filename << "\n";
}

// ============================================================================
// run_magnetization_mms_single - Using MMSContext
// ============================================================================

MagMMSResult run_magnetization_mms_single(
    unsigned int refinement,
    const Parameters& params,
    MagSolverType solver_type)
{
    MagMMSResult result;
    result.refinement = refinement;
    result.solver_type = solver_type;

    // Time parameters
    const double t_start = 0.1;
    const double t_end = 0.2;
    const double L_y = params.domain.y_max - params.domain.y_min;

    // Make mutable params
    Parameters mms_params = params;
    mms_params.enable_mms = true;
    mms_params.physics.tau_M = 1.0;  // Override for MMS test


    auto total_start = std::chrono::high_resolution_clock::now();

    // ========================================================================
    // Setup using MMSContext - USES PRODUCTION CODE
    // ========================================================================
    MMSContext<dim> ctx;
    ctx.setup_mesh(mms_params, refinement);
    ctx.setup_magnetization(mms_params);

    // Also need velocity and phi DoF handlers for assembler interface
    ctx.setup_ns(mms_params, t_start);
    ctx.setup_poisson(mms_params);
    ctx.setup_ch(mms_params, t_start);

    result.h = ctx.get_min_h();
    result.n_dofs = 2 * ctx.mx_dof_handler.n_dofs();  // Mx + My

    const double dt = (t_end - t_start) / 100;  // 100 steps
    const unsigned int n_steps = 100;

    // Dummy fields (U=0, φ=0, θ=1)
    ctx.ux_solution = 0.0;
    ctx.uy_solution = 0.0;
    ctx.phi_solution = 0.0;
    ctx.theta_solution = 1.0;

    // Initialize with exact solution at t_start
    MagExactMx<dim> exact_Mx(t_start, L_y);
    MagExactMy<dim> exact_My(t_start, L_y);
    dealii::VectorTools::interpolate(ctx.mx_dof_handler, exact_Mx, ctx.mx_solution);
    dealii::VectorTools::interpolate(ctx.mx_dof_handler, exact_My, ctx.my_solution);

    dealii::Vector<double> mx_old = ctx.mx_solution;
    dealii::Vector<double> my_old = ctx.my_solution;

    // ========================================================================
    // PRODUCTION ASSEMBLER
    // ========================================================================
    MagnetizationAssembler<dim> assembler(
        mms_params, ctx.mx_dof_handler, ctx.ux_dof_handler,
        ctx.phi_dof_handler, ctx.theta_dof_handler);

    // ========================================================================
    // PRODUCTION SOLVER
    // ========================================================================
    LinearSolverParams solver_params;
    solver_params.use_iterative = (solver_type == MagSolverType::GMRES);
    MagnetizationSolver<dim> solver(solver_params);

    // Allocate local system (assembler writes to these)
    const unsigned int n_M = ctx.mx_dof_handler.n_dofs();
    dealii::SparseMatrix<double> M_matrix(ctx.mx_sparsity);
    dealii::Vector<double> rhs_x(n_M), rhs_y(n_M);

    // ========================================================================
    // Time stepping
    // ========================================================================
    double current_time = t_start;
    double total_assembly_time = 0.0;
    double total_solve_time = 0.0;

    for (unsigned int step = 0; step < n_steps; ++step)
    {
        current_time += dt;
        mx_old = ctx.mx_solution;
        my_old = ctx.my_solution;

        // Assembly
        auto asm_start = std::chrono::high_resolution_clock::now();

        assembler.assemble(
            M_matrix, rhs_x, rhs_y,
            ctx.ux_solution, ctx.uy_solution, ctx.phi_solution, ctx.theta_solution,
            mx_old, my_old,
            dt, current_time);

        auto asm_end = std::chrono::high_resolution_clock::now();
        total_assembly_time += std::chrono::duration<double>(asm_end - asm_start).count();

        // Solve
        auto solve_start = std::chrono::high_resolution_clock::now();

        solver.initialize(M_matrix);
        solver.solve(ctx.mx_solution, rhs_x);
        solver.solve(ctx.my_solution, rhs_y);

        auto solve_end = std::chrono::high_resolution_clock::now();
        total_solve_time += std::chrono::duration<double>(solve_end - solve_start).count();
    }

    result.assembly_time = total_assembly_time;
    result.solve_time = total_solve_time;

    // ========================================================================
    // Compute errors
    // ========================================================================
    MagMMSError errors = compute_mag_mms_error(
        ctx.mx_dof_handler, ctx.mx_solution, ctx.my_solution, current_time, L_y);

    result.Mx_L2 = errors.Mx_L2;
    result.My_L2 = errors.My_L2;
    result.M_L2 = errors.M_L2;

    auto total_end = std::chrono::high_resolution_clock::now();
    result.total_time = std::chrono::duration<double>(total_end - total_start).count();

    return result;
}

// ============================================================================
// run_magnetization_mms_standalone - Full convergence study
// ============================================================================

MagMMSConvergenceResult run_magnetization_mms_standalone(
    const std::vector<unsigned int>& refinements,
    const Parameters& params,
    MagSolverType solver_type)
{
    MagMMSConvergenceResult result;
    result.fe_degree = params.fe.degree_magnetization;
    result.solver_type = solver_type;
    result.standalone = true;
    result.expected_L2_rate = params.fe.degree_magnetization + 1;  // DG optimal

    std::cout << "\n[MAGNETIZATION_STANDALONE] Running convergence study...\n";
    std::cout << "  τ_M = " << (params.physics.tau_M > 0 ? params.physics.tau_M : 1.0) << "\n";
    std::cout << "  FE degree = DG" << params.fe.degree_magnetization << "\n";
    std::cout << "  Solver = " << to_string(solver_type) << "\n";
    std::cout << "  Using MMSContext with PRODUCTION code\n\n";

    for (unsigned int ref : refinements)
    {
        std::cout << "  Refinement " << ref << "... " << std::flush;

        MagMMSResult r = run_magnetization_mms_single(ref, params, solver_type);
        result.results.push_back(r);

        std::cout << "M_L2=" << std::scientific << std::setprecision(2) << r.M_L2
                  << ", time=" << std::fixed << std::setprecision(1) << r.total_time << "s\n";
    }

    result.compute_rates();
    return result;
}

// ============================================================================
// compare_magnetization_solvers
// ============================================================================

void compare_magnetization_solvers(
    unsigned int refinement,
    const Parameters& params)
{
    std::cout << "\n[MAG SOLVER COMPARISON] Refinement " << refinement << "\n";
    std::cout << std::string(50, '=') << "\n";

    std::cout << "Running Direct... " << std::flush;
    MagMMSResult direct = run_magnetization_mms_single(refinement, params, MagSolverType::Direct);
    std::cout << "Done.\n";

    std::cout << "Running GMRES... " << std::flush;
    MagMMSResult gmres = run_magnetization_mms_single(refinement, params, MagSolverType::GMRES);
    std::cout << "Done.\n";

    std::cout << "\nResults:\n";
    std::cout << std::left
              << std::setw(12) << "Solver"
              << std::setw(12) << "M_L2"
              << std::setw(12) << "Time(s)"
              << "\n";
    std::cout << std::string(36, '-') << "\n";

    std::cout << std::setw(12) << "Direct"
              << std::scientific << std::setprecision(3) << std::setw(12) << direct.M_L2
              << std::fixed << std::setprecision(3) << std::setw(12) << direct.total_time << "\n";

    std::cout << std::setw(12) << "GMRES"
              << std::scientific << std::setprecision(3) << std::setw(12) << gmres.M_L2
              << std::fixed << std::setprecision(3) << std::setw(12) << gmres.total_time << "\n";
}