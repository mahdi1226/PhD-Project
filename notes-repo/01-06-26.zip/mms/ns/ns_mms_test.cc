// ============================================================================
// mms/ns/ns_mms_test.cc - NS MMS Test (REFACTORED - Production Code Path)
//
// This test validates the PRODUCTION NS assembler (ns_assembler.cc) by:
//   1. Using setup_ns_coupled_system() from setup/ns_setup.h
//   2. Using assemble_ns_system() from assembly/ns_assembler.h
//   3. Using solve_ns_system_*() from solvers/ns_solver.h
//   4. Using BlockSchurPreconditioner from solvers/ns_block_preconditioner.h
//
// Reference: Nochetto, Salgado & Tomas, CMAME 309 (2016) 497-531
// ============================================================================

#include "mms/ns/ns_mms_test.h"
#include "mms/ns/ns_mms.h"

// PRODUCTION code - the actual files being tested
#include "setup/ns_setup.h"
#include "assembly/ns_assembler.h"
#include "solvers/ns_solver.h"
#include "solvers/ns_block_preconditioner.h"

#include <deal.II/grid/tria.h>
#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/grid_tools.h>
#include <deal.II/dofs/dof_handler.h>
#include <deal.II/dofs/dof_tools.h>
#include <deal.II/fe/fe_q.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/lac/vector.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/sparse_direct.h>
#include <deal.II/lac/affine_constraints.h>
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/base/quadrature_lib.h>

#include <iostream>
#include <iomanip>
#include <chrono>
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

using namespace dealii;

constexpr int dim = 2;

// ============================================================================
// NSMMSConvergenceResult implementation
// ============================================================================

void NSMMSConvergenceResult::compute_rates()
{
    const size_t n = results.size();

    ux_L2_rate.resize(n, 0.0);
    ux_H1_rate.resize(n, 0.0);
    uy_L2_rate.resize(n, 0.0);
    uy_H1_rate.resize(n, 0.0);
    p_L2_rate.resize(n, 0.0);

    for (size_t i = 1; i < n; ++i)
    {
        const double h_ratio = results[i-1].h / results[i].h;
        const double log_h = std::log(h_ratio);

        if (results[i-1].ux_L2 > 1e-15 && results[i].ux_L2 > 1e-15)
            ux_L2_rate[i] = std::log(results[i-1].ux_L2 / results[i].ux_L2) / log_h;
        if (results[i-1].ux_H1 > 1e-15 && results[i].ux_H1 > 1e-15)
            ux_H1_rate[i] = std::log(results[i-1].ux_H1 / results[i].ux_H1) / log_h;
        if (results[i-1].uy_L2 > 1e-15 && results[i].uy_L2 > 1e-15)
            uy_L2_rate[i] = std::log(results[i-1].uy_L2 / results[i].uy_L2) / log_h;
        if (results[i-1].uy_H1 > 1e-15 && results[i].uy_H1 > 1e-15)
            uy_H1_rate[i] = std::log(results[i-1].uy_H1 / results[i].uy_H1) / log_h;
        if (results[i-1].p_L2 > 1e-15 && results[i].p_L2 > 1e-15)
            p_L2_rate[i] = std::log(results[i-1].p_L2 / results[i].p_L2) / log_h;
    }
}

void NSMMSConvergenceResult::print() const
{
    std::cout << "\n========================================\n";
    std::cout << "MMS Convergence Results: NS_STANDALONE\n";
    std::cout << "========================================\n";
    std::cout << std::left
              << std::setw(6) << "Ref"
              << std::setw(12) << "h"
              << std::setw(12) << "ux_L2" << std::setw(8) << "rate"
              << std::setw(12) << "ux_H1" << std::setw(8) << "rate"
              << std::setw(12) << "p_L2" << std::setw(8) << "rate"
              << std::setw(12) << "div_U"
              << "\n";
    std::cout << std::string(100, '-') << "\n";

    for (size_t i = 0; i < results.size(); ++i)
    {
        std::cout << std::left << std::setw(6) << results[i].refinement
                  << std::scientific << std::setprecision(2)
                  << std::setw(12) << results[i].h
                  << std::setw(12) << results[i].ux_L2
                  << std::fixed << std::setprecision(2)
                  << std::setw(8) << ux_L2_rate[i]
                  << std::scientific << std::setprecision(2)
                  << std::setw(12) << results[i].ux_H1
                  << std::fixed << std::setprecision(2)
                  << std::setw(8) << ux_H1_rate[i]
                  << std::scientific << std::setprecision(2)
                  << std::setw(12) << results[i].p_L2
                  << std::fixed << std::setprecision(2)
                  << std::setw(8) << p_L2_rate[i]
                  << std::scientific << std::setprecision(2)
                  << std::setw(12) << results[i].div_U_L2
                  << "\n";
    }
    std::cout << "========================================\n";

    if (passes())
        std::cout << "[PASS] All convergence rates within tolerance!\n";
    else
        std::cout << "[FAIL] Some rates below expected!\n";
}

bool NSMMSConvergenceResult::passes(double tol) const
{
    if (results.size() < 2)
        return false;

    const size_t last = results.size() - 1;

    // For unsteady with first-order time stepping, spatial rate limited by O(dt)
    const double min_vel_L2 = std::min(expected_vel_L2_rate, 2.0) - tol;
    const double min_vel_H1 = expected_vel_H1_rate - tol;
    const double min_p_L2 = expected_p_L2_rate - tol;

    bool pass = true;

    if (ux_L2_rate[last] < min_vel_L2)
    {
        std::cout << "[FAIL] ux_L2 rate = " << ux_L2_rate[last]
                  << " < " << min_vel_L2 << "\n";
        pass = false;
    }
    if (ux_H1_rate[last] < min_vel_H1)
    {
        std::cout << "[FAIL] ux_H1 rate = " << ux_H1_rate[last]
                  << " < " << min_vel_H1 << "\n";
        pass = false;
    }
    if (p_L2_rate[last] < min_p_L2)
    {
        std::cout << "[FAIL] p_L2 rate = " << p_L2_rate[last]
                  << " < " << min_p_L2 << "\n";
        pass = false;
    }

    return pass;
}

// ============================================================================
// Main test function - CLEAN PRODUCTION CODE PATH
// ============================================================================

NSMMSConvergenceResult run_ns_mms_standalone(
    const std::vector<unsigned int>& refinements,
    const Parameters& params,
    NSSolverType solver_type,
    unsigned int n_time_steps)
{
    NSMMSConvergenceResult result;
    result.fe_degree_velocity = params.fe.degree_velocity;
    result.fe_degree_pressure = params.fe.degree_pressure;
    result.n_time_steps = n_time_steps;
    result.L_y = params.domain.y_max - params.domain.y_min;

    // Expected rates for Q2-Q1 Taylor-Hood
    result.expected_vel_L2_rate = params.fe.degree_velocity + 1;  // 3 for Q2
    result.expected_vel_H1_rate = params.fe.degree_velocity;      // 2 for Q2
    result.expected_p_L2_rate = params.fe.degree_pressure + 1;    // 2 for Q1

    // Time integration
    const double t_init = 0.1;
    const double t_final = 0.2;
    const double dt = (t_final - t_init) / n_time_steps;
    result.dt = dt;

    // Create mutable params for MMS
    Parameters mms_params = params;
    mms_params.enable_mms = true;
    mms_params.time.dt = dt;

    // Constant viscosity for standalone NS test
    mms_params.physics.nu_water = 1.0;
    mms_params.physics.nu_ferro = 1.0;
    result.nu = 1.0;

    const double L_y = result.L_y;

    std::cout << "\n[NS_STANDALONE] Running convergence study...\n";
    std::cout << "  t in [" << t_init << ", " << t_final << "], dt = " << dt << "\n";
    std::cout << "  nu = " << result.nu << ", L_y = " << L_y << "\n";
    std::cout << "  FE degree: Q" << params.fe.degree_velocity << "-Q"
              << params.fe.degree_pressure << " (Taylor-Hood)\n";
    std::cout << "  Solver = " << to_string(solver_type) << "\n";
    std::cout << "  Using PRODUCTION code path\n\n";

    for (unsigned int ref : refinements)
    {
        std::cout << "  Refinement " << ref << "... " << std::flush;
        auto total_start = std::chrono::high_resolution_clock::now();

        NSMMSResult res;
        res.refinement = ref;

        // ====================================================================
        // STEP 1: Create mesh (same as PhaseFieldProblem::setup_mesh)
        // ====================================================================
        Triangulation<dim> triangulation;

        Point<dim> p1(mms_params.domain.x_min, mms_params.domain.y_min);
        Point<dim> p2(mms_params.domain.x_max, mms_params.domain.y_max);

        std::vector<unsigned int> subdivisions(dim);
        subdivisions[0] = mms_params.domain.initial_cells_x;
        subdivisions[1] = mms_params.domain.initial_cells_y;

        GridGenerator::subdivided_hyper_rectangle(triangulation, subdivisions, p1, p2);

        // Assign boundary IDs: 0=bottom, 1=right, 2=top, 3=left
        for (auto& face : triangulation.active_face_iterators())
        {
            if (!face->at_boundary())
                continue;

            const auto center = face->center();
            const double tol = 1e-10;

            if (std::abs(center[1] - mms_params.domain.y_min) < tol)
                face->set_boundary_id(0);
            else if (std::abs(center[0] - mms_params.domain.x_max) < tol)
                face->set_boundary_id(1);
            else if (std::abs(center[1] - mms_params.domain.y_max) < tol)
                face->set_boundary_id(2);
            else if (std::abs(center[0] - mms_params.domain.x_min) < tol)
                face->set_boundary_id(3);
        }

        triangulation.refine_global(ref);
        res.h = GridTools::minimal_cell_diameter(triangulation);

        // ====================================================================
        // STEP 2: Create FE and DoF handlers
        // ====================================================================
        FE_Q<dim> fe_Q2(mms_params.fe.degree_velocity);
        FE_Q<dim> fe_Q1(mms_params.fe.degree_pressure);

        DoFHandler<dim> ux_dof_handler(triangulation);
        DoFHandler<dim> uy_dof_handler(triangulation);
        DoFHandler<dim> p_dof_handler(triangulation);

        ux_dof_handler.distribute_dofs(fe_Q2);
        uy_dof_handler.distribute_dofs(fe_Q2);
        p_dof_handler.distribute_dofs(fe_Q1);

        // Also need theta/psi DoF handlers for assembler interface
        DoFHandler<dim> theta_dof_handler(triangulation);
        DoFHandler<dim> psi_dof_handler(triangulation);
        theta_dof_handler.distribute_dofs(fe_Q2);
        psi_dof_handler.distribute_dofs(fe_Q2);

        const unsigned int n_ux = ux_dof_handler.n_dofs();
        const unsigned int n_uy = uy_dof_handler.n_dofs();
        const unsigned int n_p = p_dof_handler.n_dofs();
        res.n_dofs = n_ux + n_uy + n_p;

        // ====================================================================
        // STEP 3: Setup constraints (PRODUCTION STYLE)
        // ====================================================================
        AffineConstraints<double> ux_constraints, uy_constraints, p_constraints;

        ux_constraints.clear();
        uy_constraints.clear();
        p_constraints.clear();

        DoFTools::make_hanging_node_constraints(ux_dof_handler, ux_constraints);
        DoFTools::make_hanging_node_constraints(uy_dof_handler, uy_constraints);
        DoFTools::make_hanging_node_constraints(p_dof_handler, p_constraints);

        // No-slip BCs on ALL 4 boundaries (exact solution is zero there)
        for (unsigned int bid = 0; bid <= 3; ++bid)
        {
            VectorTools::interpolate_boundary_values(
                ux_dof_handler, bid,
                Functions::ZeroFunction<dim>(), ux_constraints);
            VectorTools::interpolate_boundary_values(
                uy_dof_handler, bid,
                Functions::ZeroFunction<dim>(), uy_constraints);
        }

        // Pin pressure DoF 0 to fix the constant
        if (!p_constraints.is_constrained(0))
        {
            p_constraints.add_line(0);
            p_constraints.set_inhomogeneity(0, 0.0);
        }

        ux_constraints.close();
        uy_constraints.close();
        p_constraints.close();

        // ====================================================================
        // STEP 4: PRODUCTION setup - setup_ns_coupled_system()
        // ====================================================================
        std::vector<types::global_dof_index> ux_to_ns_map, uy_to_ns_map, p_to_ns_map;
        AffineConstraints<double> ns_constraints;
        SparsityPattern ns_sparsity;

        setup_ns_coupled_system<dim>(
            ux_dof_handler, uy_dof_handler, p_dof_handler,
            ux_constraints, uy_constraints, p_constraints,
            ux_to_ns_map, uy_to_ns_map, p_to_ns_map,
            ns_constraints, ns_sparsity, false);

        // ====================================================================
        // STEP 4b: Setup pressure mass matrix (needed for Schur preconditioner)
        // Uses PRODUCTION function: assemble_pressure_mass_matrix()
        // ====================================================================
        SparsityPattern p_mass_sparsity;
        SparseMatrix<double> pressure_mass_matrix;

        if (solver_type == NSSolverType::Schur)
        {
            // PRODUCTION function creates sparsity AND assembles matrix
            assemble_pressure_mass_matrix<dim>(
                p_dof_handler,
                p_constraints,
                p_mass_sparsity,
                pressure_mass_matrix);
        }

        // ====================================================================
        // STEP 5: Allocate system
        // ====================================================================
        SparseMatrix<double> ns_matrix(ns_sparsity);
        Vector<double> ns_rhs(n_ux + n_uy + n_p);
        Vector<double> ns_solution(n_ux + n_uy + n_p);

        Vector<double> ux_solution(n_ux), uy_solution(n_uy), p_solution(n_p);
        Vector<double> ux_old(n_ux), uy_old(n_uy);

        // Dummy theta/psi for assembler (set to zero - no coupling)
        Vector<double> theta_solution(theta_dof_handler.n_dofs());
        Vector<double> psi_solution(psi_dof_handler.n_dofs());
        theta_solution = 0.0;
        psi_solution = 0.0;

        // ====================================================================
        // STEP 5b: Schur preconditioner (created after first matrix assembly)
        // ====================================================================
        std::unique_ptr<BlockSchurPreconditioner> schur_preconditioner;

        // ====================================================================
        // STEP 6: Initialize with exact solution at t_init
        // ====================================================================
        NSExactVelocityX<dim> exact_ux_init(t_init, L_y);
        NSExactVelocityY<dim> exact_uy_init(t_init, L_y);

        VectorTools::interpolate(ux_dof_handler, exact_ux_init, ux_old);
        VectorTools::interpolate(uy_dof_handler, exact_uy_init, uy_old);

        // ====================================================================
        // STEP 7: Time stepping loop
        // ====================================================================
        double current_time = t_init;
        double total_assembly_time = 0.0;
        double total_solve_time = 0.0;
        unsigned int total_iterations = 0;

        for (unsigned int step = 0; step < n_time_steps; ++step)
        {
            current_time += dt;

            // ----------------------------------------------------------------
            // PRODUCTION ASSEMBLY - assemble_ns_system()
            // ----------------------------------------------------------------
            auto assembly_start = std::chrono::high_resolution_clock::now();

            ns_matrix = 0;
            ns_rhs = 0;

            // Call PRODUCTION assembler with nullptr for magnetic fields
            assemble_ns_system<dim>(
                ux_dof_handler, uy_dof_handler, p_dof_handler,
                theta_dof_handler, psi_dof_handler,
                nullptr, nullptr,  // No phi, M DoF handlers
                ux_old, uy_old,
                theta_solution, psi_solution,
                nullptr, nullptr, nullptr,  // No phi, mx, my
                mms_params,
                dt, current_time,
                ux_to_ns_map, uy_to_ns_map, p_to_ns_map,
                ns_constraints,
                ns_matrix, ns_rhs);

            auto assembly_end = std::chrono::high_resolution_clock::now();
            total_assembly_time += std::chrono::duration<double>(
                assembly_end - assembly_start).count();

            // ----------------------------------------------------------------
            // PRODUCTION SOLVE
            // ----------------------------------------------------------------
            auto solve_start = std::chrono::high_resolution_clock::now();

            ns_solution = 0;
            SolverInfo info;

            switch (solver_type)
            {
                case NSSolverType::Direct:
                    // PRODUCTION direct solver
                    info = solve_ns_system_direct(
                        ns_matrix, ns_rhs, ns_solution, ns_constraints, false);
                    break;

                case NSSolverType::GMRES_ILU:
                    // PRODUCTION GMRES+ILU solver
                    info = solve_ns_system(
                        ns_matrix, ns_rhs, ns_solution, ns_constraints,
                        2000, 1e-8, false);
                    break;

                case NSSolverType::Schur:
                    // PRODUCTION Schur solver with BlockSchurPreconditioner
                    if (!schur_preconditioner)
                    {
                        // First time: create preconditioner
                        schur_preconditioner = std::make_unique<BlockSchurPreconditioner>(
                            ns_matrix,
                            pressure_mass_matrix,
                            ux_to_ns_map,
                            uy_to_ns_map,
                            p_to_ns_map,
                            true);  // do_solve_A = true (matches production)
                    }
                    else
                    {
                        // Subsequent times: update with new matrix values
                        schur_preconditioner->update(ns_matrix, pressure_mass_matrix);
                    }

                    // PRODUCTION Schur solver
                    info = solve_ns_system_schur(
                        ns_matrix,
                        ns_rhs,
                        ns_solution,
                        ns_constraints,
                        *schur_preconditioner,
                        mms_params.solvers.ns.max_iterations,
                        mms_params.solvers.ns.rel_tolerance,
                        false);  // not verbose
                    break;
            }

            // Distribute constraints on coupled solution
            ns_constraints.distribute(ns_solution);

            auto solve_end = std::chrono::high_resolution_clock::now();
            total_solve_time += std::chrono::duration<double>(
                solve_end - solve_start).count();
            total_iterations += info.iterations;

            // ----------------------------------------------------------------
            // Extract solutions (NO double distribute!)
            // ----------------------------------------------------------------
            for (unsigned int i = 0; i < n_ux; ++i)
                ux_solution[i] = ns_solution[ux_to_ns_map[i]];
            for (unsigned int i = 0; i < n_uy; ++i)
                uy_solution[i] = ns_solution[uy_to_ns_map[i]];
            for (unsigned int i = 0; i < n_p; ++i)
                p_solution[i] = ns_solution[p_to_ns_map[i]];

            // Update old for next step
            ux_old = ux_solution;
            uy_old = uy_solution;
        }

        res.assembly_time = total_assembly_time;
        res.solve_time = total_solve_time;
        res.solver_iterations = total_iterations;

        // ====================================================================
        // STEP 8: Compute errors at final time
        // ====================================================================
        NSMMSError errors = compute_ns_mms_error(
            ux_dof_handler, uy_dof_handler, p_dof_handler,
            ux_solution, uy_solution, p_solution,
            current_time, L_y);

        res.ux_L2 = errors.ux_L2;
        res.ux_H1 = errors.ux_H1;
        res.uy_L2 = errors.uy_L2;
        res.uy_H1 = errors.uy_H1;
        res.p_L2 = errors.p_L2;
        res.div_U_L2 = errors.div_U_L2;

        auto total_end = std::chrono::high_resolution_clock::now();
        res.total_time = std::chrono::duration<double>(total_end - total_start).count();

        result.results.push_back(res);

        std::cout << "ux_L2=" << std::scientific << std::setprecision(2) << res.ux_L2
                  << ", p_L2=" << res.p_L2
                  << ", div=" << res.div_U_L2
                  << ", iters=" << res.solver_iterations
                  << ", time=" << std::fixed << std::setprecision(1) << res.total_time << "s\n";
    }

    result.compute_rates();
    return result;
}

// to_string is already defined in ns_mms_test.h