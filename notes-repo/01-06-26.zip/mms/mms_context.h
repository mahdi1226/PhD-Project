// ============================================================================
// mms/mms_context.h - MMS Test Context
//
// Provides a unified context for MMS verification tests that uses
// PRODUCTION setup code from core/phase_field_setup.cc and setup/*.h.
//
// This ensures MMS tests validate the actual code paths used in production,
// not duplicated inline implementations that could diverge.
//
// Usage:
//   MMSContext<2> ctx;
//   ctx.setup_mesh(params, refinement);
//   ctx.setup_ch(params, mms_time);
//   ctx.apply_ch_initial_conditions(params, t_init);
//   // ... use ctx.theta_dof_handler, ctx.ch_matrix, etc.
//
// ============================================================================
#ifndef MMS_CONTEXT_H
#define MMS_CONTEXT_H

#include "utilities/parameters.h"

#include <deal.II/grid/tria.h>
#include <deal.II/dofs/dof_handler.h>
#include <deal.II/fe/fe_q.h>
#include <deal.II/fe/fe_dgq.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/sparsity_pattern.h>
#include <deal.II/lac/vector.h>
#include <deal.II/lac/affine_constraints.h>

#include <memory>
#include <vector>

/**
 * @brief Unified data structure for MMS verification tests
 *
 * Holds all mesh, DoF handlers, constraints, matrices, and solution vectors
 * needed for MMS convergence studies. Setup methods call PRODUCTION code
 * from setup/ch_setup.h, setup/ns_setup.h, etc.
 *
 * @tparam dim Spatial dimension (typically 2)
 */
template <int dim>
struct MMSContext
{
    // ========================================================================
    // Mesh
    // ========================================================================
    dealii::Triangulation<dim> triangulation;

    // ========================================================================
    // Finite Elements (created on demand by setup methods)
    // ========================================================================
    std::unique_ptr<dealii::FE_Q<dim>> fe_phase;      ///< Q1/Q2 for θ, ψ
    std::unique_ptr<dealii::FE_Q<dim>> fe_velocity;   ///< Q2 for ux, uy
    std::unique_ptr<dealii::FE_Q<dim>> fe_pressure;   ///< Q1 for p
    std::unique_ptr<dealii::FE_Q<dim>> fe_potential;  ///< Q1/Q2 for φ
    std::unique_ptr<dealii::FE_DGQ<dim>> fe_mag;      ///< DG0/DG1 for Mx, My

    // ========================================================================
    // Cahn-Hilliard System (θ, ψ)
    // ========================================================================
    dealii::DoFHandler<dim> theta_dof_handler;
    dealii::DoFHandler<dim> psi_dof_handler;

    dealii::AffineConstraints<double> theta_constraints;
    dealii::AffineConstraints<double> psi_constraints;
    dealii::AffineConstraints<double> ch_constraints;  ///< Combined for coupled solve

    std::vector<dealii::types::global_dof_index> theta_to_ch_map;
    std::vector<dealii::types::global_dof_index> psi_to_ch_map;

    dealii::SparsityPattern ch_sparsity;
    dealii::SparseMatrix<double> ch_matrix;
    dealii::Vector<double> ch_rhs;

    dealii::Vector<double> theta_solution;
    dealii::Vector<double> theta_old;
    dealii::Vector<double> psi_solution;

    // ========================================================================
    // Navier-Stokes System (ux, uy, p)
    // ========================================================================
    dealii::DoFHandler<dim> ux_dof_handler;
    dealii::DoFHandler<dim> uy_dof_handler;
    dealii::DoFHandler<dim> p_dof_handler;

    dealii::AffineConstraints<double> ux_constraints;
    dealii::AffineConstraints<double> uy_constraints;
    dealii::AffineConstraints<double> p_constraints;
    dealii::AffineConstraints<double> ns_constraints;  ///< Combined for coupled solve

    std::vector<dealii::types::global_dof_index> ux_to_ns_map;
    std::vector<dealii::types::global_dof_index> uy_to_ns_map;
    std::vector<dealii::types::global_dof_index> p_to_ns_map;

    dealii::SparsityPattern ns_sparsity;
    dealii::SparseMatrix<double> ns_matrix;
    dealii::Vector<double> ns_rhs;
    dealii::Vector<double> ns_solution;

    dealii::Vector<double> ux_solution;
    dealii::Vector<double> ux_old;
    dealii::Vector<double> uy_solution;
    dealii::Vector<double> uy_old;
    dealii::Vector<double> p_solution;

    // ========================================================================
    // Poisson System (φ)
    // ========================================================================
    dealii::DoFHandler<dim> phi_dof_handler;

    dealii::AffineConstraints<double> phi_constraints;

    dealii::SparsityPattern phi_sparsity;
    dealii::SparseMatrix<double> phi_matrix;
    dealii::Vector<double> phi_rhs;
    dealii::Vector<double> phi_solution;

    // ========================================================================
    // Magnetization System (Mx, My) - DG
    // ========================================================================
    dealii::DoFHandler<dim> mx_dof_handler;
    dealii::DoFHandler<dim> my_dof_handler;

    // DG sparsity pattern (for MagnetizationAssembler)
    dealii::SparsityPattern mx_sparsity;

    dealii::Vector<double> mx_solution;
    dealii::Vector<double> mx_old;
    dealii::Vector<double> my_solution;
    dealii::Vector<double> my_old;

    // ========================================================================
    // Constructor - Attaches DoF handlers to triangulation
    // ========================================================================
    MMSContext();

    // ========================================================================
    // Setup Methods - Use PRODUCTION code
    // ========================================================================

    /**
     * @brief Create mesh from parameters and refine globally
     *
     * Uses same mesh creation as PhaseFieldProblem::setup_mesh():
     * - Domain from params.domain.*
     * - Subdivisions from params.domain.initial_cells_*
     * - Boundary IDs: 0=bottom, 1=right, 2=top, 3=left
     *
     * @param params Simulation parameters
     * @param refinement Number of global refinements (overrides params.mesh.initial_refinement)
     */
    void setup_mesh(const Parameters& params, unsigned int refinement);

    /**
     * @brief Setup Cahn-Hilliard subsystem
     *
     * Calls PRODUCTION setup_ch_coupled_system() from setup/ch_setup.h.
     * For MMS, applies exact Dirichlet BCs via apply_ch_mms_boundary_constraints().
     *
     * @param params Simulation parameters
     * @param mms_time Time for MMS boundary conditions
     */
    void setup_ch(const Parameters& params, double mms_time);

    /**
     * @brief Setup Navier-Stokes subsystem
     *
     * Calls PRODUCTION setup_ns_coupled_system() from setup/ns_setup.h.
     * For MMS, applies exact Dirichlet BCs.
     *
     * @param params Simulation parameters
     * @param mms_time Time for MMS boundary conditions (used for L_y calculation)
     */
    void setup_ns(const Parameters& params, double mms_time);

    /**
     * @brief Setup Poisson subsystem
     *
     * Calls PRODUCTION setup_poisson_constraints_and_sparsity() from setup/poisson_setup.h.
     *
     * @param params Simulation parameters
     */
    void setup_poisson(const Parameters& params);

    /**
     * @brief Setup Magnetization subsystem (DG)
     *
     * Creates DG DoF handlers for Mx, My components.
     * No constraints needed for DG (handled in assembler).
     *
     * @param params Simulation parameters
     */
    void setup_magnetization(const Parameters& params);

    // ========================================================================
    // Initial Condition Methods
    // ========================================================================

    /**
     * @brief Apply CH MMS initial conditions at t_init
     * @param params Simulation parameters
     * @param t_init Initial time
     */
    void apply_ch_initial_conditions(const Parameters& params, double t_init);

    /**
     * @brief Apply NS MMS initial conditions at t_init
     * @param params Simulation parameters
     * @param t_init Initial time
     */
    void apply_ns_initial_conditions(const Parameters& params, double t_init);

    /**
     * @brief Apply Poisson MMS initial conditions (usually φ = 0)
     * @param params Simulation parameters
     * @param t_init Initial time
     */
    void apply_poisson_initial_conditions(const Parameters& params, double t_init);

    /**
     * @brief Apply Magnetization initial conditions (usually M = 0)
     * @param params Simulation parameters
     */
    void apply_magnetization_initial_conditions(const Parameters& params);

    // ========================================================================
    // Convenience Methods
    // ========================================================================

    /// Get minimum cell diameter (for h in convergence tables)
    double get_min_h() const;

    /// Get total CH DoFs
    unsigned int n_ch_dofs() const { return theta_dof_handler.n_dofs() * 2; }

    /// Get total NS DoFs
    unsigned int n_ns_dofs() const {
        return ux_dof_handler.n_dofs() + uy_dof_handler.n_dofs() + p_dof_handler.n_dofs();
    }

    /// Get total Poisson DoFs
    unsigned int n_phi_dofs() const { return phi_dof_handler.n_dofs(); }

    /// Get total Magnetization DoFs (Mx + My)
    unsigned int n_mag_dofs() const { return mx_dof_handler.n_dofs() * 2; }

    // ========================================================================
    // Update Constraints (for time-dependent MMS BCs)
    // ========================================================================

    /**
     * @brief Update CH constraints for new time (MMS)
     * @param params Simulation parameters
     * @param time Current time
     */
    void update_ch_constraints(const Parameters& params, double time);

    /**
     * @brief Update NS constraints for new time (MMS)
     * @param params Simulation parameters
     * @param time Current time
     */
    void update_ns_constraints(const Parameters& params, double time);
};

#endif // MMS_CONTEXT_H