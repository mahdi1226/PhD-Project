// ============================================================================
// mms/poisson/poisson_mms_test.cc - Poisson MMS Test Implementation (REFACTORED)
//
// Uses MMSContext for setup, which calls PRODUCTION code:
//   - setup/poisson_setup.h
//   - assembly/poisson_assembler.h
//   - solvers/poisson_solver.h
//
// Reference: Nochetto, Salgado & Tomas, CMAME 309 (2016) 497-531
// ============================================================================

#include "mms/poisson/poisson_mms_test.h"
#include "mms/poisson/poisson_mms.h"
#include "mms/mms_context.h"

// Production code (for assembly/solve - setup is in MMSContext)
#include "assembly/poisson_assembler.h"
#include "solvers/poisson_solver.h"

#include <deal.II/lac/sparse_direct.h>

#include <iostream>
#include <iomanip>
#include <fstream>
#include <chrono>
#include <cmath>

constexpr int dim = 2;

// ============================================================================
// Helper: Convert enum to string
// ============================================================================

std::string to_string(PoissonSolverType type)
{
    switch (type)
    {
        case PoissonSolverType::AMG:    return "AMG";
        case PoissonSolverType::SSOR:   return "SSOR";
        case PoissonSolverType::Direct: return "Direct";
        default: return "Unknown";
    }
}

// ============================================================================
// PoissonMMSConvergenceResult Implementation
// ============================================================================

void PoissonMMSConvergenceResult::compute_rates()
{
    L2_rates.clear();
    H1_rates.clear();

    for (size_t i = 1; i < results.size(); ++i)
    {
        const double h_fine = results[i].h;
        const double h_coarse = results[i-1].h;

        if (results[i-1].L2_error > 1e-15 && results[i].L2_error > 1e-15)
        {
            L2_rates.push_back(
                std::log(results[i-1].L2_error / results[i].L2_error)
                / std::log(h_coarse / h_fine));
        }
        else
        {
            L2_rates.push_back(0.0);
        }

        if (results[i-1].H1_error > 1e-15 && results[i].H1_error > 1e-15)
        {
            H1_rates.push_back(
                std::log(results[i-1].H1_error / results[i].H1_error)
                / std::log(h_coarse / h_fine));
        }
        else
        {
            H1_rates.push_back(0.0);
        }
    }
}

bool PoissonMMSConvergenceResult::passes(double tolerance) const
{
    if (L2_rates.empty() || H1_rates.empty())
        return false;

    return (L2_rates.back() >= expected_L2_rate - tolerance) &&
           (H1_rates.back() >= expected_H1_rate - tolerance);
}

void PoissonMMSConvergenceResult::print() const
{
    std::cout << "\n";
    std::cout << "================================================================\n";
    std::cout << "  POISSON MMS CONVERGENCE RESULTS\n";
    std::cout << "================================================================\n";
    std::cout << "  Solver: " << to_string(solver_type) << "\n";
    std::cout << "  FE degree: Q" << fe_degree << "\n";
    std::cout << "  Expected rates: L2 = " << expected_L2_rate
              << ", H1 = " << expected_H1_rate << "\n";
    std::cout << "================================================================\n\n";

    std::cout << std::left
              << std::setw(5)  << "Ref"
              << std::setw(10) << "DoFs"
              << std::setw(12) << "h"
              << std::setw(12) << "L2 error"
              << std::setw(8)  << "rate"
              << std::setw(12) << "H1 error"
              << std::setw(8)  << "rate"
              << std::setw(8)  << "iters"
              << std::setw(10) << "time(s)"
              << "\n";
    std::cout << std::string(85, '-') << "\n";

    for (size_t i = 0; i < results.size(); ++i)
    {
        const auto& r = results[i];

        std::cout << std::left
                  << std::setw(5)  << r.refinement
                  << std::setw(10) << r.n_dofs
                  << std::scientific << std::setprecision(2)
                  << std::setw(12) << r.h
                  << std::setw(12) << r.L2_error
                  << std::fixed << std::setprecision(2)
                  << std::setw(8)  << (i > 0 ? L2_rates[i-1] : 0.0)
                  << std::scientific << std::setprecision(2)
                  << std::setw(12) << r.H1_error
                  << std::fixed << std::setprecision(2)
                  << std::setw(8)  << (i > 0 ? H1_rates[i-1] : 0.0)
                  << std::setw(8)  << r.solver_iterations
                  << std::setw(10) << r.total_time
                  << "\n";
    }

    std::cout << "\n";
    if (!L2_rates.empty())
    {
        std::cout << "Asymptotic rates: L2 = " << std::fixed << std::setprecision(2)
                  << L2_rates.back() << ", H1 = " << H1_rates.back() << "\n";
        std::cout << "STATUS: " << (passes(0.3) ? "PASS" : "FAIL") << "\n";
    }
    std::cout << "\n";
}

void PoissonMMSConvergenceResult::write_csv(const std::string& filename) const
{
    std::ofstream file(filename);
    if (!file.is_open())
    {
        std::cerr << "[MMS] Failed to open " << filename << " for writing\n";
        return;
    }

    file << "refinement,n_dofs,h,L2_error,L2_rate,H1_error,H1_rate,"
         << "iterations,total_time,solver_type\n";

    for (size_t i = 0; i < results.size(); ++i)
    {
        const auto& r = results[i];
        file << r.refinement << ","
             << r.n_dofs << ","
             << std::scientific << std::setprecision(6) << r.h << ","
             << r.L2_error << ","
             << std::fixed << std::setprecision(3)
             << (i > 0 ? L2_rates[i-1] : 0.0) << ","
             << std::scientific << std::setprecision(6) << r.H1_error << ","
             << std::fixed << std::setprecision(3)
             << (i > 0 ? H1_rates[i-1] : 0.0) << ","
             << r.solver_iterations << ","
             << std::fixed << std::setprecision(4) << r.total_time << ","
             << to_string(r.solver_type) << "\n";
    }

    file.close();
    std::cout << "[MMS] Results written to " << filename << "\n";
}

// ============================================================================
// Run single Poisson MMS test - Using MMSContext
// ============================================================================

static PoissonMMSResult run_poisson_mms_single_impl(
    unsigned int refinement,
    Parameters params,
    PoissonSolverType solver_type)
{
    PoissonMMSResult result;
    result.refinement = refinement;
    result.solver_type = solver_type;

    auto total_start = std::chrono::high_resolution_clock::now();

    const double time = 1.0;  // MMS solution amplitude
    params.enable_mms = true;

    // ========================================================================
    // Setup using MMSContext - USES PRODUCTION CODE
    // ========================================================================
    MMSContext<dim> ctx;
    ctx.setup_mesh(params, refinement);
    ctx.setup_poisson(params);

    result.h = ctx.get_min_h();
    result.n_dofs = ctx.phi_dof_handler.n_dofs();

    // Empty M vectors for standalone test
    dealii::Vector<double> mx_empty, my_empty;

    // ========================================================================
    // PRODUCTION ASSEMBLY
    // ========================================================================
    auto asm_start = std::chrono::high_resolution_clock::now();

    assemble_poisson_system<dim>(
        ctx.phi_dof_handler, ctx.mx_dof_handler,
        mx_empty, my_empty,
        params, time,
        ctx.phi_matrix, ctx.phi_rhs, ctx.phi_constraints);

    auto asm_end = std::chrono::high_resolution_clock::now();
    result.assembly_time = std::chrono::duration<double>(asm_end - asm_start).count();

    // ========================================================================
    // PRODUCTION SOLVE
    // ========================================================================
    auto solve_start = std::chrono::high_resolution_clock::now();

    SolverInfo solver_info;

    switch (solver_type)
    {
        case PoissonSolverType::AMG:
        case PoissonSolverType::SSOR:
        {
            solver_info = solve_poisson_system(
                ctx.phi_matrix, ctx.phi_rhs, ctx.phi_solution,
                ctx.phi_constraints, false);
            break;
        }

        case PoissonSolverType::Direct:
        {
            dealii::SparseDirectUMFPACK direct_solver;
            direct_solver.initialize(ctx.phi_matrix);
            direct_solver.vmult(ctx.phi_solution, ctx.phi_rhs);
            ctx.phi_constraints.distribute(ctx.phi_solution);

            solver_info.iterations = 1;
            solver_info.residual = 0.0;
            solver_info.converged = true;
            break;
        }
    }

    auto solve_end = std::chrono::high_resolution_clock::now();
    result.solve_time = std::chrono::duration<double>(solve_end - solve_start).count();

    result.solver_iterations = solver_info.iterations;
    result.solver_residual = solver_info.residual;
    result.used_direct_fallback = !solver_info.converged;

    // ========================================================================
    // Compute errors
    // ========================================================================
    const double L_y = params.domain.y_max - params.domain.y_min;
    PoissonMMSError errors = compute_poisson_mms_error(
        ctx.phi_dof_handler, ctx.phi_solution, time, L_y);

    result.L2_error = errors.L2_error;
    result.H1_error = errors.H1_error;
    result.Linf_error = errors.Linf_error;

    auto total_end = std::chrono::high_resolution_clock::now();
    result.total_time = std::chrono::duration<double>(total_end - total_start).count();

    return result;
}

// ============================================================================
// Public interface
// ============================================================================

PoissonMMSResult run_poisson_mms_single(
    unsigned int refinement,
    const Parameters& params,
    PoissonSolverType solver_type)
{
    return run_poisson_mms_single_impl(refinement, params, solver_type);
}

PoissonMMSConvergenceResult run_poisson_mms_standalone(
    const std::vector<unsigned int>& refinements,
    const Parameters& params,
    PoissonSolverType solver_type)
{
    PoissonMMSConvergenceResult result;
    result.fe_degree = params.fe.degree_potential;
    result.expected_L2_rate = params.fe.degree_potential + 1;
    result.expected_H1_rate = params.fe.degree_potential;
    result.solver_type = solver_type;
    result.standalone = true;

    std::cout << "\n[POISSON_MMS] Running convergence study...\n";
    std::cout << "  Solver: " << to_string(solver_type) << "\n";
    std::cout << "  FE degree: Q" << params.fe.degree_potential << "\n";
    std::cout << "  Expected: L2 = " << result.expected_L2_rate
              << ", H1 = " << result.expected_H1_rate << "\n";
    std::cout << "  Using MMSContext with PRODUCTION code\n\n";

    for (unsigned int ref : refinements)
    {
        std::cout << "  Refinement " << ref << "... " << std::flush;

        PoissonMMSResult r = run_poisson_mms_single(ref, params, solver_type);
        result.results.push_back(r);

        std::cout << "L2=" << std::scientific << std::setprecision(2) << r.L2_error
                  << ", H1=" << r.H1_error
                  << ", iters=" << r.solver_iterations
                  << ", time=" << std::fixed << std::setprecision(2) << r.total_time << "s\n";
    }

    result.compute_rates();
    return result;
}

void compare_poisson_solvers(
    unsigned int refinement,
    const Parameters& params)
{
    std::cout << "\n================================================================\n";
    std::cout << "  POISSON SOLVER COMPARISON (Refinement " << refinement << ")\n";
    std::cout << "================================================================\n\n";

    std::vector<PoissonSolverType> solvers = {
        PoissonSolverType::AMG,
        PoissonSolverType::SSOR,
        PoissonSolverType::Direct
    };

    std::cout << std::left
              << std::setw(10) << "Solver"
              << std::setw(10) << "DoFs"
              << std::setw(10) << "Iters"
              << std::setw(12) << "Time(s)"
              << std::setw(12) << "L2 error"
              << "\n";
    std::cout << std::string(54, '-') << "\n";

    for (auto solver : solvers)
    {
        PoissonMMSResult r = run_poisson_mms_single(refinement, params, solver);

        std::cout << std::left
                  << std::setw(10) << to_string(solver)
                  << std::setw(10) << r.n_dofs
                  << std::setw(10) << r.solver_iterations
                  << std::fixed << std::setprecision(4)
                  << std::setw(12) << r.total_time
                  << std::scientific << std::setprecision(2)
                  << std::setw(12) << r.L2_error
                  << "\n";
    }
    std::cout << "\n";
}